// src/data/subjects.js
// AUTO-GENERATED from subjects.json — do not edit by hand
// Regenerate with: bash sync-subjects.sh

export const DEPARTMENTS =
  [
    {
      "id": "cosc",
      "label": "COSC",
      "color": "#4ecdc4",
      "icon": "◈",
      "courses": [
        {
          "id": "datastruct",
          "label": "Data Structures",
          "courseCode": "COSC 2436",
          "color": "#e8c547",
          "icon": "⬡",
          "notes": [
            {
              "file": "./content/subjects/datastruct/ds.md",
              "label": "Data Structures Reference"
            },
            {
              "file": "./content/subjects/datastruct/algos.md",
              "label": "Algorithm Complexity"
            },
            {
              "file": "./content/subjects/datastruct/listbrief.md",
              "label": "Brief Reference"
            },
            {
              "file": "./content/subjects/datastruct/listquick.md",
              "label": "Quick Reference"
            },
            {
              "file": "./content/subjects/datastruct/zydsa.md",
              "label": "Zybook Notes"
            },
            {
              "file": "./content/subjects/datastruct/ds_overview.md",
              "label": "DS Overview"
            },
            {
              "file": "./content/subjects/datastruct/ds_adts.md",
              "label": "ADTs"
            },
            {
              "file": "./content/subjects/datastruct/ds_array_vs_ll.md",
              "label": "Array vs Linked List"
            },
            {
              "file": "./content/subjects/datastruct/ds_vectors.md",
              "label": "Vectors & Arrays"
            },
            {
              "file": "./content/subjects/datastruct/ds_graphs.md",
              "label": "Graphs"
            },
            {
              "file": "./content/subjects/datastruct/ds_trees.md",
              "label": "Trees"
            },
            {
              "file": "./content/subjects/datastruct/ds_heaps.md",
              "label": "Heaps"
            },
            {
              "file": "./content/subjects/datastruct/ds_heap_vs_stack.md",
              "label": "Heap vs Stack"
            },
            {
              "file": "./content/subjects/datastruct/ds_composite.md",
              "label": "Composite Structures"
            },
            {
              "file": "./content/subjects/datastruct/ds_hash_collision.md",
              "label": "Hash Collision"
            },
            {
              "file": "./content/subjects/datastruct/ds_recursion.md",
              "label": "Recursion"
            },
            {
              "file": "./content/subjects/datastruct/ds_divide_conquer.md",
              "label": "Divide & Conquer"
            },
            {
              "file": "./content/subjects/datastruct/ds_special_algos.md",
              "label": "Special Algorithms"
            },
            {
              "file": "./content/subjects/datastruct/ds_sort_stability.md",
              "label": "Sort Stability"
            },
            {
              "file": "./content/subjects/datastruct/ds_paradigms.md",
              "label": "Paradigms"
            },
            {
              "file": "./content/subjects/datastruct/ds_algo_notes.md",
              "label": "Algo Notes"
            }
          ],
          "references": [
            {
              "file": "cosc/datastruct/other/ds_overview.html",
              "label": "DS Overview",
              "type": "iframe"
            },
            {
              "file": "cosc/datastruct/data_structures.html",
              "label": "DS History & Reference",
              "type": "iframe"
            },
            {
              "file": "cosc/datastruct/data_structures.html",
              "label": "Data Structures Guide",
              "type": "iframe"
            },
            {
              "type": "group",
              "label": "Linear Structures",
              "children": [
                {
                  "file": "cosc/datastruct/linear/ds_array.html",
                  "label": "Array Visual",
                  "type": "iframe"
                },
                {
                  "file": "cosc/datastruct/linear/ds_singly.html",
                  "label": "Singly Linked List",
                  "type": "iframe"
                },
                {
                  "file": "cosc/datastruct/linear/ds_doubly.html",
                  "label": "Doubly Linked List",
                  "type": "iframe"
                },
                {
                  "file": "cosc/datastruct/linear/ds_circular.html",
                  "label": "Circular List",
                  "type": "iframe"
                },
                {
                  "file": "cosc/datastruct/linear/ds_stack.html",
                  "label": "Stack",
                  "type": "iframe"
                },
                {
                  "file": "cosc/datastruct/linear/ds_queue.html",
                  "label": "Queue",
                  "type": "iframe"
                },
                {
                  "file": "cosc/datastruct/linear/ds_deque.html",
                  "label": "Deque",
                  "type": "iframe"
                },
                {
                  "file": "cosc/datastruct/other/ds_hashtable.html",
                  "label": "Hash Table",
                  "type": "iframe"
                }
              ]
            },
            {
              "type": "group",
              "label": "Trees & Graphs",
              "children": [
                {
                  "file": "cosc/datastruct/trees/ds_binarytree.html",
                  "label": "Binary Tree",
                  "type": "iframe"
                },
                {
                  "file": "cosc/datastruct/trees/ds_bst.html",
                  "label": "BST",
                  "type": "iframe"
                },
                {
                  "file": "cosc/datastruct/trees/ds_avl.html",
                  "label": "AVL Tree",
                  "type": "iframe"
                },
                {
                  "file": "cosc/datastruct/trees/ds_redblack.html",
                  "label": "Red-Black Tree",
                  "type": "iframe"
                },
                {
                  "file": "cosc/datastruct/trees/ds_heap.html",
                  "label": "Heap",
                  "type": "iframe"
                },
                {
                  "file": "cosc/datastruct/trees/ds_trie.html",
                  "label": "Trie",
                  "type": "iframe"
                },
                {
                  "file": "cosc/datastruct/other/ds_graph.html",
                  "label": "Graph",
                  "type": "iframe"
                },
                {
                  "file": "cosc/datastruct/trees/ds_btree.html",
                  "label": "B-Tree",
                  "type": "iframe"
                }
              ]
            },
            {
              "file": "cosc/datastruct/tools/ds_toc.html",
              "label": "DS Table of Contents",
              "type": "iframe"
            },
            {
              "type": "group",
              "label": "Tools",
              "children": [
                {
                  "file": "tools/iteration_visualizer.html",
                  "label": "Iteration Visualizer",
                  "type": "iframe"
                },
                {
                  "file": "tools/zybook.html",
                  "label": "Zybook",
                  "type": "iframe"
                }
              ]
            }
          ],
          "assignments": [],
          "code": [
            {
              "path": "./content/code/simplyDS/arrays.cpp",
              "label": "arrays.cpp"
            },
            {
              "path": "./content/code/simplyDS/singly.cpp",
              "label": "singly.cpp"
            },
            {
              "path": "./content/code/simplyDS/doubly.cpp",
              "label": "doubly.cpp"
            },
            {
              "path": "./content/code/simplyDS/circular.cpp",
              "label": "circular.cpp"
            },
            {
              "path": "./content/code/simplyDS/basicTrees.cpp",
              "label": "basicTrees.cpp"
            },
            {
              "path": "./content/code/simplyDS/specialTrees.cpp",
              "label": "specialTrees.cpp"
            },
            {
              "path": "./content/code/simplyDS/specialPurposeTrees.cpp",
              "label": "specialPurposeTrees.cpp"
            },
            {
              "path": "./content/code/simplyDS/selfBalancingTrees.cpp",
              "label": "selfBalancingTrees.cpp"
            },
            {
              "path": "./content/code/simplyDS/hash.cpp",
              "label": "hash.cpp"
            },
            {
              "path": "./content/code/simplyDS/pureGraphs.cpp",
              "label": "pureGraphs.cpp"
            },
            {
              "path": "./content/code/simplyDS/compositeGraphs.cpp",
              "label": "compositeGraphs.cpp"
            },
            {
              "path": "./content/code/simplyDS/unique.cpp",
              "label": "unique.cpp"
            },
            {
              "path": "./content/code/simplyDS/everythingArrays.cpp",
              "label": "everythingArrays.cpp"
            },
            {
              "path": "./content/code/simplyADT/linear.cpp",
              "label": "ADT — linear.cpp"
            },
            {
              "path": "./content/code/simplyADT/trees.cpp",
              "label": "ADT — trees.cpp"
            },
            {
              "path": "./content/code/simplyADT/graph.cpp",
              "label": "ADT — graph.cpp"
            },
            {
              "path": "./content/code/simplyADT/hash.cpp",
              "label": "ADT — hash.cpp"
            },
            {
              "path": "./content/code/simplyADT/special.cpp",
              "label": "ADT — special.cpp"
            }
          ],
          "flashcards": "dsa_basics",
          "pdfs": [
            {
              "file": "dsa_zybook.pdf",
              "label": "Zybook DSA Textbook"
            }
          ],
          "langRefs": true,
          "gopal": []
        },
        {
          "id": "algos",
          "label": "Algorithms",
          "courseCode": "COSC 3320",
          "color": "#4ecdc4",
          "icon": "∿",
          "notes": [
            {
              "file": "./content/notes/algos/hw1questions.md",
              "label": "HW1 Questions"
            },
            {
              "file": "./content/imp/algoinfo.md",
              "label": "Algorithm Categories Guide"
            },
            {
              "file": "./content/imp/ashort.md",
              "label": "Algorithm Categories (Short)"
            },
            {
              "file": "./content/notes/practice/3320Eintro.md",
              "label": "Intro Exam Practice"
            },
            {
              "file": "./content/subjects/discrete/proofs/algoproofs.md",
              "label": "Algo Proofs"
            },
            {
              "file": "./content/notes/algos/list.md",
              "label": "Algos List"
            },
            {
              "file": "./content/notes/algos/sorting.md",
              "label": "Sorting Notes"
            }
          ],
          "references": [
            {
              "file": "cosc/algos/algorithms.html",
              "label": "Algorithms History & Reference",
              "type": "iframe"
            },
            {
              "file": "cosc/algos/algorithms.html",
              "label": "Algorithms Guide",
              "type": "iframe"
            },
            {
              "file": "tools/recursion_memo_dp.html",
              "label": "Recursion / Memo / DP",
              "type": "iframe"
            },
            {
              "file": "cosc/algos/tools/algorithms_toc.html",
              "label": "Algorithms TOC",
              "type": "iframe"
            },
            {
              "type": "group",
              "label": "Searching",
              "children": [
                {
                  "file": "cosc/algos/searching/search_linear.html",
                  "label": "Linear Search",
                  "type": "iframe"
                },
                {
                  "file": "cosc/algos/searching/search_binary.html",
                  "label": "Binary Search",
                  "type": "iframe"
                },
                {
                  "file": "cosc/algos/searching/search_jump.html",
                  "label": "Jump Search",
                  "type": "iframe"
                },
                {
                  "file": "cosc/algos/searching/search_ternary.html",
                  "label": "Ternary Search",
                  "type": "iframe"
                }
              ]
            },
            {
              "type": "group",
              "label": "Sorting",
              "children": [
                {
                  "file": "cosc/algos/sorting/sort_bubble.html",
                  "label": "Bubble Sort",
                  "type": "iframe"
                },
                {
                  "file": "cosc/algos/sorting/sort_selection.html",
                  "label": "Selection Sort",
                  "type": "iframe"
                },
                {
                  "file": "cosc/algos/sorting/sort_insertion.html",
                  "label": "Insertion Sort",
                  "type": "iframe"
                },
                {
                  "file": "cosc/algos/sorting/sort_merge.html",
                  "label": "Merge Sort",
                  "type": "iframe"
                },
                {
                  "file": "cosc/algos/sorting/sort_quick.html",
                  "label": "Quick Sort",
                  "type": "iframe"
                },
                {
                  "file": "cosc/algos/sorting/sort_heap.html",
                  "label": "Heap Sort",
                  "type": "iframe"
                },
                {
                  "file": "cosc/algos/sorting/sort_shell.html",
                  "label": "Shell Sort",
                  "type": "iframe"
                },
                {
                  "file": "cosc/algos/sorting/sort_counting.html",
                  "label": "Counting Sort",
                  "type": "iframe"
                },
                {
                  "file": "cosc/algos/sorting/sort_radix.html",
                  "label": "Radix Sort",
                  "type": "iframe"
                },
                {
                  "file": "cosc/algos/sorting/sort_bucket.html",
                  "label": "Bucket Sort",
                  "type": "iframe"
                }
              ]
            },
            {
              "type": "group",
              "label": "Graph",
              "children": [
                {
                  "file": "cosc/algos/graphs/graph_bfs.html",
                  "label": "BFS",
                  "type": "iframe"
                },
                {
                  "file": "cosc/algos/graphs/graph_dfs.html",
                  "label": "DFS",
                  "type": "iframe"
                },
                {
                  "file": "cosc/algos/graphs/graph_dijkstra.html",
                  "label": "Dijkstra",
                  "type": "iframe"
                },
                {
                  "file": "cosc/algos/graphs/graph_bellmanford.html",
                  "label": "Bellman-Ford",
                  "type": "iframe"
                },
                {
                  "file": "cosc/algos/graphs/graph_floydwarshall.html",
                  "label": "Floyd-Warshall",
                  "type": "iframe"
                },
                {
                  "file": "cosc/algos/graphs/graph_mst.html",
                  "label": "Kruskal & Prim",
                  "type": "iframe"
                },
                {
                  "file": "cosc/algos/graphs/graph_toposort.html",
                  "label": "Topological Sort",
                  "type": "iframe"
                }
              ]
            },
            {
              "type": "group",
              "label": "Tree Algorithms",
              "children": [
                {
                  "file": "cosc/algos/trees/tree_traversals.html",
                  "label": "Traversals (Pre/In/Post/Level)",
                  "type": "iframe"
                },
                {
                  "file": "cosc/algos/trees/tree_queries.html",
                  "label": "Height, LCA, Diameter",
                  "type": "iframe"
                }
              ]
            },
            {
              "type": "group",
              "label": "Divide & Conquer",
              "children": [
                {
                  "file": "cosc/algos/paradigms/dc_overview.html",
                  "label": "D&C Overview + Master Theorem",
                  "type": "iframe"
                }
              ]
            },
            {
              "type": "group",
              "label": "Dynamic Programming",
              "children": [
                {
                  "file": "cosc/algos/paradigms/dp_overview.html",
                  "label": "DP Overview + Classic Problems",
                  "type": "iframe"
                }
              ]
            },
            {
              "type": "group",
              "label": "Greedy",
              "children": [
                {
                  "file": "cosc/algos/paradigms/greedy_overview.html",
                  "label": "Greedy Overview + Problems",
                  "type": "iframe"
                }
              ]
            },
            {
              "type": "group",
              "label": "Backtracking",
              "children": [
                {
                  "file": "cosc/algos/paradigms/backtracking_overview.html",
                  "label": "Backtracking Overview + Problems",
                  "type": "iframe"
                }
              ]
            }
          ],
          "gopal": [
            {
              "type": "group",
              "label": "References",
              "children": [
                {
                  "file": "cosc/algos/gopal/algos_overview.html",
                  "label": "Algorithms Overview",
                  "type": "iframe"
                },
                {
                  "file": "cosc/algos/gopal/algos_gopal_induction.html",
                  "label": "Induction",
                  "type": "iframe"
                },
                {
                  "file": "cosc/algos/paradigms/algos_greedy.html",
                  "label": "Greedy",
                  "type": "iframe"
                },
                {
                  "file": "cosc/algos/gopal/algos_think_induction.html",
                  "label": "Think Induction",
                  "type": "iframe"
                },
                {
                  "file": "cosc/algos/gopal/algos_think_pseudocode.html",
                  "label": "Pseudocode",
                  "type": "iframe"
                },
                {
                  "file": "cosc/algos/tools/algo_visualizer.html",
                  "label": "Algorithm Visualizer",
                  "type": "iframe"
                },
                {
                  "file": "cosc/algos/gopal/algos_recursion_explainer.html",
                  "label": "Recursion Explainer",
                  "type": "iframe"
                }
              ]
            },
            {
              "type": "group",
              "label": "Foundations",
              "children": [
                {
                  "file": "cosc/algos/gopal/gopal_asymptotic.html",
                  "label": "Asymptotic Notation (Big-O/Ω/Θ)",
                  "type": "iframe"
                },
                {
                  "file": "cosc/algos/gopal/gopal_ram_model.html",
                  "label": "RAM Model of Computation",
                  "type": "iframe"
                },
                {
                  "file": "cosc/algos/gopal/gopal_primality.html",
                  "label": "Primality Checking",
                  "type": "iframe"
                },
                {
                  "file": "cosc/algos/gopal/gopal_induction.html",
                  "label": "Mathematical Induction",
                  "type": "iframe"
                },
                {
                  "file": "cosc/algos/gopal/gopal_gcd.html",
                  "label": "GCD & Euclidean Algorithm",
                  "type": "iframe"
                },
                {
                  "file": "cosc/algos/gopal/gopal_recurrences.html",
                  "label": "Recurrences & Master Theorem",
                  "type": "iframe"
                }
              ]
            },
            {
              "type": "group",
              "label": "Algorithms",
              "children": [
                {
                  "file": "cosc/algos/gopal/gopal_selection.html",
                  "label": "Selection — Median of Medians",
                  "type": "iframe"
                },
                {
                  "file": "cosc/algos/gopal/gopal_closest_pair.html",
                  "label": "Closest Pair of Points",
                  "type": "iframe"
                },
                {
                  "file": "cosc/algos/gopal/gopal_fft.html",
                  "label": "FFT & DFT",
                  "type": "iframe"
                },
                {
                  "file": "cosc/algos/gopal/gopal_maxsum.html",
                  "label": "Max Subarray / Kadane's",
                  "type": "iframe"
                },
                {
                  "file": "cosc/algos/gopal/gopal_matrix_chain.html",
                  "label": "Matrix Chain Multiplication",
                  "type": "iframe"
                },
                {
                  "file": "cosc/algos/gopal/gopal_seq_align.html",
                  "label": "Sequence Alignment",
                  "type": "iframe"
                },
                {
                  "file": "cosc/algos/gopal/gopal_caching.html",
                  "label": "Optimal Caching / LFD",
                  "type": "iframe"
                },
                {
                  "file": "cosc/algos/gopal/gopal_astar.html",
                  "label": "A* Algorithm",
                  "type": "iframe"
                }
              ]
            },
            {
              "type": "group",
              "label": "Appendices",
              "children": [
                {
                  "file": "cosc/algos/gopal/gopal_union_find.html",
                  "label": "Union-Find / Disjoint Sets",
                  "type": "iframe"
                },
                {
                  "file": "cosc/algos/gopal/gopal_math_formulas.html",
                  "label": "Math Formulas for Algorithms",
                  "type": "iframe"
                }
              ]
            }
          ],
          "assignments": [
            {
              "file": "./content/assignments/algos/intro_exam_review.html",
              "label": "Intro Exam Review",
              "type": "content"
            },
            {
              "file": "./content/practice/algos_intro_exam.html",
              "label": "Intro Exam Practice",
              "type": "content"
            },
            {
              "type": "group",
              "label": "Exam",
              "children": [
                {
                  "file": "./content/assignments/algos/intro_exam.html",
                  "label": "algos gopal intro exam Intro",
                  "type": "content"
                }
              ]
            },
            {
              "type": "group",
              "label": "Template",
              "children": [
                {
                  "file": "./content/assignments/algos/template.html",
                  "label": "TEMPLATE algos",
                  "type": "content"
                }
              ]
            },
            {
              "type": "group",
              "label": "Homeworks",
              "children": [
                {
                  "file": "./content/assignments/algos/hw2_solutions.html",
                  "label": "algos 3320 hw2 solutions",
                  "type": "content"
                },
                {
                  "file": "./content/assignments/algos/hw1_solutions.html",
                  "label": "algos 3320 hw1 solutions",
                  "type": "content"
                }
              ]
            },
            {
              "type": "group",
              "label": "Gopal",
              "children": []
            }
          ],
          "code": [
            {
              "path": "./content/code/simplyAlgos/sorting.cpp",
              "label": "sorting.cpp"
            },
            {
              "path": "./content/code/simplyAlgos/searching.cpp",
              "label": "searching.cpp"
            },
            {
              "path": "./content/code/simplyAlgos/divideConquer.cpp",
              "label": "divideConquer.cpp"
            },
            {
              "path": "./content/code/simplyAlgos/dynamicProgramming.cpp",
              "label": "dynamicProgramming.cpp"
            },
            {
              "path": "./content/code/simplyAlgos/greedy.cpp",
              "label": "greedy.cpp"
            },
            {
              "path": "./content/code/simplyAlgos/backtracking.cpp",
              "label": "backtracking.cpp"
            },
            {
              "path": "./content/code/simplyAlgos/graph.cpp",
              "label": "graph.cpp"
            },
            {
              "path": "./content/code/simplyAlgos/tree.cpp",
              "label": "tree.cpp"
            },
            {
              "type": "group",
              "label": "Homework",
              "children": [
                {
                  "file": "./content/code/algos/algos_code_hw2_ex6.py",
                  "label": "algos code hw2 ex6"
                }
              ]
            }
          ],
          "flashcards": null,
          "pdfs": [
            {
              "file": "algos_gopal_textbook.pdf",
              "label": "Gopal Algorithms Textbook"
            },
            {
              "file": "algos_intro_exam.pdf",
              "label": "Gopal Intro Exam"
            },
            {
              "type": "group",
              "label": "Homework",
              "children": [
                {
                  "file": "algos_hw1_answerkey.pdf",
                  "label": "COSC3320 Homework 1 Spr 2026 ANSWERKEY"
                },
                {
                  "file": "algos_hw2.pdf",
                  "label": "COSC3320 Homework 2 Spr 2026"
                },
                {
                  "file": "algos_hw1_solutions.pdf",
                  "label": "algos c hw1 solutions"
                },
                {
                  "file": "algos_hw1_personal.pdf",
                  "label": "algos jesiah hw1"
                }
              ]
            }
          ],
          "langRefs": true
        },
        {
          "id": "automata",
          "label": "Automata",
          "courseCode": "COSC 3340",
          "color": "#ff6b9d",
          "icon": "◎",
          "notes": [
            {
              "file": "./content/notes/automata/list.md",
              "label": "Main Notes"
            },
            {
              "file": "./content/notes/automata/oldlist.md",
              "label": "Previous Notes"
            },
            {
              "file": "./content/notes/assignments/problems_extractedAutomata.md",
              "label": "Extracted Problems"
            },
            {
              "file": "./content/notes/assignments/solutionsAutomatahw1to2q1pq2.md",
              "label": "HW1-2 Solutions"
            },
            {
              "file": "./content/notes/practice/3340Q1.md",
              "label": "Quiz 1 Practice"
            },
            {
              "file": "./content/subjects/discrete/proofs/automataproofs.md",
              "label": "Automata Proofs"
            },
            {
              "file": "./content/notes/automata/hw1_hw2_solutions.md",
              "label": "HW1-2 Solutions"
            },
            {
              "file": "./content/notes/automata/problems_extracted.md",
              "label": "Problems Extracted"
            }
          ],
          "references": [
            {
              "file": "cosc/automata/finite/automata_reference.html",
              "label": "Automata History & Reference",
              "type": "iframe"
            },
            {
              "file": "cosc/automata/advanced/automata_sipser.html",
              "label": "Sipser Reference",
              "type": "iframe"
            },
            {
              "file": "cosc/automata/finite/automata_reading_sets.html",
              "label": "Reading Sets & Automata",
              "type": "iframe"
            },
            {
              "file": "cosc/automata/finite/jflap_demo.html",
              "label": "JFLAP Demo",
              "type": "iframe"
            },
            {
              "type": "group",
              "label": "Visual",
              "children": [
                {
                  "file": "cosc/automata/finite/automata_visualizer.html",
                  "label": "Automata Visualizer",
                  "type": "iframe"
                }
              ]
            },
            {
              "type": "group",
              "label": "3340",
              "children": [
                {
                  "file": "cosc/automata/finite/automata_dfa_nfa.html",
                  "label": "DFA & NFA",
                  "type": "iframe"
                },
                {
                  "file": "cosc/automata/advanced/automata_pumping.html",
                  "label": "Pumping Lemma",
                  "type": "iframe"
                },
                {
                  "file": "cosc/automata/advanced/automata_turing.html",
                  "label": "Turing Machines",
                  "type": "iframe"
                }
              ]
            }
          ],
          "assignments": [
            {
              "file": "./content/assignments/automata/hw1_problems.html",
              "label": "HW1 Solutions",
              "type": "content"
            },
            {
              "file": "./content/assignments/automata/hw2_problems.html",
              "label": "HW2 Solutions",
              "type": "content"
            },
            {
              "file": "./content/assignments/automata/hw3_problems.html",
              "label": "HW3 Solutions",
              "type": "content"
            },
            {
              "file": "./content/assignments/automata/quiz1_review.html",
              "label": "Quiz 1 Review",
              "type": "content"
            },
            {
              "file": "./content/assignments/automata/quiz2_review.html",
              "label": "Practice Quiz 2",
              "type": "content"
            },
            {
              "file": "./content/practice/automata_quiz1.html",
              "label": "Q1 Practice",
              "type": "content"
            },
            {
              "type": "group",
              "label": "Quiz",
              "children": [
                {
                  "file": "./content/assignments/automata/quiz2_review.html",
                  "label": "automata quiz2 rev",
                  "type": "content"
                },
                {
                  "file": "./content/assignments/automata/quiz1_solutions.html",
                  "label": "automata quiz1 solutions",
                  "type": "content"
                },
                {
                  "file": "./content/assignments/automata/quiz2_practice.html",
                  "label": "Quiz 2 Practice",
                  "type": "content"
                }
              ]
            },
            {
              "type": "group",
              "label": "Template",
              "children": [
                {
                  "file": "./content/assignments/automata/quiz_template.html",
                  "label": "automata quiz template",
                  "type": "content"
                }
              ]
            },
            {
              "type": "group",
              "label": "Homeworks",
              "children": [
                {
                  "file": "./content/assignments/automata/hw3_solutions.html",
                  "label": "automata cosc3340 hw3 solutions (1)",
                  "type": "content"
                },
                {
                  "file": "./content/assignments/automata/hw1_solutions.html",
                  "label": "automata 3340 hw1 solutions",
                  "type": "content"
                },
                {
                  "file": "./content/assignments/automata/hw2_solutions.html",
                  "label": "automata hw2 solutions",
                  "type": "content"
                }
              ]
            }
          ],
          "code": [],
          "flashcards": "automata_basics",
          "pdfs": [
            {
              "file": "automata_varem.pdf",
              "label": "Automata Textbook (Varem)"
            },
            {
              "file": "automata_quiz2.pdf",
              "label": "AutomataQuiz2"
            }
          ],
          "langRefs": true,
          "gopal": []
        },
        {
          "id": "comporg",
          "label": "Comp Org",
          "courseCode": "COSC 2425",
          "color": "#34d399",
          "icon": "⚙",
          "notes": [],
          "references": [
            {
              "file": "cosc/comporg/comporg_reference.html",
              "label": "Comp Org History & Reference",
              "type": "iframe"
            },
            {
              "file": "cosc/comporg/arm_reference.html",
              "label": "ARM / Comp Org Reference",
              "type": "iframe"
            }
          ],
          "assignments": [],
          "code": [],
          "flashcards": null,
          "pdfs": [
            {
              "file": "comporg_arm_textbook.pdf",
              "label": "ARM Architecture Textbook"
            },
            {
              "file": "comporg_notes.pdf",
              "label": "Comp Org Merged Notes"
            },
            {
              "file": "comporg_labs.pdf",
              "label": "Comp Org Labs"
            }
          ],
          "langRefs": true,
          "gopal": []
        },
        {
          "id": "databases",
          "label": "Databases",
          "courseCode": "COSC 3380",
          "color": "#f472b6",
          "icon": "⊗",
          "notes": [],
          "references": [
            {
              "file": "cosc/databases/databases_prep.html",
              "label": "⚡ Fall Prep Guide",
              "type": "iframe"
            },
            {
              "file": "cosc/databases/databases_reference.html",
              "label": "DB History, Models & Migration",
              "type": "iframe"
            },
            {
              "file": "cosc/databases/sql_reference.html",
              "label": "SQL Reference",
              "type": "iframe"
            }
          ],
          "assignments": [],
          "code": [],
          "flashcards": null,
          "pdfs": [],
          "langRefs": true,
          "gopal": []
        },
        {
          "id": "opsystems",
          "label": "Operating Systems",
          "courseCode": "COSC 3360",
          "color": "#fb923c",
          "icon": "⚙",
          "isHub": true,
          "lanes": [
            {
              "id": "opsystems_academic",
              "icon": "⚙",
              "color": "#fb923c",
              "title": "Academic OS",
              "description": "Course references, prep guides, and the Rincon textbook. Scheduling, memory management, concurrency, and OS theory."
            },
            {
              "id": "opsystems_linux",
              "icon": "⌘",
              "color": "#34d399",
              "title": "Linux",
              "description": "Personal notes on the Linux OS — kernels, GNU, the terminal, permissions, package management, and the history behind it all."
            }
          ],
          "assignments": [],
          "gopal": [],
          "pdfs": [],
          "references": []
        },
        {
          "id": "opsystems_academic",
          "label": "Academic OS",
          "courseCode": "COSC 3360",
          "color": "#fb923c",
          "icon": "⚙",
          "hubParent": "opsystems",
          "notes": [],
          "references": [
            {
              "file": "cosc/opsystems/opsystems_prep.html",
              "label": "⚡ Fall Prep Guide",
              "type": "iframe"
            },
            {
              "file": "cosc/opsystems/opsystems_reference.html",
              "label": "OS History & Reference",
              "type": "iframe"
            }
          ],
          "assignments": [],
          "code": [],
          "flashcards": null,
          "pdfs": [
            {
              "file": "opsystems_textbook.pdf",
              "label": "Operating Systems — Rincon Textbook"
            }
          ],
          "langRefs": true,
          "gopal": []
        },
        {
          "id": "opsystems_linux",
          "label": "Linux",
          "courseCode": "COSC 3360",
          "color": "#34d399",
          "icon": "⌘",
          "hubParent": "opsystems",
          "notes": [
            {
              "file": "./content/subjects/linux/linux_os.md",
              "label": "OS"
            },
            {
              "file": "./content/subjects/linux/linux_os_history.md",
              "label": "OS History"
            },
            {
              "file": "./content/subjects/linux/linux_kernels.md",
              "label": "Kernels"
            },
            {
              "file": "./content/subjects/linux/linux_gnu.md",
              "label": "GNU/Linux"
            },
            {
              "file": "./content/subjects/linux/linux_gnu_breakdown.md",
              "label": "Linux & GNU Breakdown"
            },
            {
              "file": "./content/subjects/linux/linux_gnu_demo.md",
              "label": "GNU/Linux Demo"
            },
            {
              "file": "./content/subjects/linux/linux_minix.md",
              "label": "Minix"
            },
            {
              "file": "./content/subjects/linux/linux_goats_of_cs.md",
              "label": "Goats of CS"
            },
            {
              "file": "./content/subjects/linux/linux_terminal.md",
              "label": "Terminal"
            },
            {
              "file": "./content/subjects/linux/linux_permissions.md",
              "label": "Permissions"
            },
            {
              "file": "./content/subjects/linux/linux_hidden_files.md",
              "label": "Hidden Files"
            },
            {
              "file": "./content/subjects/linux/linux_my_hidden_files.md",
              "label": "My Hidden Files"
            },
            {
              "file": "./content/subjects/linux/linux_package_management.md",
              "label": "Package Management"
            },
            {
              "file": "./content/subjects/linux/linux_makeup.md",
              "label": "Linux Makeup"
            },
            {
              "file": "./content/subjects/linux/linux_words.md",
              "label": "Linux Words"
            },
            {
              "file": "./content/subjects/linux/linux_specs.md",
              "label": "Specs"
            },
            {
              "file": "./content/subjects/linux/linux_api.md",
              "label": "API"
            },
            {
              "file": "./content/subjects/linux/linux_git.md",
              "label": "Git"
            },
            {
              "file": "./content/subjects/linux/linux_gnome.md",
              "label": "GNOME"
            },
            {
              "file": "./content/subjects/linux/linux_anticheat_proton.md",
              "label": "Anti-Cheat & Proton"
            },
            {
              "file": "./content/subjects/linux/linux_wine_proton.md",
              "label": "Wine & Proton"
            },
            {
              "file": "./content/subjects/linux/linux_lockdown_browser.md",
              "label": "Lockdown Browser"
            }
          ],
          "references": [
            {
              "file": "cosc/linux/linux_reference.html",
              "label": "Linux History & Reference",
              "type": "iframe"
            },
            {
              "file": "cosc/linux/linux_quick.html",
              "label": "Linux Quick Reference",
              "type": "iframe"
            }
          ],
          "assignments": [],
          "code": [],
          "flashcards": null,
          "pdfs": [],
          "langRefs": true,
          "gopal": []
        },
        {
          "id": "cpp",
          "label": "C++",
          "courseCode": "COSC 1437",
          "color": "#fb923c",
          "icon": "{}",
          "notes": [
            {
              "file": "./content/subjects/cpp/listcpp.md",
              "label": "Notes I"
            },
            {
              "file": "./content/subjects/cpp/listcpp_2.md",
              "label": "Notes II"
            },
            {
              "file": "./content/subjects/cpp/listcpp_3.md",
              "label": "Notes III"
            },
            {
              "file": "./content/subjects/cpp/zycpp.md",
              "label": "Zybook Notes"
            },
            {
              "file": "./content/subjects/cpp/cpp_concepts.md",
              "label": "Core Concepts"
            },
            {
              "file": "./content/subjects/cpp/cpp_adt.md",
              "label": "ADTs in C++"
            },
            {
              "file": "./content/subjects/cpp/cpp_compile_run.md",
              "label": "Compile & Run"
            },
            {
              "file": "./content/subjects/cpp/cpp_malloc.md",
              "label": "Malloc & Memory"
            },
            {
              "file": "./content/subjects/cpp/cpp_poly_inheritance.md",
              "label": "Polymorphism & Inheritance"
            },
            {
              "file": "./content/subjects/cpp/cpp_static_auto.md",
              "label": "Static & Auto"
            },
            {
              "file": "./content/subjects/cpp/cpp_symbols.md",
              "label": "Symbols"
            },
            {
              "file": "./content/subjects/cpp/cpp_ting.md",
              "label": "Ting"
            },
            {
              "file": "./content/subjects/cpp/cpp_tong.md",
              "label": "Tong"
            }
          ],
          "references": [
            {
              "file": "cosc/cpp/cpp_reference.html",
              "label": "C++ History & Reference",
              "type": "iframe"
            },
            {
              "file": "cosc/cpp/cpp_reference.html",
              "label": "C++ Quick Reference",
              "type": "iframe"
            }
          ],
          "assignments": [],
          "code": [],
          "flashcards": "prog_fundamentals",
          "pdfs": [
            {
              "file": "cpp_notes.pdf",
              "label": "C++ Merged Textbook"
            },
            {
              "file": "cpp_rpg_project.pdf",
              "label": "RPG Project"
            }
          ],
          "langRefs": true,
          "gopal": []
        },
        {
          "id": "python",
          "label": "Python",
          "courseCode": null,
          "color": "#4ecdc4",
          "icon": "𝜆",
          "notes": [],
          "references": [
            {
              "file": "languages/python_reference.html",
              "label": "Python History & Reference",
              "type": "iframe"
            },
            {
              "file": "languages/python_reference.html",
              "label": "Python Quick Reference",
              "type": "iframe"
            }
          ],
          "assignments": [],
          "code": [],
          "flashcards": null,
          "pdfs": [],
          "langRefs": true,
          "gopal": []
        },
        {
          "id": "ai",
          "label": "AI & LLMs",
          "courseCode": null,
          "color": "#a78bfa",
          "icon": "◎",
          "notes": [
            {
              "file": "ai/introtollms.md",
              "label": "Intro to LLMs"
            },
            {
              "file": "ai/transformers.md",
              "label": "Transformers"
            },
            {
              "file": "ai/agents.md",
              "label": "Agents"
            },
            {
              "file": "ai/transformer.svg",
              "label": "Transformer Architecture (SVG)"
            }
          ],
          "references": [
            {
              "file": "ai/llms_intro.html",
              "label": "Intro to LLMs",
              "type": "iframe"
            },
            {
              "file": "ai/llm_explained.html",
              "label": "LLM Explained",
              "type": "iframe"
            },
            {
              "file": "ai/machine_learning.html",
              "label": "Machine Learning",
              "type": "iframe"
            },
            {
              "file": "ai/deep_learning.html",
              "label": "Deep Learning",
              "type": "iframe"
            },
            {
              "type": "group",
              "label": "Agents",
              "children": [
                {
                  "file": "ai/ai_agents.html",
                  "label": "AI Agents",
                  "type": "iframe"
                },
                {
                  "file": "ai/agents_guide.html",
                  "label": "Agents Guide",
                  "type": "iframe"
                }
              ]
            },
            {
              "file": "ai/ai_landscape.html",
              "label": "AI Landscape",
              "type": "iframe"
            }
          ],
          "assignments": [],
          "code": [],
          "flashcards": null,
          "pdfs": [],
          "gopal": []
        }
      ]
    },
    {
      "id": "math",
      "label": "MATH",
      "color": "#f472b6",
      "icon": "∑",
      "courses": [
        {
          "id": "algebra",
          "label": "Algebra",
          "courseCode": null,
          "color": "#e8c547",
          "icon": "x²",
          "notes": [],
          "references": [
            {
              "file": "math/notation/math_science.html",
              "label": "Math & Science Ref",
              "type": "iframe"
            }
          ],
          "assignments": [],
          "code": [],
          "flashcards": null,
          "pdfs": [],
          "gopal": []
        },
        {
          "id": "precalc",
          "label": "Pre-Calculus",
          "courseCode": null,
          "color": "#fb923c",
          "icon": "∠",
          "notes": [],
          "references": [
            {
              "file": "math/notation/math_science.html",
              "label": "Math & Science Ref",
              "type": "iframe"
            }
          ],
          "assignments": [],
          "code": [],
          "flashcards": null,
          "pdfs": [],
          "gopal": []
        },
        {
          "id": "calc1",
          "label": "Calculus I",
          "courseCode": null,
          "color": "#4ecdc4",
          "icon": "∫",
          "notes": [],
          "references": [
            {
              "file": "math/notation/math_science.html",
              "label": "Math & Science Ref",
              "type": "iframe"
            }
          ],
          "assignments": [],
          "code": [],
          "flashcards": null,
          "pdfs": [],
          "gopal": []
        },
        {
          "id": "calc2",
          "label": "Calculus II",
          "courseCode": null,
          "color": "#4ecdc4",
          "icon": "∬",
          "notes": [],
          "references": [
            {
              "file": "math/notation/math_science.html",
              "label": "Math & Science Ref",
              "type": "iframe"
            }
          ],
          "assignments": [],
          "code": [],
          "flashcards": null,
          "pdfs": [],
          "gopal": []
        },
        {
          "id": "discrete",
          "label": "Discrete Math",
          "courseCode": "COSC 2303",
          "color": "#a78bfa",
          "icon": "∑",
          "notes": [
            {
              "file": "./content/subjects/discrete/list.md",
              "label": "Main Notes"
            },
            {
              "file": "./content/subjects/discrete/asymptotic.md",
              "label": "Asymptotic Notation"
            },
            {
              "file": "./content/subjects/discrete/combperm.md",
              "label": "Combinatorics & Permutations"
            },
            {
              "file": "./content/subjects/discrete/proofs/proofs.md",
              "label": "Proofs"
            },
            {
              "file": "./content/notes/math_notation.md",
              "label": "Math Notation Notes"
            }
          ],
          "references": [
            {
              "file": "math/discrete/discrete_math.html",
              "label": "Discrete Math Guide",
              "type": "iframe"
            },
            {
              "file": "math/notation/math_notation.html",
              "label": "Math Notation",
              "type": "iframe"
            },
            {
              "file": "math/notation/math_science.html",
              "label": "Math & Science Ref",
              "type": "iframe"
            },
            {
              "file": "math/notation/math_notation_simple.html",
              "label": "Math Notation (Simple)",
              "type": "iframe"
            }
          ],
          "assignments": [],
          "code": [],
          "flashcards": null,
          "pdfs": [
            {
              "file": "discrete_textbook.pdf",
              "label": "Discrete Math Textbook"
            },
            {
              "file": "discrete_notes.pdf",
              "label": "Discrete Notes"
            },
            {
              "file": "discrete_exam1.pdf",
              "label": "Exam 1"
            },
            {
              "file": "discrete_exam2.pdf",
              "label": "Exam 2"
            }
          ],
          "gopal": []
        },
        {
          "id": "linear",
          "label": "Linear Algebra",
          "courseCode": "MATH 2318",
          "color": "#f472b6",
          "icon": "[]",
          "notes": [
            {
              "file": "./content/notes/linear/list.md",
              "label": "Main Notes"
            },
            {
              "file": "./content/notes/practice/linearhwto5.md",
              "label": "HW1-5 Reference"
            },
            {
              "file": "./content/notes/practice/2318E1.md",
              "label": "Exam 1 Practice"
            }
          ],
          "references": [
            {
              "file": "math/linear/linear_algebra.html",
              "label": "Linear Algebra Guide",
              "type": "iframe"
            },
            {
              "file": "math/notation/math_notation.html",
              "label": "Math Notation",
              "type": "iframe"
            },
            {
              "file": "./content/subjects/linear/linear_template.html",
              "label": "linear template"
            },
            {
              "file": "math/notation/math_notation_simple.html",
              "label": "Math Notation (Simple)",
              "type": "iframe"
            }
          ],
          "assignments": [
            {
              "file": "./content/assignments/linear/hw1.html",
              "label": "HW1",
              "type": "content"
            },
            {
              "file": "./content/assignments/linear/hw2.html",
              "label": "HW2",
              "type": "content"
            },
            {
              "file": "./content/assignments/linear/hw3.html",
              "label": "HW3",
              "type": "content"
            },
            {
              "file": "./content/assignments/linear/hw4.html",
              "label": "HW4 — Vector Spaces",
              "type": "content"
            },
            {
              "file": "./content/assignments/linear/hw5.html",
              "label": "HW5 — Linear Operators",
              "type": "content"
            },
            {
              "file": "./content/assignments/linear/exam1_review.html",
              "label": "Exam 1 Review",
              "type": "content"
            },
            {
              "file": "./content/assignments/linear/exam_checklist.html",
              "label": "Exam Checklist",
              "type": "content"
            },
            {
              "file": "./content/subjects/linear/linear_template.html",
              "label": "linear template"
            },
            {
              "file": "./content/practice/linear_exam1.html",
              "label": "Exam 1 Practice",
              "type": "content"
            },
            {
              "type": "group",
              "label": "Old Exam",
              "children": [
                {
                  "file": "./content/assignments/linear/exam2_final.html",
                  "label": "math2318 exam2 FINAL v2",
                  "type": "content"
                },
                {
                  "file": "./content/assignments/linear/exam1_old.html",
                  "label": "math2318 OLD exam1 solutions",
                  "type": "content"
                },
                {
                  "file": "./content/assignments/linear/final_sp24.html",
                  "label": "linear final sp24 solutions",
                  "type": "content"
                }
              ]
            },
            {
              "type": "group",
              "label": "Exam",
              "children": [
                {
                  "file": "./content/assignments/linear/exam1_sp26.html",
                  "label": "math2318 exam1 sp26 solutions",
                  "type": "content"
                }
              ]
            }
          ],
          "code": [],
          "flashcards": null,
          "pdfs": [
            {
              "type": "group",
              "label": "OldExams",
              "children": [
                {
                  "file": "linear_exam1_sp25.pdf",
                  "label": "Linear Spring25Exam1"
                },
                {
                  "file": "linear_exam2_sp25.pdf",
                  "label": "Linear Spring25Exam2"
                },
                {
                  "file": "linear_final_sp25.pdf",
                  "label": "Linear Spring25FinalExam"
                }
              ]
            },
            {
              "file": "linear_textbook.pdf",
              "label": "Linear Algebra Textbook"
            },
            {
              "type": "group",
              "label": "NewExam",
              "children": [
                {
                  "file": "linear_exams_1_to_3.pdf",
                  "label": "Linear Exam1 3"
                }
              ]
            }
          ],
          "gopal": []
        },
        {
          "id": "stats",
          "label": "Statistics",
          "courseCode": null,
          "color": "#a78bfa",
          "icon": "σ",
          "notes": [],
          "references": [
            {
              "file": "math/stats/statistics.html",
              "label": "Statistics Reference",
              "type": "iframe"
            }
          ],
          "assignments": [],
          "code": [],
          "flashcards": null,
          "pdfs": [
            {
              "file": "stats_lectures.pdf",
              "label": "All Lectures"
            }
          ],
          "gopal": []
        }
      ]
    }
  ];

export const LANG_REFS =
  [
    {
      "file": "cosc/cpp/c_reference.html",
      "label": "C",
      "color": "#34d399"
    },
    {
      "file": "languages/java_reference.html",
      "label": "Java",
      "color": "#e8c547"
    },
    {
      "file": "languages/csharp_reference.html",
      "label": "C#",
      "color": "#a78bfa"
    },
    {
      "file": "languages/typescript_reference.html",
      "label": "TypeScript",
      "color": "#4ecdc4"
    },
    {
      "file": "languages/rust_reference.html",
      "label": "Rust",
      "color": "#ff6b9d"
    },
    {
      "file": "languages/go_reference.html",
      "label": "Go",
      "color": "#34d399"
    },
    {
      "file": "cosc/databases/sql_reference.html",
      "label": "SQL",
      "color": "#e8c547"
    },
    {
      "file": "languages/htmlcss_reference.html",
      "label": "HTML/CSS",
      "color": "#fb923c"
    },
    {
      "file": "cosc/comporg/arm_reference.html",
      "label": "ARM",
      "color": "#34d399"
    },
    {
      "file": "cosc/linux/linux_reference.html",
      "label": "Linux",
      "color": "#a78bfa"
    },
    {
      "file": "tools/git_reference.html",
      "label": "Git",
      "color": "#fb923c"
    },
    {
      "file": "cosc/linux/bash_reference.html",
      "label": "Bash",
      "color": "#a8e6a3"
    },
    {
      "file": "cosc/cpp/cpp_reference.html",
      "label": "C++",
      "color": "#fb923c"
    },
    {
      "file": "languages/python_reference.html",
      "label": "Python",
      "color": "#4ecdc4"
    }
  ];

export const MATH_SHARED_REFS =
  [
    {
      "label": "Math & Science Ref",
      "file": "math/notation/math_science.html",
      "color": "#f472b6"
    },
    {
      "label": "Math Notation",
      "file": "math/notation/math_notation.html",
      "color": "#f472b6"
    },
    {
      "label": "Discrete Math",
      "file": "math/discrete/discrete_math.html",
      "color": "#a78bfa"
    },
    {
      "label": "Pre-Calculus",
      "file": "math/calculus/precalculus.html",
      "color": "#fb923c"
    },
    {
      "label": "Calculus I",
      "file": "math/calculus/calculus1.html",
      "color": "#4ecdc4"
    },
    {
      "label": "Calculus II",
      "file": "math/calculus/calculus2.html",
      "color": "#4ecdc4"
    },
    {
      "label": "Linear Algebra",
      "file": "math/linear/linear_algebra.html",
      "color": "#a78bfa"
    },
    {
      "label": "Statistics",
      "file": "math/stats/statistics.html",
      "color": "#a78bfa"
    }
  ];

export const ALL_COURSES =
  [
    {
      "id": "datastruct",
      "label": "Data Structures",
      "courseCode": "COSC 2436",
      "color": "#e8c547",
      "icon": "⬡",
      "notes": [
        {
          "file": "./content/subjects/datastruct/ds.md",
          "label": "Data Structures Reference"
        },
        {
          "file": "./content/subjects/datastruct/algos.md",
          "label": "Algorithm Complexity"
        },
        {
          "file": "./content/subjects/datastruct/listbrief.md",
          "label": "Brief Reference"
        },
        {
          "file": "./content/subjects/datastruct/listquick.md",
          "label": "Quick Reference"
        },
        {
          "file": "./content/subjects/datastruct/zydsa.md",
          "label": "Zybook Notes"
        },
        {
          "file": "./content/subjects/datastruct/ds_overview.md",
          "label": "DS Overview"
        },
        {
          "file": "./content/subjects/datastruct/ds_adts.md",
          "label": "ADTs"
        },
        {
          "file": "./content/subjects/datastruct/ds_array_vs_ll.md",
          "label": "Array vs Linked List"
        },
        {
          "file": "./content/subjects/datastruct/ds_vectors.md",
          "label": "Vectors & Arrays"
        },
        {
          "file": "./content/subjects/datastruct/ds_graphs.md",
          "label": "Graphs"
        },
        {
          "file": "./content/subjects/datastruct/ds_trees.md",
          "label": "Trees"
        },
        {
          "file": "./content/subjects/datastruct/ds_heaps.md",
          "label": "Heaps"
        },
        {
          "file": "./content/subjects/datastruct/ds_heap_vs_stack.md",
          "label": "Heap vs Stack"
        },
        {
          "file": "./content/subjects/datastruct/ds_composite.md",
          "label": "Composite Structures"
        },
        {
          "file": "./content/subjects/datastruct/ds_hash_collision.md",
          "label": "Hash Collision"
        },
        {
          "file": "./content/subjects/datastruct/ds_recursion.md",
          "label": "Recursion"
        },
        {
          "file": "./content/subjects/datastruct/ds_divide_conquer.md",
          "label": "Divide & Conquer"
        },
        {
          "file": "./content/subjects/datastruct/ds_special_algos.md",
          "label": "Special Algorithms"
        },
        {
          "file": "./content/subjects/datastruct/ds_sort_stability.md",
          "label": "Sort Stability"
        },
        {
          "file": "./content/subjects/datastruct/ds_paradigms.md",
          "label": "Paradigms"
        },
        {
          "file": "./content/subjects/datastruct/ds_algo_notes.md",
          "label": "Algo Notes"
        }
      ],
      "references": [
        {
          "file": "cosc/datastruct/other/ds_overview.html",
          "label": "DS Overview",
          "type": "iframe"
        },
        {
          "file": "cosc/datastruct/data_structures.html",
          "label": "DS History & Reference",
          "type": "iframe"
        },
        {
          "file": "cosc/datastruct/data_structures.html",
          "label": "Data Structures Guide",
          "type": "iframe"
        },
        {
          "type": "group",
          "label": "Linear Structures",
          "children": [
            {
              "file": "cosc/datastruct/linear/ds_array.html",
              "label": "Array Visual",
              "type": "iframe"
            },
            {
              "file": "cosc/datastruct/linear/ds_singly.html",
              "label": "Singly Linked List",
              "type": "iframe"
            },
            {
              "file": "cosc/datastruct/linear/ds_doubly.html",
              "label": "Doubly Linked List",
              "type": "iframe"
            },
            {
              "file": "cosc/datastruct/linear/ds_circular.html",
              "label": "Circular List",
              "type": "iframe"
            },
            {
              "file": "cosc/datastruct/linear/ds_stack.html",
              "label": "Stack",
              "type": "iframe"
            },
            {
              "file": "cosc/datastruct/linear/ds_queue.html",
              "label": "Queue",
              "type": "iframe"
            },
            {
              "file": "cosc/datastruct/linear/ds_deque.html",
              "label": "Deque",
              "type": "iframe"
            },
            {
              "file": "cosc/datastruct/other/ds_hashtable.html",
              "label": "Hash Table",
              "type": "iframe"
            }
          ]
        },
        {
          "type": "group",
          "label": "Trees & Graphs",
          "children": [
            {
              "file": "cosc/datastruct/trees/ds_binarytree.html",
              "label": "Binary Tree",
              "type": "iframe"
            },
            {
              "file": "cosc/datastruct/trees/ds_bst.html",
              "label": "BST",
              "type": "iframe"
            },
            {
              "file": "cosc/datastruct/trees/ds_avl.html",
              "label": "AVL Tree",
              "type": "iframe"
            },
            {
              "file": "cosc/datastruct/trees/ds_redblack.html",
              "label": "Red-Black Tree",
              "type": "iframe"
            },
            {
              "file": "cosc/datastruct/trees/ds_heap.html",
              "label": "Heap",
              "type": "iframe"
            },
            {
              "file": "cosc/datastruct/trees/ds_trie.html",
              "label": "Trie",
              "type": "iframe"
            },
            {
              "file": "cosc/datastruct/other/ds_graph.html",
              "label": "Graph",
              "type": "iframe"
            },
            {
              "file": "cosc/datastruct/trees/ds_btree.html",
              "label": "B-Tree",
              "type": "iframe"
            }
          ]
        },
        {
          "file": "cosc/datastruct/tools/ds_toc.html",
          "label": "DS Table of Contents",
          "type": "iframe"
        },
        {
          "type": "group",
          "label": "Tools",
          "children": [
            {
              "file": "tools/iteration_visualizer.html",
              "label": "Iteration Visualizer",
              "type": "iframe"
            },
            {
              "file": "tools/zybook.html",
              "label": "Zybook",
              "type": "iframe"
            }
          ]
        }
      ],
      "assignments": [],
      "code": [
        {
          "path": "./content/code/simplyDS/arrays.cpp",
          "label": "arrays.cpp"
        },
        {
          "path": "./content/code/simplyDS/singly.cpp",
          "label": "singly.cpp"
        },
        {
          "path": "./content/code/simplyDS/doubly.cpp",
          "label": "doubly.cpp"
        },
        {
          "path": "./content/code/simplyDS/circular.cpp",
          "label": "circular.cpp"
        },
        {
          "path": "./content/code/simplyDS/basicTrees.cpp",
          "label": "basicTrees.cpp"
        },
        {
          "path": "./content/code/simplyDS/specialTrees.cpp",
          "label": "specialTrees.cpp"
        },
        {
          "path": "./content/code/simplyDS/specialPurposeTrees.cpp",
          "label": "specialPurposeTrees.cpp"
        },
        {
          "path": "./content/code/simplyDS/selfBalancingTrees.cpp",
          "label": "selfBalancingTrees.cpp"
        },
        {
          "path": "./content/code/simplyDS/hash.cpp",
          "label": "hash.cpp"
        },
        {
          "path": "./content/code/simplyDS/pureGraphs.cpp",
          "label": "pureGraphs.cpp"
        },
        {
          "path": "./content/code/simplyDS/compositeGraphs.cpp",
          "label": "compositeGraphs.cpp"
        },
        {
          "path": "./content/code/simplyDS/unique.cpp",
          "label": "unique.cpp"
        },
        {
          "path": "./content/code/simplyDS/everythingArrays.cpp",
          "label": "everythingArrays.cpp"
        },
        {
          "path": "./content/code/simplyADT/linear.cpp",
          "label": "ADT — linear.cpp"
        },
        {
          "path": "./content/code/simplyADT/trees.cpp",
          "label": "ADT — trees.cpp"
        },
        {
          "path": "./content/code/simplyADT/graph.cpp",
          "label": "ADT — graph.cpp"
        },
        {
          "path": "./content/code/simplyADT/hash.cpp",
          "label": "ADT — hash.cpp"
        },
        {
          "path": "./content/code/simplyADT/special.cpp",
          "label": "ADT — special.cpp"
        }
      ],
      "flashcards": "dsa_basics",
      "pdfs": [
        {
          "file": "dsa_zybook.pdf",
          "label": "Zybook DSA Textbook"
        }
      ],
      "langRefs": true,
      "gopal": [],
      "dept": "cosc",
      "deptLabel": "COSC"
    },
    {
      "id": "algos",
      "label": "Algorithms",
      "courseCode": "COSC 3320",
      "color": "#4ecdc4",
      "icon": "∿",
      "notes": [
        {
          "file": "./content/notes/algos/hw1questions.md",
          "label": "HW1 Questions"
        },
        {
          "file": "./content/imp/algoinfo.md",
          "label": "Algorithm Categories Guide"
        },
        {
          "file": "./content/imp/ashort.md",
          "label": "Algorithm Categories (Short)"
        },
        {
          "file": "./content/notes/practice/3320Eintro.md",
          "label": "Intro Exam Practice"
        },
        {
          "file": "./content/subjects/discrete/proofs/algoproofs.md",
          "label": "Algo Proofs"
        },
        {
          "file": "./content/notes/algos/list.md",
          "label": "Algos List"
        },
        {
          "file": "./content/notes/algos/sorting.md",
          "label": "Sorting Notes"
        }
      ],
      "references": [
        {
          "file": "cosc/algos/algorithms.html",
          "label": "Algorithms History & Reference",
          "type": "iframe"
        },
        {
          "file": "cosc/algos/algorithms.html",
          "label": "Algorithms Guide",
          "type": "iframe"
        },
        {
          "file": "tools/recursion_memo_dp.html",
          "label": "Recursion / Memo / DP",
          "type": "iframe"
        },
        {
          "file": "cosc/algos/tools/algorithms_toc.html",
          "label": "Algorithms TOC",
          "type": "iframe"
        },
        {
          "type": "group",
          "label": "Searching",
          "children": [
            {
              "file": "cosc/algos/searching/search_linear.html",
              "label": "Linear Search",
              "type": "iframe"
            },
            {
              "file": "cosc/algos/searching/search_binary.html",
              "label": "Binary Search",
              "type": "iframe"
            },
            {
              "file": "cosc/algos/searching/search_jump.html",
              "label": "Jump Search",
              "type": "iframe"
            },
            {
              "file": "cosc/algos/searching/search_ternary.html",
              "label": "Ternary Search",
              "type": "iframe"
            }
          ]
        },
        {
          "type": "group",
          "label": "Sorting",
          "children": [
            {
              "file": "cosc/algos/sorting/sort_bubble.html",
              "label": "Bubble Sort",
              "type": "iframe"
            },
            {
              "file": "cosc/algos/sorting/sort_selection.html",
              "label": "Selection Sort",
              "type": "iframe"
            },
            {
              "file": "cosc/algos/sorting/sort_insertion.html",
              "label": "Insertion Sort",
              "type": "iframe"
            },
            {
              "file": "cosc/algos/sorting/sort_merge.html",
              "label": "Merge Sort",
              "type": "iframe"
            },
            {
              "file": "cosc/algos/sorting/sort_quick.html",
              "label": "Quick Sort",
              "type": "iframe"
            },
            {
              "file": "cosc/algos/sorting/sort_heap.html",
              "label": "Heap Sort",
              "type": "iframe"
            },
            {
              "file": "cosc/algos/sorting/sort_shell.html",
              "label": "Shell Sort",
              "type": "iframe"
            },
            {
              "file": "cosc/algos/sorting/sort_counting.html",
              "label": "Counting Sort",
              "type": "iframe"
            },
            {
              "file": "cosc/algos/sorting/sort_radix.html",
              "label": "Radix Sort",
              "type": "iframe"
            },
            {
              "file": "cosc/algos/sorting/sort_bucket.html",
              "label": "Bucket Sort",
              "type": "iframe"
            }
          ]
        },
        {
          "type": "group",
          "label": "Graph",
          "children": [
            {
              "file": "cosc/algos/graphs/graph_bfs.html",
              "label": "BFS",
              "type": "iframe"
            },
            {
              "file": "cosc/algos/graphs/graph_dfs.html",
              "label": "DFS",
              "type": "iframe"
            },
            {
              "file": "cosc/algos/graphs/graph_dijkstra.html",
              "label": "Dijkstra",
              "type": "iframe"
            },
            {
              "file": "cosc/algos/graphs/graph_bellmanford.html",
              "label": "Bellman-Ford",
              "type": "iframe"
            },
            {
              "file": "cosc/algos/graphs/graph_floydwarshall.html",
              "label": "Floyd-Warshall",
              "type": "iframe"
            },
            {
              "file": "cosc/algos/graphs/graph_mst.html",
              "label": "Kruskal & Prim",
              "type": "iframe"
            },
            {
              "file": "cosc/algos/graphs/graph_toposort.html",
              "label": "Topological Sort",
              "type": "iframe"
            }
          ]
        },
        {
          "type": "group",
          "label": "Tree Algorithms",
          "children": [
            {
              "file": "cosc/algos/trees/tree_traversals.html",
              "label": "Traversals (Pre/In/Post/Level)",
              "type": "iframe"
            },
            {
              "file": "cosc/algos/trees/tree_queries.html",
              "label": "Height, LCA, Diameter",
              "type": "iframe"
            }
          ]
        },
        {
          "type": "group",
          "label": "Divide & Conquer",
          "children": [
            {
              "file": "cosc/algos/paradigms/dc_overview.html",
              "label": "D&C Overview + Master Theorem",
              "type": "iframe"
            }
          ]
        },
        {
          "type": "group",
          "label": "Dynamic Programming",
          "children": [
            {
              "file": "cosc/algos/paradigms/dp_overview.html",
              "label": "DP Overview + Classic Problems",
              "type": "iframe"
            }
          ]
        },
        {
          "type": "group",
          "label": "Greedy",
          "children": [
            {
              "file": "cosc/algos/paradigms/greedy_overview.html",
              "label": "Greedy Overview + Problems",
              "type": "iframe"
            }
          ]
        },
        {
          "type": "group",
          "label": "Backtracking",
          "children": [
            {
              "file": "cosc/algos/paradigms/backtracking_overview.html",
              "label": "Backtracking Overview + Problems",
              "type": "iframe"
            }
          ]
        }
      ],
      "gopal": [
        {
          "type": "group",
          "label": "References",
          "children": [
            {
              "file": "cosc/algos/gopal/algos_overview.html",
              "label": "Algorithms Overview",
              "type": "iframe"
            },
            {
              "file": "cosc/algos/gopal/algos_gopal_induction.html",
              "label": "Induction",
              "type": "iframe"
            },
            {
              "file": "cosc/algos/paradigms/algos_greedy.html",
              "label": "Greedy",
              "type": "iframe"
            },
            {
              "file": "cosc/algos/gopal/algos_think_induction.html",
              "label": "Think Induction",
              "type": "iframe"
            },
            {
              "file": "cosc/algos/gopal/algos_think_pseudocode.html",
              "label": "Pseudocode",
              "type": "iframe"
            },
            {
              "file": "cosc/algos/tools/algo_visualizer.html",
              "label": "Algorithm Visualizer",
              "type": "iframe"
            },
            {
              "file": "cosc/algos/gopal/algos_recursion_explainer.html",
              "label": "Recursion Explainer",
              "type": "iframe"
            }
          ]
        },
        {
          "type": "group",
          "label": "Foundations",
          "children": [
            {
              "file": "cosc/algos/gopal/gopal_asymptotic.html",
              "label": "Asymptotic Notation (Big-O/Ω/Θ)",
              "type": "iframe"
            },
            {
              "file": "cosc/algos/gopal/gopal_ram_model.html",
              "label": "RAM Model of Computation",
              "type": "iframe"
            },
            {
              "file": "cosc/algos/gopal/gopal_primality.html",
              "label": "Primality Checking",
              "type": "iframe"
            },
            {
              "file": "cosc/algos/gopal/gopal_induction.html",
              "label": "Mathematical Induction",
              "type": "iframe"
            },
            {
              "file": "cosc/algos/gopal/gopal_gcd.html",
              "label": "GCD & Euclidean Algorithm",
              "type": "iframe"
            },
            {
              "file": "cosc/algos/gopal/gopal_recurrences.html",
              "label": "Recurrences & Master Theorem",
              "type": "iframe"
            }
          ]
        },
        {
          "type": "group",
          "label": "Algorithms",
          "children": [
            {
              "file": "cosc/algos/gopal/gopal_selection.html",
              "label": "Selection — Median of Medians",
              "type": "iframe"
            },
            {
              "file": "cosc/algos/gopal/gopal_closest_pair.html",
              "label": "Closest Pair of Points",
              "type": "iframe"
            },
            {
              "file": "cosc/algos/gopal/gopal_fft.html",
              "label": "FFT & DFT",
              "type": "iframe"
            },
            {
              "file": "cosc/algos/gopal/gopal_maxsum.html",
              "label": "Max Subarray / Kadane's",
              "type": "iframe"
            },
            {
              "file": "cosc/algos/gopal/gopal_matrix_chain.html",
              "label": "Matrix Chain Multiplication",
              "type": "iframe"
            },
            {
              "file": "cosc/algos/gopal/gopal_seq_align.html",
              "label": "Sequence Alignment",
              "type": "iframe"
            },
            {
              "file": "cosc/algos/gopal/gopal_caching.html",
              "label": "Optimal Caching / LFD",
              "type": "iframe"
            },
            {
              "file": "cosc/algos/gopal/gopal_astar.html",
              "label": "A* Algorithm",
              "type": "iframe"
            }
          ]
        },
        {
          "type": "group",
          "label": "Appendices",
          "children": [
            {
              "file": "cosc/algos/gopal/gopal_union_find.html",
              "label": "Union-Find / Disjoint Sets",
              "type": "iframe"
            },
            {
              "file": "cosc/algos/gopal/gopal_math_formulas.html",
              "label": "Math Formulas for Algorithms",
              "type": "iframe"
            }
          ]
        }
      ],
      "assignments": [
        {
          "file": "./content/assignments/algos/intro_exam_review.html",
          "label": "Intro Exam Review",
          "type": "content"
        },
        {
          "file": "./content/practice/algos_intro_exam.html",
          "label": "Intro Exam Practice",
          "type": "content"
        },
        {
          "type": "group",
          "label": "Exam",
          "children": [
            {
              "file": "./content/assignments/algos/intro_exam.html",
              "label": "algos gopal intro exam Intro",
              "type": "content"
            }
          ]
        },
        {
          "type": "group",
          "label": "Template",
          "children": [
            {
              "file": "./content/assignments/algos/template.html",
              "label": "TEMPLATE algos",
              "type": "content"
            }
          ]
        },
        {
          "type": "group",
          "label": "Homeworks",
          "children": [
            {
              "file": "./content/assignments/algos/hw2_solutions.html",
              "label": "algos 3320 hw2 solutions",
              "type": "content"
            },
            {
              "file": "./content/assignments/algos/hw1_solutions.html",
              "label": "algos 3320 hw1 solutions",
              "type": "content"
            }
          ]
        },
        {
          "type": "group",
          "label": "Gopal",
          "children": []
        }
      ],
      "code": [
        {
          "path": "./content/code/simplyAlgos/sorting.cpp",
          "label": "sorting.cpp"
        },
        {
          "path": "./content/code/simplyAlgos/searching.cpp",
          "label": "searching.cpp"
        },
        {
          "path": "./content/code/simplyAlgos/divideConquer.cpp",
          "label": "divideConquer.cpp"
        },
        {
          "path": "./content/code/simplyAlgos/dynamicProgramming.cpp",
          "label": "dynamicProgramming.cpp"
        },
        {
          "path": "./content/code/simplyAlgos/greedy.cpp",
          "label": "greedy.cpp"
        },
        {
          "path": "./content/code/simplyAlgos/backtracking.cpp",
          "label": "backtracking.cpp"
        },
        {
          "path": "./content/code/simplyAlgos/graph.cpp",
          "label": "graph.cpp"
        },
        {
          "path": "./content/code/simplyAlgos/tree.cpp",
          "label": "tree.cpp"
        },
        {
          "type": "group",
          "label": "Homework",
          "children": [
            {
              "file": "./content/code/algos/algos_code_hw2_ex6.py",
              "label": "algos code hw2 ex6"
            }
          ]
        }
      ],
      "flashcards": null,
      "pdfs": [
        {
          "file": "algos_gopal_textbook.pdf",
          "label": "Gopal Algorithms Textbook"
        },
        {
          "file": "algos_intro_exam.pdf",
          "label": "Gopal Intro Exam"
        },
        {
          "type": "group",
          "label": "Homework",
          "children": [
            {
              "file": "algos_hw1_answerkey.pdf",
              "label": "COSC3320 Homework 1 Spr 2026 ANSWERKEY"
            },
            {
              "file": "algos_hw2.pdf",
              "label": "COSC3320 Homework 2 Spr 2026"
            },
            {
              "file": "algos_hw1_solutions.pdf",
              "label": "algos c hw1 solutions"
            },
            {
              "file": "algos_hw1_personal.pdf",
              "label": "algos jesiah hw1"
            }
          ]
        }
      ],
      "langRefs": true,
      "dept": "cosc",
      "deptLabel": "COSC"
    },
    {
      "id": "automata",
      "label": "Automata",
      "courseCode": "COSC 3340",
      "color": "#ff6b9d",
      "icon": "◎",
      "notes": [
        {
          "file": "./content/notes/automata/list.md",
          "label": "Main Notes"
        },
        {
          "file": "./content/notes/automata/oldlist.md",
          "label": "Previous Notes"
        },
        {
          "file": "./content/notes/assignments/problems_extractedAutomata.md",
          "label": "Extracted Problems"
        },
        {
          "file": "./content/notes/assignments/solutionsAutomatahw1to2q1pq2.md",
          "label": "HW1-2 Solutions"
        },
        {
          "file": "./content/notes/practice/3340Q1.md",
          "label": "Quiz 1 Practice"
        },
        {
          "file": "./content/subjects/discrete/proofs/automataproofs.md",
          "label": "Automata Proofs"
        },
        {
          "file": "./content/notes/automata/hw1_hw2_solutions.md",
          "label": "HW1-2 Solutions"
        },
        {
          "file": "./content/notes/automata/problems_extracted.md",
          "label": "Problems Extracted"
        }
      ],
      "references": [
        {
          "file": "cosc/automata/finite/automata_reference.html",
          "label": "Automata History & Reference",
          "type": "iframe"
        },
        {
          "file": "cosc/automata/advanced/automata_sipser.html",
          "label": "Sipser Reference",
          "type": "iframe"
        },
        {
          "file": "cosc/automata/finite/automata_reading_sets.html",
          "label": "Reading Sets & Automata",
          "type": "iframe"
        },
        {
          "file": "cosc/automata/finite/jflap_demo.html",
          "label": "JFLAP Demo",
          "type": "iframe"
        },
        {
          "type": "group",
          "label": "Visual",
          "children": [
            {
              "file": "cosc/automata/finite/automata_visualizer.html",
              "label": "Automata Visualizer",
              "type": "iframe"
            }
          ]
        },
        {
          "type": "group",
          "label": "3340",
          "children": [
            {
              "file": "cosc/automata/finite/automata_dfa_nfa.html",
              "label": "DFA & NFA",
              "type": "iframe"
            },
            {
              "file": "cosc/automata/advanced/automata_pumping.html",
              "label": "Pumping Lemma",
              "type": "iframe"
            },
            {
              "file": "cosc/automata/advanced/automata_turing.html",
              "label": "Turing Machines",
              "type": "iframe"
            }
          ]
        }
      ],
      "assignments": [
        {
          "file": "./content/assignments/automata/hw1_problems.html",
          "label": "HW1 Solutions",
          "type": "content"
        },
        {
          "file": "./content/assignments/automata/hw2_problems.html",
          "label": "HW2 Solutions",
          "type": "content"
        },
        {
          "file": "./content/assignments/automata/hw3_problems.html",
          "label": "HW3 Solutions",
          "type": "content"
        },
        {
          "file": "./content/assignments/automata/quiz1_review.html",
          "label": "Quiz 1 Review",
          "type": "content"
        },
        {
          "file": "./content/assignments/automata/quiz2_review.html",
          "label": "Practice Quiz 2",
          "type": "content"
        },
        {
          "file": "./content/practice/automata_quiz1.html",
          "label": "Q1 Practice",
          "type": "content"
        },
        {
          "type": "group",
          "label": "Quiz",
          "children": [
            {
              "file": "./content/assignments/automata/quiz2_review.html",
              "label": "automata quiz2 rev",
              "type": "content"
            },
            {
              "file": "./content/assignments/automata/quiz1_solutions.html",
              "label": "automata quiz1 solutions",
              "type": "content"
            },
            {
              "file": "./content/assignments/automata/quiz2_practice.html",
              "label": "Quiz 2 Practice",
              "type": "content"
            }
          ]
        },
        {
          "type": "group",
          "label": "Template",
          "children": [
            {
              "file": "./content/assignments/automata/quiz_template.html",
              "label": "automata quiz template",
              "type": "content"
            }
          ]
        },
        {
          "type": "group",
          "label": "Homeworks",
          "children": [
            {
              "file": "./content/assignments/automata/hw3_solutions.html",
              "label": "automata cosc3340 hw3 solutions (1)",
              "type": "content"
            },
            {
              "file": "./content/assignments/automata/hw1_solutions.html",
              "label": "automata 3340 hw1 solutions",
              "type": "content"
            },
            {
              "file": "./content/assignments/automata/hw2_solutions.html",
              "label": "automata hw2 solutions",
              "type": "content"
            }
          ]
        }
      ],
      "code": [],
      "flashcards": "automata_basics",
      "pdfs": [
        {
          "file": "automata_varem.pdf",
          "label": "Automata Textbook (Varem)"
        },
        {
          "file": "automata_quiz2.pdf",
          "label": "AutomataQuiz2"
        }
      ],
      "langRefs": true,
      "gopal": [],
      "dept": "cosc",
      "deptLabel": "COSC"
    },
    {
      "id": "comporg",
      "label": "Comp Org",
      "courseCode": "COSC 2425",
      "color": "#34d399",
      "icon": "⚙",
      "notes": [],
      "references": [
        {
          "file": "cosc/comporg/comporg_reference.html",
          "label": "Comp Org History & Reference",
          "type": "iframe"
        },
        {
          "file": "cosc/comporg/arm_reference.html",
          "label": "ARM / Comp Org Reference",
          "type": "iframe"
        }
      ],
      "assignments": [],
      "code": [],
      "flashcards": null,
      "pdfs": [
        {
          "file": "comporg_arm_textbook.pdf",
          "label": "ARM Architecture Textbook"
        },
        {
          "file": "comporg_notes.pdf",
          "label": "Comp Org Merged Notes"
        },
        {
          "file": "comporg_labs.pdf",
          "label": "Comp Org Labs"
        }
      ],
      "langRefs": true,
      "gopal": [],
      "dept": "cosc",
      "deptLabel": "COSC"
    },
    {
      "id": "databases",
      "label": "Databases",
      "courseCode": "COSC 3380",
      "color": "#f472b6",
      "icon": "⊗",
      "notes": [],
      "references": [
        {
          "file": "cosc/databases/databases_prep.html",
          "label": "⚡ Fall Prep Guide",
          "type": "iframe"
        },
        {
          "file": "cosc/databases/databases_reference.html",
          "label": "DB History, Models & Migration",
          "type": "iframe"
        },
        {
          "file": "cosc/databases/sql_reference.html",
          "label": "SQL Reference",
          "type": "iframe"
        }
      ],
      "assignments": [],
      "code": [],
      "flashcards": null,
      "pdfs": [],
      "langRefs": true,
      "gopal": [],
      "dept": "cosc",
      "deptLabel": "COSC"
    },
    {
      "id": "opsystems",
      "label": "Operating Systems",
      "courseCode": "COSC 3360",
      "color": "#fb923c",
      "icon": "⚙",
      "isHub": true,
      "lanes": [
        {
          "id": "opsystems_academic",
          "icon": "⚙",
          "color": "#fb923c",
          "title": "Academic OS",
          "description": "Course references, prep guides, and the Rincon textbook. Scheduling, memory management, concurrency, and OS theory."
        },
        {
          "id": "opsystems_linux",
          "icon": "⌘",
          "color": "#34d399",
          "title": "Linux",
          "description": "Personal notes on the Linux OS — kernels, GNU, the terminal, permissions, package management, and the history behind it all."
        }
      ],
      "assignments": [],
      "gopal": [],
      "pdfs": [],
      "references": [],
      "dept": "cosc",
      "deptLabel": "COSC"
    },
    {
      "id": "opsystems_academic",
      "label": "Academic OS",
      "courseCode": "COSC 3360",
      "color": "#fb923c",
      "icon": "⚙",
      "hubParent": "opsystems",
      "notes": [],
      "references": [
        {
          "file": "cosc/opsystems/opsystems_prep.html",
          "label": "⚡ Fall Prep Guide",
          "type": "iframe"
        },
        {
          "file": "cosc/opsystems/opsystems_reference.html",
          "label": "OS History & Reference",
          "type": "iframe"
        }
      ],
      "assignments": [],
      "code": [],
      "flashcards": null,
      "pdfs": [
        {
          "file": "opsystems_textbook.pdf",
          "label": "Operating Systems — Rincon Textbook"
        }
      ],
      "langRefs": true,
      "gopal": [],
      "dept": "cosc",
      "deptLabel": "COSC"
    },
    {
      "id": "opsystems_linux",
      "label": "Linux",
      "courseCode": "COSC 3360",
      "color": "#34d399",
      "icon": "⌘",
      "hubParent": "opsystems",
      "notes": [
        {
          "file": "./content/subjects/linux/linux_os.md",
          "label": "OS"
        },
        {
          "file": "./content/subjects/linux/linux_os_history.md",
          "label": "OS History"
        },
        {
          "file": "./content/subjects/linux/linux_kernels.md",
          "label": "Kernels"
        },
        {
          "file": "./content/subjects/linux/linux_gnu.md",
          "label": "GNU/Linux"
        },
        {
          "file": "./content/subjects/linux/linux_gnu_breakdown.md",
          "label": "Linux & GNU Breakdown"
        },
        {
          "file": "./content/subjects/linux/linux_gnu_demo.md",
          "label": "GNU/Linux Demo"
        },
        {
          "file": "./content/subjects/linux/linux_minix.md",
          "label": "Minix"
        },
        {
          "file": "./content/subjects/linux/linux_goats_of_cs.md",
          "label": "Goats of CS"
        },
        {
          "file": "./content/subjects/linux/linux_terminal.md",
          "label": "Terminal"
        },
        {
          "file": "./content/subjects/linux/linux_permissions.md",
          "label": "Permissions"
        },
        {
          "file": "./content/subjects/linux/linux_hidden_files.md",
          "label": "Hidden Files"
        },
        {
          "file": "./content/subjects/linux/linux_my_hidden_files.md",
          "label": "My Hidden Files"
        },
        {
          "file": "./content/subjects/linux/linux_package_management.md",
          "label": "Package Management"
        },
        {
          "file": "./content/subjects/linux/linux_makeup.md",
          "label": "Linux Makeup"
        },
        {
          "file": "./content/subjects/linux/linux_words.md",
          "label": "Linux Words"
        },
        {
          "file": "./content/subjects/linux/linux_specs.md",
          "label": "Specs"
        },
        {
          "file": "./content/subjects/linux/linux_api.md",
          "label": "API"
        },
        {
          "file": "./content/subjects/linux/linux_git.md",
          "label": "Git"
        },
        {
          "file": "./content/subjects/linux/linux_gnome.md",
          "label": "GNOME"
        },
        {
          "file": "./content/subjects/linux/linux_anticheat_proton.md",
          "label": "Anti-Cheat & Proton"
        },
        {
          "file": "./content/subjects/linux/linux_wine_proton.md",
          "label": "Wine & Proton"
        },
        {
          "file": "./content/subjects/linux/linux_lockdown_browser.md",
          "label": "Lockdown Browser"
        }
      ],
      "references": [
        {
          "file": "cosc/linux/linux_reference.html",
          "label": "Linux History & Reference",
          "type": "iframe"
        },
        {
          "file": "cosc/linux/linux_quick.html",
          "label": "Linux Quick Reference",
          "type": "iframe"
        }
      ],
      "assignments": [],
      "code": [],
      "flashcards": null,
      "pdfs": [],
      "langRefs": true,
      "gopal": [],
      "dept": "cosc",
      "deptLabel": "COSC"
    },
    {
      "id": "cpp",
      "label": "C++",
      "courseCode": "COSC 1437",
      "color": "#fb923c",
      "icon": "{}",
      "notes": [
        {
          "file": "./content/subjects/cpp/listcpp.md",
          "label": "Notes I"
        },
        {
          "file": "./content/subjects/cpp/listcpp_2.md",
          "label": "Notes II"
        },
        {
          "file": "./content/subjects/cpp/listcpp_3.md",
          "label": "Notes III"
        },
        {
          "file": "./content/subjects/cpp/zycpp.md",
          "label": "Zybook Notes"
        },
        {
          "file": "./content/subjects/cpp/cpp_concepts.md",
          "label": "Core Concepts"
        },
        {
          "file": "./content/subjects/cpp/cpp_adt.md",
          "label": "ADTs in C++"
        },
        {
          "file": "./content/subjects/cpp/cpp_compile_run.md",
          "label": "Compile & Run"
        },
        {
          "file": "./content/subjects/cpp/cpp_malloc.md",
          "label": "Malloc & Memory"
        },
        {
          "file": "./content/subjects/cpp/cpp_poly_inheritance.md",
          "label": "Polymorphism & Inheritance"
        },
        {
          "file": "./content/subjects/cpp/cpp_static_auto.md",
          "label": "Static & Auto"
        },
        {
          "file": "./content/subjects/cpp/cpp_symbols.md",
          "label": "Symbols"
        },
        {
          "file": "./content/subjects/cpp/cpp_ting.md",
          "label": "Ting"
        },
        {
          "file": "./content/subjects/cpp/cpp_tong.md",
          "label": "Tong"
        }
      ],
      "references": [
        {
          "file": "cosc/cpp/cpp_reference.html",
          "label": "C++ History & Reference",
          "type": "iframe"
        },
        {
          "file": "cosc/cpp/cpp_reference.html",
          "label": "C++ Quick Reference",
          "type": "iframe"
        }
      ],
      "assignments": [],
      "code": [],
      "flashcards": "prog_fundamentals",
      "pdfs": [
        {
          "file": "cpp_notes.pdf",
          "label": "C++ Merged Textbook"
        },
        {
          "file": "cpp_rpg_project.pdf",
          "label": "RPG Project"
        }
      ],
      "langRefs": true,
      "gopal": [],
      "dept": "cosc",
      "deptLabel": "COSC"
    },
    {
      "id": "python",
      "label": "Python",
      "courseCode": null,
      "color": "#4ecdc4",
      "icon": "𝜆",
      "notes": [],
      "references": [
        {
          "file": "languages/python_reference.html",
          "label": "Python History & Reference",
          "type": "iframe"
        },
        {
          "file": "languages/python_reference.html",
          "label": "Python Quick Reference",
          "type": "iframe"
        }
      ],
      "assignments": [],
      "code": [],
      "flashcards": null,
      "pdfs": [],
      "langRefs": true,
      "gopal": [],
      "dept": "cosc",
      "deptLabel": "COSC"
    },
    {
      "id": "ai",
      "label": "AI & LLMs",
      "courseCode": null,
      "color": "#a78bfa",
      "icon": "◎",
      "notes": [
        {
          "file": "ai/introtollms.md",
          "label": "Intro to LLMs"
        },
        {
          "file": "ai/transformers.md",
          "label": "Transformers"
        },
        {
          "file": "ai/agents.md",
          "label": "Agents"
        },
        {
          "file": "ai/transformer.svg",
          "label": "Transformer Architecture (SVG)"
        }
      ],
      "references": [
        {
          "file": "ai/llms_intro.html",
          "label": "Intro to LLMs",
          "type": "iframe"
        },
        {
          "file": "ai/llm_explained.html",
          "label": "LLM Explained",
          "type": "iframe"
        },
        {
          "file": "ai/machine_learning.html",
          "label": "Machine Learning",
          "type": "iframe"
        },
        {
          "file": "ai/deep_learning.html",
          "label": "Deep Learning",
          "type": "iframe"
        },
        {
          "type": "group",
          "label": "Agents",
          "children": [
            {
              "file": "ai/ai_agents.html",
              "label": "AI Agents",
              "type": "iframe"
            },
            {
              "file": "ai/agents_guide.html",
              "label": "Agents Guide",
              "type": "iframe"
            }
          ]
        },
        {
          "file": "ai/ai_landscape.html",
          "label": "AI Landscape",
          "type": "iframe"
        }
      ],
      "assignments": [],
      "code": [],
      "flashcards": null,
      "pdfs": [],
      "gopal": [],
      "dept": "cosc",
      "deptLabel": "COSC"
    },
    {
      "id": "algebra",
      "label": "Algebra",
      "courseCode": null,
      "color": "#e8c547",
      "icon": "x²",
      "notes": [],
      "references": [
        {
          "file": "math/notation/math_science.html",
          "label": "Math & Science Ref",
          "type": "iframe"
        }
      ],
      "assignments": [],
      "code": [],
      "flashcards": null,
      "pdfs": [],
      "gopal": [],
      "dept": "math",
      "deptLabel": "MATH"
    },
    {
      "id": "precalc",
      "label": "Pre-Calculus",
      "courseCode": null,
      "color": "#fb923c",
      "icon": "∠",
      "notes": [],
      "references": [
        {
          "file": "math/notation/math_science.html",
          "label": "Math & Science Ref",
          "type": "iframe"
        }
      ],
      "assignments": [],
      "code": [],
      "flashcards": null,
      "pdfs": [],
      "gopal": [],
      "dept": "math",
      "deptLabel": "MATH"
    },
    {
      "id": "calc1",
      "label": "Calculus I",
      "courseCode": null,
      "color": "#4ecdc4",
      "icon": "∫",
      "notes": [],
      "references": [
        {
          "file": "math/notation/math_science.html",
          "label": "Math & Science Ref",
          "type": "iframe"
        }
      ],
      "assignments": [],
      "code": [],
      "flashcards": null,
      "pdfs": [],
      "gopal": [],
      "dept": "math",
      "deptLabel": "MATH"
    },
    {
      "id": "calc2",
      "label": "Calculus II",
      "courseCode": null,
      "color": "#4ecdc4",
      "icon": "∬",
      "notes": [],
      "references": [
        {
          "file": "math/notation/math_science.html",
          "label": "Math & Science Ref",
          "type": "iframe"
        }
      ],
      "assignments": [],
      "code": [],
      "flashcards": null,
      "pdfs": [],
      "gopal": [],
      "dept": "math",
      "deptLabel": "MATH"
    },
    {
      "id": "discrete",
      "label": "Discrete Math",
      "courseCode": "COSC 2303",
      "color": "#a78bfa",
      "icon": "∑",
      "notes": [
        {
          "file": "./content/subjects/discrete/list.md",
          "label": "Main Notes"
        },
        {
          "file": "./content/subjects/discrete/asymptotic.md",
          "label": "Asymptotic Notation"
        },
        {
          "file": "./content/subjects/discrete/combperm.md",
          "label": "Combinatorics & Permutations"
        },
        {
          "file": "./content/subjects/discrete/proofs/proofs.md",
          "label": "Proofs"
        },
        {
          "file": "./content/notes/math_notation.md",
          "label": "Math Notation Notes"
        }
      ],
      "references": [
        {
          "file": "math/discrete/discrete_math.html",
          "label": "Discrete Math Guide",
          "type": "iframe"
        },
        {
          "file": "math/notation/math_notation.html",
          "label": "Math Notation",
          "type": "iframe"
        },
        {
          "file": "math/notation/math_science.html",
          "label": "Math & Science Ref",
          "type": "iframe"
        },
        {
          "file": "math/notation/math_notation_simple.html",
          "label": "Math Notation (Simple)",
          "type": "iframe"
        }
      ],
      "assignments": [],
      "code": [],
      "flashcards": null,
      "pdfs": [
        {
          "file": "discrete_textbook.pdf",
          "label": "Discrete Math Textbook"
        },
        {
          "file": "discrete_notes.pdf",
          "label": "Discrete Notes"
        },
        {
          "file": "discrete_exam1.pdf",
          "label": "Exam 1"
        },
        {
          "file": "discrete_exam2.pdf",
          "label": "Exam 2"
        }
      ],
      "gopal": [],
      "dept": "math",
      "deptLabel": "MATH"
    },
    {
      "id": "linear",
      "label": "Linear Algebra",
      "courseCode": "MATH 2318",
      "color": "#f472b6",
      "icon": "[]",
      "notes": [
        {
          "file": "./content/notes/linear/list.md",
          "label": "Main Notes"
        },
        {
          "file": "./content/notes/practice/linearhwto5.md",
          "label": "HW1-5 Reference"
        },
        {
          "file": "./content/notes/practice/2318E1.md",
          "label": "Exam 1 Practice"
        }
      ],
      "references": [
        {
          "file": "math/linear/linear_algebra.html",
          "label": "Linear Algebra Guide",
          "type": "iframe"
        },
        {
          "file": "math/notation/math_notation.html",
          "label": "Math Notation",
          "type": "iframe"
        },
        {
          "file": "./content/subjects/linear/linear_template.html",
          "label": "linear template"
        },
        {
          "file": "math/notation/math_notation_simple.html",
          "label": "Math Notation (Simple)",
          "type": "iframe"
        }
      ],
      "assignments": [
        {
          "file": "./content/assignments/linear/hw1.html",
          "label": "HW1",
          "type": "content"
        },
        {
          "file": "./content/assignments/linear/hw2.html",
          "label": "HW2",
          "type": "content"
        },
        {
          "file": "./content/assignments/linear/hw3.html",
          "label": "HW3",
          "type": "content"
        },
        {
          "file": "./content/assignments/linear/hw4.html",
          "label": "HW4 — Vector Spaces",
          "type": "content"
        },
        {
          "file": "./content/assignments/linear/hw5.html",
          "label": "HW5 — Linear Operators",
          "type": "content"
        },
        {
          "file": "./content/assignments/linear/exam1_review.html",
          "label": "Exam 1 Review",
          "type": "content"
        },
        {
          "file": "./content/assignments/linear/exam_checklist.html",
          "label": "Exam Checklist",
          "type": "content"
        },
        {
          "file": "./content/subjects/linear/linear_template.html",
          "label": "linear template"
        },
        {
          "file": "./content/practice/linear_exam1.html",
          "label": "Exam 1 Practice",
          "type": "content"
        },
        {
          "type": "group",
          "label": "Old Exam",
          "children": [
            {
              "file": "./content/assignments/linear/exam2_final.html",
              "label": "math2318 exam2 FINAL v2",
              "type": "content"
            },
            {
              "file": "./content/assignments/linear/exam1_old.html",
              "label": "math2318 OLD exam1 solutions",
              "type": "content"
            },
            {
              "file": "./content/assignments/linear/final_sp24.html",
              "label": "linear final sp24 solutions",
              "type": "content"
            }
          ]
        },
        {
          "type": "group",
          "label": "Exam",
          "children": [
            {
              "file": "./content/assignments/linear/exam1_sp26.html",
              "label": "math2318 exam1 sp26 solutions",
              "type": "content"
            }
          ]
        }
      ],
      "code": [],
      "flashcards": null,
      "pdfs": [
        {
          "type": "group",
          "label": "OldExams",
          "children": [
            {
              "file": "linear_exam1_sp25.pdf",
              "label": "Linear Spring25Exam1"
            },
            {
              "file": "linear_exam2_sp25.pdf",
              "label": "Linear Spring25Exam2"
            },
            {
              "file": "linear_final_sp25.pdf",
              "label": "Linear Spring25FinalExam"
            }
          ]
        },
        {
          "file": "linear_textbook.pdf",
          "label": "Linear Algebra Textbook"
        },
        {
          "type": "group",
          "label": "NewExam",
          "children": [
            {
              "file": "linear_exams_1_to_3.pdf",
              "label": "Linear Exam1 3"
            }
          ]
        }
      ],
      "gopal": [],
      "dept": "math",
      "deptLabel": "MATH"
    },
    {
      "id": "stats",
      "label": "Statistics",
      "courseCode": null,
      "color": "#a78bfa",
      "icon": "σ",
      "notes": [],
      "references": [
        {
          "file": "math/stats/statistics.html",
          "label": "Statistics Reference",
          "type": "iframe"
        }
      ],
      "assignments": [],
      "code": [],
      "flashcards": null,
      "pdfs": [
        {
          "file": "stats_lectures.pdf",
          "label": "All Lectures"
        }
      ],
      "gopal": [],
      "dept": "math",
      "deptLabel": "MATH"
    }
  ];
