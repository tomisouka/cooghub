const e=`3340 Automata
3320 Algos
2318 Linear Algebra
Algo Workshop
1501 French

I know that there are textbooks for all of this.

Root: This is where i start always, when i have a routine i bypass root to a routine that is doing
or reviewing.

Routine: Past thinking a repetitive doing or reviewing, anki for example.
Reading is what I call the root routine, because it is always to be done, there is nothing to 
lose from it. Skimming is something we want to get better at, it is effective reading. 
We are reading for information not entertainment. Efficiency is our goal. 

Brainstorming is starting to feel like root, so now these two will be synonymous. because you
will always have to brainstorm and question before getting to the others.

Brainstorming = Root (/) = Questioning

Routine = read when all else fails then question
Root Routine = Book
Cause when your root becomes dry you need to read and feed it. 

Starting at / 
Accessing to Root Routine

There is no home for now. 

Now I'll end here with the biggest questions for the corresponding subjects

3340 
State diagrams and states, but where are we looking up from? Has this been brought to life?
3320
What am i most comfortable with and least comfortable with.
`;export{e as default};
