const e=`Quick mental model 🧠

Compile-time → your code is checked, stack size known

Runtime → program executes, heap memory allocated dynamically
`;export{e as default};
