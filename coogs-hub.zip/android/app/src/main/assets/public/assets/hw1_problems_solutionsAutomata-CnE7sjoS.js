const n=`<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>HW1 — COSC 3340 Automata</title>
<link href="https://fonts.googleapis.com/css2?family=IBM+Plex+Mono:ital,wght@0,400;0,600;1,400&family=Space+Grotesk:wght@300;400;600;700&display=swap" rel="stylesheet">
<style>
  :root {
    --bg: #0a0e17;
    --surface: #111827;
    --border: #1f2d45;
    --accent: #00d4ff;
    --accent2: #7c3aed;
    --green: #10b981;
    --amber: #f59e0b;
    --text: #e2e8f0;
    --muted: #64748b;
    --card: #131c2e;
  }

  * { box-sizing: border-box; margin: 0; padding: 0; }

  body {
    background: var(--bg);
    color: var(--text);
    font-family: 'Space Grotesk', sans-serif;
    min-height: 100vh;
    background-image: 
      radial-gradient(ellipse at 20% 10%, rgba(0,212,255,0.05) 0%, transparent 50%),
      radial-gradient(ellipse at 80% 90%, rgba(124,58,237,0.05) 0%, transparent 50%);
  }

  header {
    border-bottom: 1px solid var(--border);
    padding: 2rem 3rem;
    display: flex;
    align-items: center;
    gap: 1.5rem;
    background: rgba(17,24,39,0.8);
    backdrop-filter: blur(10px);
    position: sticky;
    top: 0;
    z-index: 100;
  }

  .badge {
    font-family: 'IBM Plex Mono', monospace;
    font-size: 0.7rem;
    font-weight: 600;
    letter-spacing: 0.1em;
    padding: 0.3rem 0.8rem;
    border-radius: 2px;
    text-transform: uppercase;
  }
  .badge-hw { background: rgba(0,212,255,0.15); color: var(--accent); border: 1px solid rgba(0,212,255,0.3); }
  .badge-due { background: rgba(245,158,11,0.15); color: var(--amber); border: 1px solid rgba(245,158,11,0.3); }

  h1 { font-size: 1.4rem; font-weight: 700; letter-spacing: -0.02em; }
  .header-meta { display: flex; align-items: center; gap: 0.75rem; flex-wrap: wrap; }

  .container { max-width: 900px; margin: 0 auto; padding: 3rem 2rem; }

  .toc {
    background: var(--card);
    border: 1px solid var(--border);
    border-left: 3px solid var(--accent);
    border-radius: 4px;
    padding: 1.5rem;
    margin-bottom: 3rem;
    font-family: 'IBM Plex Mono', monospace;
    font-size: 0.85rem;
  }
  .toc-title { font-size: 0.7rem; letter-spacing: 0.1em; text-transform: uppercase; color: var(--accent); margin-bottom: 0.75rem; }
  .toc a { color: var(--muted); text-decoration: none; display: block; padding: 0.2rem 0; transition: color 0.2s; }
  .toc a:hover { color: var(--text); }
  .toc a::before { content: '→ '; color: var(--accent); }

  .problem-block {
    margin-bottom: 2.5rem;
    border: 1px solid var(--border);
    border-radius: 6px;
    overflow: hidden;
    transition: border-color 0.2s;
  }
  .problem-block:hover { border-color: rgba(0,212,255,0.3); }

  .problem-header {
    display: flex;
    align-items: center;
    gap: 1rem;
    padding: 1rem 1.5rem;
    background: var(--card);
    cursor: pointer;
    user-select: none;
    border-bottom: 1px solid var(--border);
  }
  .problem-header:hover { background: rgba(19,28,46,0.8); }

  .q-num {
    font-family: 'IBM Plex Mono', monospace;
    font-size: 0.75rem;
    font-weight: 600;
    color: var(--accent);
    background: rgba(0,212,255,0.1);
    border: 1px solid rgba(0,212,255,0.2);
    padding: 0.2rem 0.6rem;
    border-radius: 2px;
    min-width: 3rem;
    text-align: center;
    flex-shrink: 0;
  }

  .problem-title { font-weight: 600; flex: 1; }
  .chevron { color: var(--muted); transition: transform 0.3s; font-size: 0.8rem; }
  .problem-block.open .chevron { transform: rotate(180deg); }

  .problem-body { padding: 1.5rem; }

  .problem-text {
    background: rgba(0,0,0,0.2);
    border-left: 3px solid var(--muted);
    padding: 1rem 1.2rem;
    border-radius: 0 4px 4px 0;
    margin-bottom: 1.5rem;
    font-size: 0.95rem;
    line-height: 1.7;
    color: #94a3b8;
  }

  .solution-label {
    font-family: 'IBM Plex Mono', monospace;
    font-size: 0.65rem;
    letter-spacing: 0.12em;
    text-transform: uppercase;
    color: var(--green);
    margin-bottom: 0.75rem;
    display: flex;
    align-items: center;
    gap: 0.5rem;
  }
  .solution-label::before { content: ''; display: block; width: 1.5rem; height: 1px; background: var(--green); }

  .solution-text {
    font-size: 0.95rem;
    line-height: 1.8;
    color: var(--text);
  }

  .solution-text p { margin-bottom: 0.8rem; }
  .solution-text strong { color: var(--accent); font-weight: 600; }
  .solution-text em { color: var(--amber); font-style: italic; }

  .math-block {
    font-family: 'IBM Plex Mono', monospace;
    background: rgba(0,0,0,0.3);
    border: 1px solid var(--border);
    border-radius: 4px;
    padding: 1rem 1.5rem;
    margin: 1rem 0;
    font-size: 0.88rem;
    overflow-x: auto;
    color: #a5b4fc;
    line-height: 1.6;
  }

  .automaton-viz {
    background: var(--card);
    border: 1px solid var(--border);
    border-radius: 4px;
    padding: 1.5rem;
    margin: 1rem 0;
    font-family: 'IBM Plex Mono', monospace;
    font-size: 0.8rem;
  }
  .automaton-viz-title {
    font-size: 0.65rem;
    letter-spacing: 0.1em;
    text-transform: uppercase;
    color: var(--accent2);
    margin-bottom: 1rem;
  }

  table {
    width: 100%;
    border-collapse: collapse;
    margin: 1rem 0;
    font-size: 0.88rem;
  }
  th {
    background: rgba(0,212,255,0.08);
    color: var(--accent);
    font-family: 'IBM Plex Mono', monospace;
    font-size: 0.75rem;
    letter-spacing: 0.05em;
    padding: 0.6rem 1rem;
    text-align: left;
    border-bottom: 1px solid var(--border);
  }
  td {
    padding: 0.6rem 1rem;
    border-bottom: 1px solid rgba(31,45,69,0.5);
    font-family: 'IBM Plex Mono', monospace;
    font-size: 0.82rem;
  }
  tr:last-child td { border-bottom: none; }
  tr:hover td { background: rgba(255,255,255,0.02); }
  .accept-state { color: var(--green); font-weight: 600; }
  .start-state { color: var(--amber); }
  .dead-state { color: #ef4444; }

  .key-insight {
    background: linear-gradient(135deg, rgba(124,58,237,0.08), rgba(0,212,255,0.05));
    border: 1px solid rgba(124,58,237,0.3);
    border-radius: 4px;
    padding: 1rem 1.2rem;
    margin: 1rem 0;
    font-size: 0.9rem;
  }
  .key-insight-label {
    font-family: 'IBM Plex Mono', monospace;
    font-size: 0.65rem;
    letter-spacing: 0.1em;
    text-transform: uppercase;
    color: var(--accent2);
    margin-bottom: 0.4rem;
  }

  .qed {
    text-align: right;
    font-family: 'IBM Plex Mono', monospace;
    color: var(--green);
    font-size: 0.9rem;
    margin-top: 0.5rem;
  }

  .jflap-sim {
    background: #0d1117;
    border: 1px solid #30363d;
    border-radius: 4px;
    padding: 1.5rem;
    margin: 1rem 0;
    position: relative;
    overflow: hidden;
  }
  .jflap-sim::before {
    content: 'JFLAP SIMULATION';
    position: absolute;
    top: 0.6rem;
    right: 0.8rem;
    font-family: 'IBM Plex Mono', monospace;
    font-size: 0.6rem;
    letter-spacing: 0.1em;
    color: #484f58;
  }

  svg.dfa-diagram { width: 100%; max-width: 600px; display: block; margin: 0 auto; }

  footer {
    text-align: center;
    padding: 2rem;
    font-family: 'IBM Plex Mono', monospace;
    font-size: 0.7rem;
    color: var(--muted);
    border-top: 1px solid var(--border);
    margin-top: 4rem;
  }
</style>
</head>
<body>

<header>
  <div class="header-meta">
    <span class="badge badge-hw">HW 1</span>
    <h1>Homework 1 — Foundations & Automata</h1>
    <span class="badge badge-due">Due Feb 6, 2026</span>
  </div>
</header>

<div class="container">
  <div class="toc">
    <div class="toc-title">Problems</div>
    <a href="#q1">Q1 — Countability of Finite Subsets of N</a>
    <a href="#q2">Q2 — Uncountability of Infinite Subsets of N</a>
    <a href="#q3">Q3 — Erdős–Szekeres: Monotone Subsequences</a>
    <a href="#q4">Q4 — Every DFA is an NFA</a>
    <a href="#q5">Q5 — n = 5a + 6b for all n ≥ 20</a>
    <a href="#q6">Q6 — NFA with ε-transitions → DFA Conversion</a>
  </div>

  <!-- Q1 -->
  <div class="problem-block open" id="q1">
    <div class="problem-header" onclick="toggle(this)">
      <span class="q-num">Q1</span>
      <span class="problem-title">Countability of All Finite Subsets of ℕ</span>
      <span class="chevron">▼</span>
    </div>
    <div class="problem-body">
      <div class="problem-text">
        Show that the set of all finite subsets of the set of natural numbers ℕ = {0, 1, 2, …} is countably infinite.
      </div>
      <div class="solution-label">Solution</div>
      <div class="solution-text">
        <p>Let ℱ denote the set of all finite subsets of ℕ. We must show |ℱ| = |ℕ|.</p>

        <p><strong>ℱ is infinite:</strong> For each n ∈ ℕ, the singleton {n} ∈ ℱ. The map n ↦ {n} is injective, so ℱ is infinite.</p>

        <p><strong>ℱ is countable — encoding argument:</strong> Define a function f : ℱ → ℕ by encoding each finite subset as a natural number using binary representation:</p>

        <div class="math-block">
For S = {a₁ < a₂ < … < aₖ} ∈ ℱ, define:
  f(S) = 2^a₁ + 2^a₂ + … + 2^aₖ
  f(∅) = 0

Examples:
  f(∅) = 0
  f({0}) = 1
  f({1}) = 2
  f({0,1}) = 3
  f({2}) = 4
  f({0,2}) = 5  ...
        </div>

        <p>Since binary representations of natural numbers are unique, f is injective: distinct finite subsets map to distinct naturals. So ℱ injects into ℕ, giving |ℱ| ≤ |ℕ|.</p>

        <p>Since ℱ is infinite and |ℱ| ≤ |ℕ|, we conclude ℱ is countably infinite. □</p>
        <div class="qed">□</div>
      </div>
    </div>
  </div>

  <!-- Q2 -->
  <div class="problem-block open" id="q2">
    <div class="problem-header" onclick="toggle(this)">
      <span class="q-num">Q2</span>
      <span class="problem-title">Uncountability of All Infinite Subsets of ℕ</span>
      <span class="chevron">▼</span>
    </div>
    <div class="problem-body">
      <div class="problem-text">
        Show that the set of all infinite subsets of the set of natural numbers is uncountable.
      </div>
      <div class="solution-label">Solution</div>
      <div class="solution-text">
        <p>Let ℐ denote the set of all infinite subsets of ℕ.</p>

        <p><strong>Key facts:</strong></p>
        <p>1. The power set 𝒫(ℕ) is <em>uncountable</em> by Cantor's theorem.</p>
        <p>2. 𝒫(ℕ) = ℱ ∪ ℐ (every subset is either finite or infinite, and the sets are disjoint).</p>
        <p>3. ℱ is <em>countable</em> by Q1.</p>

        <p><strong>Proof by contradiction:</strong> Suppose ℐ were countable. Then:</p>

        <div class="math-block">
𝒫(ℕ) = ℱ ∪ ℐ
      = (countable) ∪ (countable)   [by assumption]
      = countable                    [union of countables is countable]
        </div>

        <p>But this contradicts the fact that 𝒫(ℕ) is uncountable. Therefore our assumption is false, and <strong>ℐ must be uncountable</strong>.</p>
        <div class="qed">□</div>
      </div>
    </div>
  </div>

  <!-- Q3 -->
  <div class="problem-block open" id="q3">
    <div class="problem-header" onclick="toggle(this)">
      <span class="q-num">Q3</span>
      <span class="problem-title">Erdős–Szekeres: Every n²+1 Sequence Has a Monotone Subsequence of n+1</span>
      <span class="chevron">▼</span>
    </div>
    <div class="problem-body">
      <div class="problem-text">
        Prove that every sequence of n² + 1 distinct natural numbers has either a descending subsequence of n + 1 numbers or an ascending subsequence of n + 1 numbers.
      </div>
      <div class="solution-label">Solution — Pigeonhole Argument</div>
      <div class="solution-text">
        <p>Let a₁, a₂, …, a_{n²+1} be a sequence of n² + 1 distinct natural numbers.</p>

        <p><strong>Define:</strong> For each element aᵢ, let dᵢ = the length of the longest <em>descending</em> subsequence starting at aᵢ.</p>

        <p><strong>Assume for contradiction</strong> that there is no descending subsequence of length n+1 and no ascending subsequence of length n+1. Then dᵢ ≤ n for all i.</p>

        <div class="math-block">
Each dᵢ ∈ {1, 2, …, n}  (n possible values)
There are n² + 1 elements  →  by Pigeonhole, two positions
share the same dᵢ value:

∃ i < j such that dᵢ = dⱼ
        </div>

        <p><strong>Case analysis on aᵢ vs aⱼ (recall i < j):</strong></p>

        <p><strong>Case 1: aᵢ > aⱼ.</strong> Then we can prepend aᵢ to the longest descending subsequence starting at aⱼ. This gives a descending subsequence starting at aᵢ of length dⱼ + 1 = dᵢ + 1 — contradicting dᵢ = dⱼ.</p>

        <p><strong>Case 2: aᵢ < aⱼ.</strong> Then aᵢ, aⱼ begins an ascending pair. By the same argument applied to ascending subsequences (define uᵢ = longest ascending from aᵢ), we derive a contradiction with uᵢ = uⱼ.</p>

        <p>Since all cases lead to contradiction, our assumption is false. Therefore every such sequence has a descending subsequence of length n+1 <em>or</em> an ascending one of length n+1.</p>
        <div class="qed">□</div>
      </div>
    </div>
  </div>

  <!-- Q4 -->
  <div class="problem-block open" id="q4">
    <div class="problem-header" onclick="toggle(this)">
      <span class="q-num">Q4</span>
      <span class="problem-title">Is Every DFA Also an NFA?</span>
      <span class="chevron">▼</span>
    </div>
    <div class="problem-body">
      <div class="problem-text">
        Is every DFA also an NFA? Justify your answer.
      </div>
      <div class="solution-label">Solution</div>
      <div class="solution-text">
        <p><strong>Yes</strong> — every DFA is a special case of an NFA.</p>

        <p><strong>Recall the definitions:</strong></p>

        <div class="math-block">
DFA M = (Q, Σ, δ, q₀, F)  where  δ: Q × Σ → Q
NFA M = (Q, Σ, δ, q₀, F)  where  δ: Q × (Σ ∪ {ε}) → 𝒫(Q)
        </div>

        <p>A DFA's transition function δ(q, a) = q' (exactly one next state) can be viewed as an NFA's transition function δ_NFA(q, a) = {q'} (a singleton set).</p>

        <p>The NFA definition allows:</p>
        <p>• Transitions to a <em>set</em> of states (DFA uses singleton sets) ✓</p>
        <p>• ε-transitions (DFA simply has none — all ε-transitions go to ∅) ✓</p>

        <div class="key-insight">
          <div class="key-insight-label">Key Insight</div>
          Every DFA is an NFA where: (1) all transitions go to singleton sets {q'}, and (2) all ε-transitions are δ(q, ε) = ∅. The class of DFAs ⊂ class of NFAs.
        </div>

        <p>Conversely, not every NFA is a DFA — NFAs may have multiple transitions or ε-transitions that DFAs cannot.</p>
        <div class="qed">□</div>
      </div>
    </div>
  </div>

  <!-- Q5 -->
  <div class="problem-block open" id="q5">
    <div class="problem-header" onclick="toggle(this)">
      <span class="q-num">Q5</span>
      <span class="problem-title">Every n ≥ 20 can be written as 5a + 6b</span>
      <span class="chevron">▼</span>
    </div>
    <div class="problem-body">
      <div class="problem-text">
        Prove that every integer n ≥ 20 can be written in the form n = 5a + 6b, where a and b are non-negative integers.
      </div>
      <div class="solution-label">Solution — Strong Induction</div>
      <div class="solution-text">
        <p><strong>Base cases</strong> (establish n = 20 through 24):</p>
        <div class="math-block">
n = 20: 5(4) + 6(0) = 20  ✓
n = 21: 5(3) + 6(1) = 21  ✓
n = 22: 5(2) + 6(2) = 22  ✓
n = 23: 5(1) + 6(3) = 23  ✓
n = 24: 5(0) + 6(4) = 24  ✓
        </div>

        <p><strong>Inductive Hypothesis:</strong> Assume every integer from 20 to k (for some k ≥ 24) can be written as 5a + 6b with a, b ≥ 0.</p>

        <p><strong>Inductive Step:</strong> Show k + 1 can also be written this way.</p>

        <div class="math-block">
Since k ≥ 24:  k + 1 ≥ 25  →  k + 1 − 5 = k − 4 ≥ 20

By the inductive hypothesis applied to (k − 4):
  k − 4 = 5a + 6b  for some a, b ≥ 0

Therefore:
  k + 1 = (k − 4) + 5 = 5a + 6b + 5 = 5(a+1) + 6b  ✓

Since a + 1 ≥ 1 > 0 and b ≥ 0, both are non-negative.
        </div>

        <p>By strong induction, every n ≥ 20 can be written as 5a + 6b.</p>
        <div class="qed">□</div>
      </div>
    </div>
  </div>

  <!-- Q6 -->
  <div class="problem-block open" id="q6">
    <div class="problem-header" onclick="toggle(this)">
      <span class="q-num">Q6</span>
      <span class="problem-title">NFA with ε-transitions → Equivalent DFA</span>
      <span class="chevron">▼</span>
    </div>
    <div class="problem-body">
      <div class="problem-text">
        Convert the NFA M = ({q0, q1, q2}, {a,b}, δ, q0, {q2}) with transitions:<br>
        q0 →a {q0}, q0 →b {q0}, q0 →ε {q1};<br>
        q1 →a {q2};<br>
        q2 →a {q2}, q2 →b {q2}
      </div>
      <div class="solution-label">Step 1 — Compute ε-closures</div>
      <div class="solution-text">
        <div class="math-block">
ε-closure(q0) = {q0, q1}   (q0 has ε-transition to q1)
ε-closure(q1) = {q1}       (no ε-transitions from q1)
ε-closure(q2) = {q2}       (no ε-transitions from q2)
        </div>

        <div class="solution-label">Step 2 — Subset Construction</div>

        <p>Start state of DFA = ε-closure(q0) = <strong>{q0, q1}</strong></p>

        <table>
          <tr>
            <th>DFA State</th>
            <th>On 'a'</th>
            <th>On 'b'</th>
            <th>Accept?</th>
          </tr>
          <tr>
            <td class="start-state">A = {q0, q1} ← start</td>
            <td>ε-cl(δ(q0,a) ∪ δ(q1,a)) = ε-cl({q0} ∪ {q2}) = {q0, q1, q2}</td>
            <td>ε-cl(δ(q0,b) ∪ δ(q1,b)) = ε-cl({q0} ∪ ∅) = {q0, q1}</td>
            <td>No</td>
          </tr>
          <tr>
            <td class="accept-state">B = {q0, q1, q2} ← accept</td>
            <td>ε-cl({q0} ∪ {q2} ∪ {q2}) = {q0, q1, q2}</td>
            <td>ε-cl({q0} ∪ ∅ ∪ {q2}) = {q0, q1, q2}</td>
            <td><span class="accept-state">Yes (contains q2)</span></td>
          </tr>
        </table>

        <div class="solution-label">DFA Transition Table (Final)</div>
        <table>
          <tr><th>State</th><th>a</th><th>b</th></tr>
          <tr><td class="start-state">A (start)</td><td>B</td><td>A</td></tr>
          <tr><td class="accept-state">B (accept)</td><td>B</td><td>B</td></tr>
        </table>

        <div class="jflap-sim">
          <svg class="dfa-diagram" viewBox="0 0 520 180" fill="none" xmlns="http://www.w3.org/2000/svg">
            <!-- Arrow from start -->
            <line x1="30" y1="90" x2="90" y2="90" stroke="#64748b" stroke-width="1.5" marker-end="url(#arr)"/>
            <text x="20" y="85" font-family="monospace" font-size="11" fill="#64748b">→</text>
            
            <!-- State A -->
            <circle cx="130" cy="90" r="35" stroke="#f59e0b" stroke-width="1.5" fill="rgba(245,158,11,0.05)"/>
            <text x="130" y="86" text-anchor="middle" font-family="monospace" font-size="13" fill="#f59e0b" font-weight="600">A</text>
            <text x="130" y="102" text-anchor="middle" font-family="monospace" font-size="9" fill="#64748b">{q0,q1}</text>

            <!-- b self-loop on A -->
            <path d="M115 57 Q100 30 130 20 Q160 30 145 57" stroke="#64748b" stroke-width="1.5" fill="none" marker-end="url(#arr)"/>
            <text x="128" y="15" text-anchor="middle" font-family="monospace" font-size="12" fill="#94a3b8">b</text>

            <!-- A → B on a -->
            <line x1="165" y1="90" x2="335" y2="90" stroke="#00d4ff" stroke-width="1.5" marker-end="url(#arr2)"/>
            <text x="250" y="83" text-anchor="middle" font-family="monospace" font-size="12" fill="#00d4ff">a</text>

            <!-- State B (double circle = accept) -->
            <circle cx="375" cy="90" r="35" stroke="#10b981" stroke-width="1.5" fill="rgba(16,185,129,0.05)"/>
            <circle cx="375" cy="90" r="30" stroke="#10b981" stroke-width="0.7" fill="none"/>
            <text x="375" y="86" text-anchor="middle" font-family="monospace" font-size="13" fill="#10b981" font-weight="600">B</text>
            <text x="375" y="102" text-anchor="middle" font-family="monospace" font-size="9" fill="#64748b">{q0,q1,q2}</text>

            <!-- a,b self-loop on B -->
            <path d="M360 57 Q345 20 375 10 Q405 20 390 57" stroke="#10b981" stroke-width="1.5" fill="none" marker-end="url(#arr3)"/>
            <text x="375" y="6" text-anchor="middle" font-family="monospace" font-size="12" fill="#10b981">a, b</text>

            <defs>
              <marker id="arr" markerWidth="8" markerHeight="8" refX="6" refY="3" orient="auto">
                <path d="M0,0 L0,6 L8,3 z" fill="#64748b"/>
              </marker>
              <marker id="arr2" markerWidth="8" markerHeight="8" refX="6" refY="3" orient="auto">
                <path d="M0,0 L0,6 L8,3 z" fill="#00d4ff"/>
              </marker>
              <marker id="arr3" markerWidth="8" markerHeight="8" refX="6" refY="3" orient="auto">
                <path d="M0,0 L0,6 L8,3 z" fill="#10b981"/>
              </marker>
            </defs>
          </svg>
        </div>

        <div class="key-insight">
          <div class="key-insight-label">Language Recognized</div>
          This DFA accepts any string over {a,b} that contains at least one 'a'. This is because the NFA non-deterministically takes the ε-transition q0→q1 and then reads an 'a' to reach q2 (accept). Once q2 is reached, all further input is accepted.
        </div>
      </div>
    </div>
  </div>

</div>

<footer>COSC 3340 — Spring 2026 · Dr. Rakesh Verma, Vu Minh H. Dang, Bryan Tuck</footer>

<script>
function toggle(header) {
  const block = header.closest('.problem-block');
  block.classList.toggle('open');
  const body = block.querySelector('.problem-body');
  if (block.classList.contains('open')) {
    body.style.display = 'block';
  } else {
    body.style.display = 'none';
  }
}
// All open by default - handled in CSS/HTML already
<\/script>

</body>
</html>
`;export{n as default};
