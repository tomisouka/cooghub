const n=`<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8"/>
<meta name="viewport" content="width=device-width, initial-scale=1.0"/>
<title>Linear Algebra — HW 3</title>
<link href="https://fonts.googleapis.com/css2?family=Playfair+Display:ital,wght@0,400;0,600;1,400&family=JetBrains+Mono:wght@300;400;500&family=Crimson+Pro:ital,wght@0,300;0,400;1,300&display=swap" rel="stylesheet"/>
<script src="https://cdn.jsdelivr.net/npm/mathjax@3/es5/tex-chtml.js" async><\/script>
<style>
  :root {
    --bg:       #0d0f14;
    --bg2:      #12151c;
    --bg3:      #181c26;
    --border:   #252a38;
    --gold:     #c9a84c;
    --gold-dim: #8a6f2e;
    --teal:     #4ec9b0;
    --slate:    #7b8caa;
    --text:     #d4d8e8;
    --text-dim: #8890a8;
    --red:      #e06c75;
    --green:    #98c379;
    --purple:   #c792ea;
    --blue:     #61afef;
  }
  *, *::before, *::after { box-sizing: border-box; margin: 0; padding: 0; }
  html { scroll-behavior: smooth; }

  body {
    background: var(--bg);
    color: var(--text);
    font-family: 'Crimson Pro', Georgia, serif;
    font-size: 18px;
    line-height: 1.75;
    min-height: 100vh;
  }
  body::before {
    content: '';
    position: fixed; inset: 0;
    background-image:
      linear-gradient(rgba(201,168,76,0.03) 1px, transparent 1px),
      linear-gradient(90deg, rgba(201,168,76,0.03) 1px, transparent 1px);
    background-size: 48px 48px;
    pointer-events: none; z-index: 0;
  }

  /* ── Header ── */
  header {
    position: relative; z-index: 1;
    padding: 60px 40px 50px;
    border-bottom: 1px solid var(--border);
    background: linear-gradient(180deg,#0a0c12 0%,transparent 100%);
    text-align: center;
  }
  .header-tag {
    font-family: 'JetBrains Mono', monospace;
    font-size: 11px; letter-spacing: .25em;
    color: var(--gold); text-transform: uppercase; margin-bottom: 16px;
  }
  header h1 {
    font-family: 'Playfair Display', serif;
    font-size: clamp(2rem,5vw,3.4rem);
    font-weight: 600; color: #f0ece0;
    letter-spacing: -.01em; line-height: 1.15;
  }
  header h1 span { color: var(--gold); font-style: italic; }
  .header-sub {
    margin-top: 14px;
    font-family: 'JetBrains Mono', monospace;
    font-size: 12px; color: var(--slate); letter-spacing: .12em;
  }
  .gold-line {
    width: 80px; height: 2px;
    background: linear-gradient(90deg,transparent,var(--gold),transparent);
    margin: 24px auto 0;
  }

  /* ── Layout ── */
  main {
    position: relative; z-index: 1;
    max-width: 980px; margin: 0 auto;
    padding: 50px 24px 80px;
  }

  /* ── TOC ── */
  .toc {
    background: var(--bg2); border: 1px solid var(--border);
    padding: 24px 28px; margin-bottom: 40px; border-radius: 2px;
  }
  .toc-title {
    font-family: 'JetBrains Mono', monospace;
    font-size: 10px; letter-spacing: .25em;
    color: var(--gold); text-transform: uppercase; margin-bottom: 14px;
  }
  .toc-list { display: flex; flex-wrap: wrap; gap: 10px; list-style: none; }
  .toc-list a {
    font-family: 'JetBrains Mono', monospace; font-size: 11px;
    color: var(--slate); text-decoration: none;
    border: 1px solid var(--border); padding: 5px 12px;
    border-radius: 2px; transition: all .2s;
  }
  .toc-list a:hover { border-color: var(--gold-dim); color: var(--gold); background: rgba(201,168,76,.06); }

  /* ── Reference box ── */
  .ref-box {
    background: var(--bg2); border: 1px solid var(--border);
    border-left: 3px solid var(--blue);
    padding: 20px 28px; margin-bottom: 40px; border-radius: 2px;
  }
  .ref-title {
    font-family: 'JetBrains Mono', monospace; font-size: 10px;
    letter-spacing: .2em; color: var(--blue); text-transform: uppercase; margin-bottom: 12px;
  }

  /* ── Problem cards ── */
  .problem {
    background: var(--bg2); border: 1px solid var(--border);
    border-left: 3px solid var(--gold-dim);
    border-radius: 2px; margin-bottom: 36px; overflow: hidden;
    animation: fadeUp .5s ease both;
  }
  @keyframes fadeUp { from{opacity:0;transform:translateY(20px)} to{opacity:1;transform:translateY(0)} }
  .problem:nth-child(3){animation-delay:.05s}
  .problem:nth-child(4){animation-delay:.10s}
  .problem:nth-child(5){animation-delay:.15s}
  .problem:nth-child(6){animation-delay:.20s}
  .problem:nth-child(7){animation-delay:.25s}
  .problem:nth-child(8){animation-delay:.30s}
  .problem:nth-child(9){animation-delay:.35s}
  .problem:nth-child(10){animation-delay:.40s}

  .problem-header {
    display: flex; align-items: center; gap: 14px; flex-wrap: wrap;
    padding: 18px 28px 14px; border-bottom: 1px solid var(--border);
    background: var(--bg3);
  }
  .problem-num {
    font-family: 'JetBrains Mono', monospace; font-size: 11px;
    font-weight: 500; letter-spacing: .18em;
    color: var(--gold); text-transform: uppercase; white-space: nowrap;
  }
  .problem-title {
    font-family: 'Playfair Display', serif; font-size: 1.05rem;
    color: #e8e2d0; font-weight: 400; flex: 1;
  }
  .badge {
    display: inline-block; font-family: 'JetBrains Mono', monospace;
    font-size: 10px; letter-spacing: .15em; text-transform: uppercase;
    padding: 3px 10px; border-radius: 2px;
  }
  .badge-proof  { background:rgba(199,146,234,.12); border:1px solid rgba(199,146,234,.35); color:var(--purple); }
  .badge-yes    { background:rgba(152,195,121,.12); border:1px solid rgba(152,195,121,.35); color:var(--green); }
  .badge-no     { background:rgba(224,108,117,.12); border:1px solid rgba(224,108,117,.35); color:var(--red); }
  .badge-ind    { background:rgba(97,175,239,.12);  border:1px solid rgba(97,175,239,.35);  color:var(--blue); }
  .badge-dep    { background:rgba(224,108,117,.12); border:1px solid rgba(224,108,117,.35); color:var(--red); }
  .badge-span   { background:rgba(78,201,176,.12);  border:1px solid rgba(78,201,176,.35);  color:var(--teal); }

  .problem-body { padding: 24px 28px; }

  /* ── Inner elements ── */
  .section-label {
    font-family: 'JetBrains Mono', monospace; font-size: 10px;
    color: var(--teal); letter-spacing: .18em; text-transform: uppercase;
    margin: 20px 0 10px;
  }
  .section-label:first-child { margin-top: 0; }

  .math-block {
    background: var(--bg); border: 1px solid var(--border);
    border-radius: 2px; padding: 16px 20px;
    margin: 10px 0 16px; overflow-x: auto; font-size: .95em;
  }

  /* proof / callout */
  .proof-block {
    background: rgba(199,146,234,.04);
    border-left: 3px solid rgba(199,146,234,.4);
    padding: 16px 20px; margin: 12px 0;
    font-style: italic; color: var(--text-dim); font-size: .96em;
  }
  .proof-block strong { font-style: normal; color: var(--purple); }

  /* subspace verdict */
  .verdict-yes {
    display:inline-flex; align-items:center; gap:8px;
    background:rgba(152,195,121,.08); border:1px solid rgba(152,195,121,.3);
    padding:10px 18px; border-radius:2px; margin:10px 0;
    font-family:'JetBrains Mono',monospace; font-size:12px; color:var(--green);
  }
  .verdict-no {
    display:inline-flex; align-items:center; gap:8px;
    background:rgba(224,108,117,.08); border:1px solid rgba(224,108,117,.3);
    padding:10px 18px; border-radius:2px; margin:10px 0;
    font-family:'JetBrains Mono',monospace; font-size:12px; color:var(--red);
  }

  /* answer box */
  .answer {
    display:inline-block;
    background:rgba(201,168,76,.08); border:1px solid var(--gold-dim);
    border-radius:2px; padding:12px 20px; margin-top:10px;
  }
  .answer-label {
    font-family:'JetBrains Mono',monospace; font-size:10px;
    letter-spacing:.2em; color:var(--gold-dim); text-transform:uppercase;
    display:block; margin-bottom:6px;
  }
  .answer-ind {
    background:rgba(97,175,239,.07); border:1px solid rgba(97,175,239,.35);
    color:var(--blue);
  }
  .answer-dep {
    background:rgba(224,108,117,.07); border:1px solid rgba(224,108,117,.35);
    color:var(--red);
  }

  .steps { list-style:none; padding:0; margin:10px 0 14px; }
  .steps li {
    padding:5px 0 5px 22px; border-left:2px solid var(--border);
    margin-bottom:4px; font-size:.96em; color:var(--text-dim);
    position:relative;
  }
  .steps li::before {
    content:'→'; position:absolute; left:5px;
    color:var(--teal); font-size:12px;
  }

  .part-divider { height:1px; background:var(--border); margin:22px 0; opacity:.5; }

  p { margin-bottom:10px; }
  p:last-child { margin-bottom:0; }

  /* basis display */
  .basis-grid {
    display:flex; flex-wrap:wrap; gap:16px; margin:14px 0;
  }
  .basis-vec {
    background:var(--bg); border:1px solid var(--border);
    border-radius:2px; padding:12px 18px;
    font-family:'JetBrains Mono',monospace; font-size:12px;
    color:var(--teal); text-align:center;
  }
  .basis-vec .vec-label {
    font-size:10px; color:var(--gold-dim); letter-spacing:.15em;
    display:block; margin-bottom:6px;
  }

  footer {
    position:relative; z-index:1; text-align:center; padding:30px;
    border-top:1px solid var(--border);
    font-family:'JetBrains Mono',monospace; font-size:11px;
    color:var(--slate); letter-spacing:.12em;
  }
</style>
</head>
<body>

<header>
  <div class="header-tag">Linear Algebra · Spring 2026</div>
  <h1>Homework <span>3</span></h1>
  <h1 style="font-size:1.3rem;margin-top:6px;color:var(--slate);font-weight:400;font-style:italic;">Vector Spaces · Independence · Span · Basis</h1>
  <div class="header-sub">10 Problems · Subspace Proofs · Linear Independence · Span Membership · Standard Basis</div>
  <div class="gold-line"></div>
</header>

<main>

  <nav class="toc">
    <div class="toc-title">Jump to Problem</div>
    <ul class="toc-list">
      <li><a href="#p1">P1 — Prove (ssp)</a></li>
      <li><a href="#p2">P2 — Subspaces of ℝ²</a></li>
      <li><a href="#p3">P3 — Dependence ⟺ Lin. Comb.</a></li>
      <li><a href="#p4">P4 — Indep. {x₁,x₂,x₃}</a></li>
      <li><a href="#p5">P5 — Indep. {x₁,x₂,x₄}</a></li>
      <li><a href="#p6">P6 — Indep. {x₁,x₃,x₄}</a></li>
      <li><a href="#p7">P7 — Inf. decompositions</a></li>
      <li><a href="#p8">P8 — Span membership</a></li>
      <li><a href="#p9">P9 — Std. basis: x₁,x₃,x₄</a></li>
      <li><a href="#p10">P10 — Std. basis: x₁,x₂,x₄</a></li>
    </ul>
  </nav>

  <!-- Reference vectors -->
  <div class="ref-box">
    <div class="ref-title">Reference Vectors (used in Problems 4–10)</div>
    <div class="math-block">
      \\[
      \\mathbf{x}_1 = \\begin{pmatrix}1\\\\4\\\\2\\\\-3\\end{pmatrix},\\quad
      \\mathbf{x}_2 = \\begin{pmatrix}7\\\\10\\\\-4\\\\-1\\end{pmatrix},\\quad
      \\mathbf{x}_3 = \\begin{pmatrix}-2\\\\1\\\\5\\\\-14\\end{pmatrix},\\quad
      \\mathbf{x}_4 = \\begin{pmatrix}-2\\\\1\\\\5\\\\-4\\end{pmatrix}
      \\]
    </div>
  </div>

  <!-- PROBLEM 1 -->
  <div class="problem" id="p1">
    <div class="problem-header">
      <span class="problem-num">Problem 01</span>
      <span class="problem-title">Prove that a closed nonempty subset is a subspace (ssp)</span>
      <span class="badge badge-proof">Proof</span>
    </div>
    <div class="problem-body">
      <p><strong style="color:var(--purple);">Claim:</strong> Let \\(V\\) be a vector space and \\(S\\subseteq V\\) a nonempty subset closed under addition and scalar multiplication. Then \\(S\\) is a vector space (subspace of \\(V\\)).</p>

      <div class="proof-block">
        Properties (a–1), (a–2), (m–1), (m–2), (d–1), (d–2) hold automatically in \\(S\\) since its vectors are a subset of \\(V\\)'s and operations are inherited. Properties (a–0) and (m–0) hold by assumption. We verify (a–3) and (a–4).
      </div>

      <div class="section-label">(a–3) Zero vector ∈ S</div>
      <p>Since \\(S\\) is nonempty, pick any \\(\\mathbf{x}_*\\in S\\). By (m–0), \\(0\\,\\mathbf{x}_*\\in S\\). By (m–2) and (d–2):</p>
      <div class="math-block">
        \\[\\mathbf{x}_* = 1\\cdot\\mathbf{x}_* = (1+0)\\mathbf{x}_* = 1\\cdot\\mathbf{x}_* + 0\\cdot\\mathbf{x}_* = \\mathbf{x}_* + 0\\,\\mathbf{x}_*\\]
      </div>
      <p>So \\(\\mathbf{x}_* + 0\\,\\mathbf{x}_* = \\mathbf{x}_*\\). By property (p–3) of \\(V\\), \\(0\\,\\mathbf{x}_* = \\mathbf{0}\\). Hence \\(\\mathbf{0}\\in S\\). \\(\\checkmark\\)</p>

      <div class="section-label">(a–4) Additive inverses ∈ S</div>
      <p>Let \\(\\mathbf{x}\\in S\\). By (m–0), \\((-1)\\mathbf{x}\\in S\\). From property (p–4)(iii) of \\(V\\), \\((-1)\\mathbf{x} = \\tilde{\\mathbf{x}}\\) (the additive inverse of \\(\\mathbf{x}\\)). Therefore \\(\\tilde{\\mathbf{x}}\\in S\\). \\(\\checkmark\\)</p>

      <p style="margin-top:12px;">All axioms are satisfied, so \\(S\\) is a vector space. \\(\\blacksquare\\)</p>
    </div>
  </div>

  <!-- PROBLEM 2 -->
  <div class="problem" id="p2">
    <div class="problem-header">
      <span class="problem-num">Problem 02</span>
      <span class="problem-title">Which subsets of ℝ² are subspaces?</span>
    </div>
    <div class="problem-body">

      <!-- 2a -->
      <div class="section-label">(a) S = { x ∈ ℝ² : x₁ = 0 }</div>
      <div class="verdict-yes">✓ IS a subspace</div>
      <p>Let \\(\\mathbf{x},\\mathbf{y}\\in S\\) so \\(x_1=0, y_1=0\\).</p>
      <ul class="steps">
        <li><strong>Addition:</strong> \\(x_1+y_1 = 0+0 = 0 \\Rightarrow \\mathbf{x}+\\mathbf{y}\\in S\\)</li>
        <li><strong>Scalar mult:</strong> \\(\\alpha x_1 = \\alpha\\cdot 0 = 0 \\Rightarrow \\alpha\\mathbf{x}\\in S\\)</li>
      </ul>

      <div class="part-divider"></div>

      <!-- 2b -->
      <div class="section-label">(b) S = { x ∈ ℝ² : x₁ − x₂ = 0 }</div>
      <div class="verdict-yes">✓ IS a subspace</div>
      <p>Let \\(\\mathbf{x},\\mathbf{y}\\in S\\) so \\(x_1=x_2\\) and \\(y_1=y_2\\).</p>
      <ul class="steps">
        <li><strong>Addition:</strong> \\((x_1+y_1)-(x_2+y_2) = (x_1-x_2)+(y_1-y_2) = 0+0 = 0\\)</li>
        <li><strong>Scalar mult:</strong> \\(\\alpha x_1-\\alpha x_2 = \\alpha(x_1-x_2) = 0\\)</li>
      </ul>

      <div class="part-divider"></div>

      <!-- 2c -->
      <div class="section-label">(c) S = { x ∈ ℝ² : x₁ + x₂ ≥ 0 }</div>
      <div class="verdict-no">✗ NOT a subspace</div>
      <p><strong>Counterexample:</strong> \\(\\mathbf{x} = \\binom{1}{1}\\in S\\) and \\(\\alpha=-1\\):</p>
      <div class="math-block">
        \\[-1\\cdot\\begin{pmatrix}1\\\\1\\end{pmatrix} = \\begin{pmatrix}-1\\\\-1\\end{pmatrix}\\notin S\\quad\\text{since }(-1)+(-1)=-2\\not\\ge 0\\]
      </div>
      <p>Not closed under scalar multiplication.</p>

      <div class="part-divider"></div>

      <!-- 2d -->
      <div class="section-label">(d) S = { x ∈ ℝ² : x₁ + 2x₂ = 0 }</div>
      <div class="verdict-yes">✓ IS a subspace</div>
      <p>Let \\(\\mathbf{x},\\mathbf{y}\\in S\\) so \\(x_1+2x_2=0\\) and \\(y_1+2y_2=0\\).</p>
      <ul class="steps">
        <li><strong>Addition:</strong> \\((x_1+y_1)+2(x_2+y_2) = (x_1+2x_2)+(y_1+2y_2) = 0+0 = 0\\)</li>
        <li><strong>Scalar mult:</strong> \\(\\alpha x_1+2(\\alpha x_2)=\\alpha(x_1+2x_2)=0\\)</li>
      </ul>
    </div>
  </div>

  <!-- PROBLEM 3 -->
  <div class="problem" id="p3">
    <div class="problem-header">
      <span class="problem-num">Problem 03</span>
      <span class="problem-title">Dependence ⟺ one vector is a linear combination of the others</span>
      <span class="badge badge-proof">Proof</span>
    </div>
    <div class="problem-body">
      <div class="proof-block">
        <strong>Claim.</strong> \\(\\{\\mathbf{x}_1,\\ldots,\\mathbf{x}_n\\}\\) (with \\(n\\ge2\\)) is dependent if and only if at least one vector can be written as a linear combination of the remaining ones.
      </div>

      <div class="section-label">(⟹) Dependent → one is a linear combination</div>
      <p>Suppose dependent: \\(\\exists\\) scalars \\(\\alpha_1,\\ldots,\\alpha_n\\), not all zero, with \\(\\sum_k\\alpha_k\\mathbf{x}_k=\\mathbf{0}\\). Pick index \\(i_*\\) where \\(\\alpha_{i_*}\\neq 0\\). Then:</p>
      <div class="math-block">
        \\[\\alpha_{i_*}\\mathbf{x}_{i_*} = -\\sum_{k\\neq i_*}\\alpha_k\\mathbf{x}_k \\implies \\mathbf{x}_{i_*} = \\sum_{k\\neq i_*}\\tilde\\alpha_k\\,\\mathbf{x}_k,\\quad \\tilde\\alpha_k = -\\frac{\\alpha_k}{\\alpha_{i_*}}\\]
      </div>

      <div class="section-label">(⟸) One is a linear combination → dependent</div>
      <p>Suppose \\(\\mathbf{x}_{i_*} = \\sum_{k\\neq i_*}\\beta_k\\mathbf{x}_k\\). Then:</p>
      <div class="math-block">
        \\[\\sum_{k\\neq i_*}\\beta_k\\mathbf{x}_k + (-1)\\mathbf{x}_{i_*} = \\mathbf{0}\\]
      </div>
      <p>This is a nontrivial combination equal to zero (coefficient of \\(\\mathbf{x}_{i_*}\\) is \\(-1\\neq 0\\)), so the set is dependent. \\(\\blacksquare\\)</p>
    </div>
  </div>

  <!-- PROBLEM 4 -->
  <div class="problem" id="p4">
    <div class="problem-header">
      <span class="problem-num">Problem 04</span>
      <span class="problem-title">Is {x₁, x₂, x₃} independent?</span>
      <span class="badge badge-ind">Independent ✓</span>
    </div>
    <div class="problem-body">
      <p>Solve \\(\\alpha_1\\mathbf{x}_1+\\alpha_2\\mathbf{x}_2+\\alpha_3\\mathbf{x}_3=\\mathbf{0}\\) via augmented matrix:</p>
      <div class="math-block">
        \\[
        \\left[\\begin{array}{ccc|c}1&7&-2&0\\\\4&10&1&0\\\\2&-4&5&0\\\\-3&-1&-14&0\\end{array}\\right]
        \\sim
        \\left[\\begin{array}{ccc|c}1&7&-2&0\\\\0&-18&9&0\\\\0&-18&9&0\\\\0&20&-20&0\\end{array}\\right]
        \\sim
        \\left[\\begin{array}{ccc|c}1&7&-2&0\\\\0&2&-1&0\\\\0&1&-1&0\\\\0&0&0&0\\end{array}\\right]
        \\]
        \\[
        \\sim\\left[\\begin{array}{ccc|c}1&7&-2&0\\\\0&2&-1&0\\\\0&0&-1&0\\\\0&0&0&0\\end{array}\\right]
        \\]
      </div>
      <ul class="steps">
        <li>From \\(R_3\\): \\(\\alpha_3 = 0\\)</li>
        <li>From \\(R_2\\): \\(2\\alpha_2 - 0 = 0 \\Rightarrow \\alpha_2 = 0\\)</li>
        <li>From \\(R_1\\): \\(\\alpha_1 = 0\\)</li>
      </ul>
      <div class="answer answer-ind">
        <span class="answer-label" style="color:rgba(97,175,239,.6)">Conclusion</span>
        Only solution is \\(\\alpha_1=\\alpha_2=\\alpha_3=0\\) → <strong>\\(\\{\\mathbf{x}_1,\\mathbf{x}_2,\\mathbf{x}_3\\}\\) is INDEPENDENT</strong>
      </div>
    </div>
  </div>

  <!-- PROBLEM 5 -->
  <div class="problem" id="p5">
    <div class="problem-header">
      <span class="problem-num">Problem 05</span>
      <span class="problem-title">Is {x₁, x₂, x₄} independent?</span>
      <span class="badge badge-dep">Dependent ✗</span>
    </div>
    <div class="problem-body">
      <div class="math-block">
        \\[
        \\left[\\begin{array}{ccc|c}1&7&-2&0\\\\4&10&1&0\\\\2&-4&5&0\\\\-3&-1&-4&0\\end{array}\\right]
        \\sim
        \\left[\\begin{array}{ccc|c}1&7&-2&0\\\\0&-18&9&0\\\\0&-18&9&0\\\\0&20&-10&0\\end{array}\\right]
        \\sim
        \\left[\\begin{array}{ccc|c}1&7&-2&0\\\\0&2&-1&0\\\\0&0&0&0\\\\0&0&0&0\\end{array}\\right]
        \\]
      </div>
      <p>\\(\\alpha_3\\) is free. Let \\(\\alpha_3 = \\alpha\\):</p>
      <ul class="steps">
        <li>\\(2\\alpha_2 = \\alpha \\Rightarrow \\alpha_2 = \\alpha/2\\)</li>
        <li>\\(\\alpha_1 + 7(\\alpha/2) - 2\\alpha = 0 \\Rightarrow \\alpha_1 = -3\\alpha/2\\)</li>
        <li>Take \\(\\alpha = 2\\): \\(\\alpha_1=-3,\\;\\alpha_2=1,\\;\\alpha_3=2\\)</li>
      </ul>
      <div class="math-block">
        \\[-3\\mathbf{x}_1 + \\mathbf{x}_2 + 2\\mathbf{x}_4 = \\mathbf{0}\\]
      </div>
      <div class="answer answer-dep">
        <span class="answer-label" style="color:rgba(224,108,117,.6)">Conclusion</span>
        Nontrivial solution exists → <strong>\\(\\{\\mathbf{x}_1,\\mathbf{x}_2,\\mathbf{x}_4\\}\\) is NOT INDEPENDENT</strong>
      </div>
    </div>
  </div>

  <!-- PROBLEM 6 -->
  <div class="problem" id="p6">
    <div class="problem-header">
      <span class="problem-num">Problem 06</span>
      <span class="problem-title">Is {x₁, x₃, x₄} independent?</span>
      <span class="badge badge-ind">Independent ✓</span>
    </div>
    <div class="problem-body">
      <div class="math-block">
        \\[
        \\left[\\begin{array}{ccc|c}1&-2&-2&0\\\\4&1&1&0\\\\2&5&5&0\\\\-3&-14&-4&0\\end{array}\\right]
        \\sim
        \\left[\\begin{array}{ccc|c}1&-2&-2&0\\\\0&9&9&0\\\\0&9&9&0\\\\0&-20&-10&0\\end{array}\\right]
        \\sim
        \\left[\\begin{array}{ccc|c}1&-2&-2&0\\\\0&1&1&0\\\\0&0&0&0\\\\0&0&-1&0\\end{array}\\right]
        \\]
        \\[
        \\xrightarrow{R_3\\leftrightarrow R_4}
        \\left[\\begin{array}{ccc|c}1&-2&-2&0\\\\0&1&1&0\\\\0&0&-1&0\\\\0&0&0&0\\end{array}\\right]
        \\]
      </div>
      <ul class="steps">
        <li>\\(-\\alpha_3 = 0 \\Rightarrow \\alpha_3 = 0\\)</li>
        <li>\\(\\alpha_2 + 0 = 0 \\Rightarrow \\alpha_2 = 0\\)</li>
        <li>\\(\\alpha_1 = 0\\)</li>
      </ul>
      <div class="answer answer-ind">
        <span class="answer-label" style="color:rgba(97,175,239,.6)">Conclusion</span>
        Only solution is \\(\\alpha_1=\\alpha_2=\\alpha_3=0\\) → <strong>\\(\\{\\mathbf{x}_1,\\mathbf{x}_3,\\mathbf{x}_4\\}\\) is INDEPENDENT</strong>
      </div>
    </div>
  </div>

  <!-- PROBLEM 7 -->
  <div class="problem" id="p7">
    <div class="problem-header">
      <span class="problem-num">Problem 07</span>
      <span class="problem-title">Dependent set → infinitely many decompositions</span>
      <span class="badge badge-proof">Proof</span>
    </div>
    <div class="problem-body">
      <div class="proof-block">
        <strong>Given:</strong> \\(\\{\\mathbf{x}_1,\\ldots,\\mathbf{x}_n\\}\\) dependent, \\(\\mathbf{y}\\in\\operatorname{span}\\{\\mathbf{x}_1,\\ldots,\\mathbf{x}_n\\}\\).
        <strong>Show:</strong> infinitely many decompositions \\(\\mathbf{y}=\\sum_k\\tilde\\alpha_k\\mathbf{x}_k\\).
      </div>
      <ul class="steps">
        <li>Dependent: \\(\\exists\\,\\beta_1,\\ldots,\\beta_n\\) not all zero with \\(\\beta_1\\mathbf{x}_1+\\cdots+\\beta_n\\mathbf{x}_n=\\mathbf{0}\\).</li>
        <li>\\(\\mathbf{y}\\in\\operatorname{span}\\): \\(\\exists\\,\\alpha_1,\\ldots,\\alpha_n\\) with \\(\\mathbf{y}=\\alpha_1\\mathbf{x}_1+\\cdots+\\alpha_n\\mathbf{x}_n\\).</li>
        <li>For any \\(\\gamma\\in\\mathbb{R}\\): \\(\\gamma(\\beta_1\\mathbf{x}_1+\\cdots+\\beta_n\\mathbf{x}_n)=\\mathbf{0}\\).</li>
      </ul>
      <div class="math-block">
        \\[\\mathbf{y} = \\mathbf{y}+\\mathbf{0} = \\sum_k\\alpha_k\\mathbf{x}_k + \\gamma\\sum_k\\beta_k\\mathbf{x}_k = \\sum_k(\\alpha_k+\\gamma\\beta_k)\\mathbf{x}_k\\]
      </div>
      <p>Setting \\(\\tilde\\alpha_k = \\alpha_k+\\gamma\\beta_k\\): since not all \\(\\beta_k\\) are zero, different \\(\\gamma\\) give different coefficient tuples. There are infinitely many \\(\\gamma\\in\\mathbb{R}\\), hence infinitely many decompositions. \\(\\blacksquare\\)</p>
    </div>
  </div>

  <!-- PROBLEM 8 -->
  <div class="problem" id="p8">
    <div class="problem-header">
      <span class="problem-num">Problem 08</span>
      <span class="problem-title">Is y ∈ span{x₁, x₂, x₃}?</span>
    </div>
    <div class="problem-body">

      <div class="section-label">(a) y = (1, 2, 3, 4)ᵀ</div>
      <p>Solve \\(\\alpha_1\\mathbf{x}_1+\\alpha_2\\mathbf{x}_2+\\alpha_3\\mathbf{x}_3=\\mathbf{y}\\):</p>
      <div class="math-block">
        \\[
        \\left[\\begin{array}{ccc|c}1&7&-2&1\\\\4&10&1&2\\\\2&-4&5&3\\\\-3&-1&-14&4\\end{array}\\right]
        \\sim\\cdots\\sim
        \\left[\\begin{array}{ccc|c}1&7&-2&1\\\\0&2&-1&2/9\\\\0&0&1&-43/90\\\\0&0&0&-1/3\\end{array}\\right]
        \\]
      </div>
      <p>Last row says \\(0=−\\tfrac{1}{3}\\) — impossible.</p>
      <div class="answer answer-dep">
        <span class="answer-label" style="color:rgba(224,108,117,.6)">Result</span>
        \\(\\mathbf{y} = (1,2,3,4)^T \\notin \\operatorname{span}\\{\\mathbf{x}_1,\\mathbf{x}_2,\\mathbf{x}_3\\}\\)
      </div>

      <div class="part-divider"></div>

      <div class="section-label">(b) y = (6, 15, 3, −18)ᵀ &nbsp;<span style="font-style:italic;color:var(--text-dim);font-size:.85em;">(note: typo corrected in solutions)</span></div>
      <div class="math-block">
        \\[
        \\left[\\begin{array}{ccc|c}1&7&-2&6\\\\4&10&1&15\\\\2&-4&5&3\\\\-3&-1&-14&-18\\end{array}\\right]
        \\sim
        \\left[\\begin{array}{ccc|c}1&7&-2&6\\\\0&2&-1&1\\\\0&0&0&0\\\\0&0&0&0\\end{array}\\right]
        \\]
      </div>
      <ul class="steps">
        <li>Take \\(\\alpha_3=1\\) (free): \\(2\\alpha_2-1=1\\Rightarrow\\alpha_2=1\\)</li>
        <li>\\(\\alpha_1+7(1)-2(1)=6\\Rightarrow\\alpha_1=1\\)</li>
      </ul>
      <div class="math-block">
        \\[\\mathbf{y} = 1\\cdot\\mathbf{x}_1 + 1\\cdot\\mathbf{x}_2 + 1\\cdot\\mathbf{x}_3 = \\begin{pmatrix}1\\\\4\\\\2\\\\-3\\end{pmatrix}+\\begin{pmatrix}7\\\\10\\\\-4\\\\-1\\end{pmatrix}+\\begin{pmatrix}-2\\\\1\\\\5\\\\-14\\end{pmatrix}=\\begin{pmatrix}6\\\\15\\\\3\\\\-18\\end{pmatrix}\\;\\checkmark\\]
      </div>
      <div class="answer answer-ind">
        <span class="answer-label" style="color:rgba(97,175,239,.6)">Result</span>
        \\(\\mathbf{y}\\in\\operatorname{span}\\{\\mathbf{x}_1,\\mathbf{x}_2,\\mathbf{x}_3\\}\\), decomposition: \\(\\mathbf{y}=\\mathbf{x}_1+\\mathbf{x}_2+\\mathbf{x}_3\\)
      </div>
    </div>
  </div>

  <!-- PROBLEM 9 -->
  <div class="problem" id="p9">
    <div class="problem-header">
      <span class="problem-num">Problem 09</span>
      <span class="problem-title">Standard basis for span{x₁, x₃, x₄}</span>
      <span class="badge badge-span">dim = 3</span>
    </div>
    <div class="problem-body">
      <p>Write vectors as rows and reduce to row canonical (reduced row echelon) form — no vertical bar:</p>
      <div class="math-block">
        \\[
        \\begin{pmatrix}1&4&2&-3\\\\-2&1&5&-14\\\\-2&1&5&-4\\end{pmatrix}
        \\sim
        \\begin{pmatrix}1&4&2&-3\\\\0&9&9&-20\\\\0&9&9&-10\\end{pmatrix}
        \\sim
        \\begin{pmatrix}1&4&2&-3\\\\0&9&9&-20\\\\0&0&0&10\\end{pmatrix}
        \\]
        \\[
        \\xrightarrow{R_1+3R_3/10,\\;R_2+20R_3/10}
        \\begin{pmatrix}1&4&2&0\\\\0&9&9&0\\\\0&0&0&1\\end{pmatrix}
        \\xrightarrow{R_2/9}
        \\begin{pmatrix}1&4&2&0\\\\0&1&1&0\\\\0&0&0&1\\end{pmatrix}
        \\xrightarrow{R_1-4R_2}
        \\begin{pmatrix}1&0&-2&0\\\\0&1&1&0\\\\0&0&0&1\\end{pmatrix}
        \\]
      </div>

      <p>Read off standard basis from the columns of the identity-like structure (columns with leading 1s, corresponding to pivot positions):</p>

      <div class="basis-grid">
        <div class="basis-vec">
          <span class="vec-label">e₁</span>
          \\(\\begin{pmatrix}1\\\\0\\\\-2\\\\0\\end{pmatrix}\\)
        </div>
        <div class="basis-vec">
          <span class="vec-label">e₂</span>
          \\(\\begin{pmatrix}0\\\\1\\\\1\\\\0\\end{pmatrix}\\)
        </div>
        <div class="basis-vec">
          <span class="vec-label">e₃</span>
          \\(\\begin{pmatrix}0\\\\0\\\\0\\\\1\\end{pmatrix}\\)
        </div>
      </div>

      <div class="answer">
        <span class="answer-label">Standard Basis — dim = 3</span>
        \\(\\operatorname{span}\\{\\mathbf{x}_1,\\mathbf{x}_3,\\mathbf{x}_4\\} = \\operatorname{span}\\{\\mathbf{e}_1,\\mathbf{e}_2,\\mathbf{e}_3\\}\\)
      </div>

      <div class="section-label" style="margin-top:18px;">Verification</div>
      <div class="math-block">
        \\[\\mathbf{x}_1 = \\mathbf{e}_1+4\\mathbf{e}_2-3\\mathbf{e}_3,\\quad
          \\mathbf{x}_3 = -2\\mathbf{e}_1+\\mathbf{e}_2-14\\mathbf{e}_3,\\quad
          \\mathbf{x}_4 = -2\\mathbf{e}_1+\\mathbf{e}_2-4\\mathbf{e}_3\\;\\checkmark\\]
      </div>
    </div>
  </div>

  <!-- PROBLEM 10 -->
  <div class="problem" id="p10">
    <div class="problem-header">
      <span class="problem-num">Problem 10</span>
      <span class="problem-title">Standard basis for span{x₁, x₂, x₄} — dependent set</span>
      <span class="badge badge-span">dim = 2</span>
    </div>
    <div class="problem-body">
      <p>Even though \\(\\{\\mathbf{x}_1,\\mathbf{x}_2,\\mathbf{x}_4\\}\\) is not independent (Problem 5), we can still find the standard basis — just discard any zero rows after reduction.</p>
      <div class="math-block">
        \\[
        \\begin{pmatrix}1&4&2&-3\\\\7&10&-4&-1\\\\-2&1&5&-4\\end{pmatrix}
        \\sim
        \\begin{pmatrix}1&4&2&-3\\\\0&-18&-18&20\\\\0&9&9&-10\\end{pmatrix}
        \\sim
        \\begin{pmatrix}1&4&2&-3\\\\0&9&9&-10\\\\0&0&0&0\\end{pmatrix}
        \\]
        \\[
        \\xrightarrow{R_2/9}
        \\begin{pmatrix}1&4&2&-3\\\\0&1&1&-10/9\\\\0&0&0&0\\end{pmatrix}
        \\xrightarrow{R_1-4R_2}
        \\begin{pmatrix}1&0&-2&13/9\\\\0&1&1&-10/9\\\\0&0&0&0\\end{pmatrix}
        \\]
      </div>

      <p>Discard the zero row. Standard basis:</p>

      <div class="basis-grid">
        <div class="basis-vec">
          <span class="vec-label">e₁</span>
          \\(\\begin{pmatrix}1\\\\0\\\\-2\\\\13/9\\end{pmatrix}\\)
        </div>
        <div class="basis-vec">
          <span class="vec-label">e₂</span>
          \\(\\begin{pmatrix}0\\\\1\\\\1\\\\-10/9\\end{pmatrix}\\)
        </div>
      </div>

      <div class="answer">
        <span class="answer-label">Standard Basis — dim = 2</span>
        \\(\\operatorname{span}\\{\\mathbf{x}_1,\\mathbf{x}_2,\\mathbf{x}_4\\} = \\operatorname{span}\\{\\mathbf{e}_1,\\mathbf{e}_2\\}\\)
      </div>

      <div class="section-label" style="margin-top:18px;">Verification</div>
      <div class="math-block">
        \\[\\mathbf{x}_1 = \\mathbf{e}_1+4\\mathbf{e}_2,\\qquad
          \\mathbf{x}_2 = 7\\mathbf{e}_1+10\\mathbf{e}_2,\\qquad
          \\mathbf{x}_4 = -2\\mathbf{e}_1+\\mathbf{e}_2\\;\\checkmark\\]
      </div>
    </div>
  </div>

</main>

<footer>
  Linear Algebra · HW 3 · Vector Spaces, Independence, Span &amp; Basis
</footer>

</body>
</html>
`;export{n as default};
