const n=`<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8"/>
<meta name="viewport" content="width=device-width, initial-scale=1.0"/>
<title>Linear Algebra — HW 2</title>
<link href="https://fonts.googleapis.com/css2?family=Playfair+Display:ital,wght@0,400;0,600;1,400&family=JetBrains+Mono:wght@300;400;500&family=Crimson+Pro:ital,wght@0,300;0,400;1,300&display=swap" rel="stylesheet"/>
<script src="https://cdn.jsdelivr.net/npm/mathjax@3/es5/tex-chtml.js" async><\/script>
<style>
  :root {
    --bg: #0d0f14;
    --bg2: #12151c;
    --bg3: #181c26;
    --border: #252a38;
    --gold: #c9a84c;
    --gold-dim: #8a6f2e;
    --teal: #4ec9b0;
    --slate: #7b8caa;
    --text: #d4d8e8;
    --text-dim: #8890a8;
    --red: #e06c75;
    --green: #98c379;
    --purple: #c792ea;
  }

  *, *::before, *::after { box-sizing: border-box; margin: 0; padding: 0; }
  html { scroll-behavior: smooth; }

  body {
    background: var(--bg);
    color: var(--text);
    font-family: 'Crimson Pro', Georgia, serif;
    font-size: 18px;
    line-height: 1.7;
    min-height: 100vh;
  }

  body::before {
    content: '';
    position: fixed;
    inset: 0;
    background-image:
      linear-gradient(rgba(201,168,76,0.03) 1px, transparent 1px),
      linear-gradient(90deg, rgba(201,168,76,0.03) 1px, transparent 1px);
    background-size: 48px 48px;
    pointer-events: none;
    z-index: 0;
  }

  header {
    position: relative;
    z-index: 1;
    padding: 60px 40px 50px;
    border-bottom: 1px solid var(--border);
    background: linear-gradient(180deg, #0a0c12 0%, transparent 100%);
    text-align: center;
  }

  .header-tag {
    font-family: 'JetBrains Mono', monospace;
    font-size: 11px;
    font-weight: 300;
    letter-spacing: 0.25em;
    color: var(--gold);
    text-transform: uppercase;
    margin-bottom: 16px;
  }

  header h1 {
    font-family: 'Playfair Display', serif;
    font-size: clamp(2rem, 5vw, 3.4rem);
    font-weight: 600;
    color: #f0ece0;
    letter-spacing: -0.01em;
    line-height: 1.15;
  }

  header h1 span { color: var(--gold); font-style: italic; }

  .header-sub {
    margin-top: 14px;
    font-family: 'JetBrains Mono', monospace;
    font-size: 12px;
    color: var(--slate);
    letter-spacing: 0.12em;
  }

  .gold-line {
    width: 80px;
    height: 2px;
    background: linear-gradient(90deg, transparent, var(--gold), transparent);
    margin: 24px auto 0;
  }

  /* solution type badges */
  .badge {
    display: inline-block;
    font-family: 'JetBrains Mono', monospace;
    font-size: 10px;
    letter-spacing: 0.15em;
    text-transform: uppercase;
    padding: 3px 10px;
    border-radius: 2px;
    vertical-align: middle;
    margin-left: 10px;
  }
  .badge-inf  { background: rgba(201,168,76,0.12); border:1px solid rgba(201,168,76,0.35); color:var(--gold); }
  .badge-uni  { background: rgba(152,195,121,0.12); border:1px solid rgba(152,195,121,0.35); color:var(--green); }
  .badge-none { background: rgba(224,108,117,0.12); border:1px solid rgba(224,108,117,0.35); color:var(--red); }
  .badge-2p   { background: rgba(199,146,234,0.12); border:1px solid rgba(199,146,234,0.35); color:var(--purple); }

  main {
    position: relative;
    z-index: 1;
    max-width: 960px;
    margin: 0 auto;
    padding: 50px 24px 80px;
  }

  .toc {
    background: var(--bg2);
    border: 1px solid var(--border);
    padding: 24px 28px;
    margin-bottom: 40px;
    border-radius: 2px;
  }
  .toc-title {
    font-family: 'JetBrains Mono', monospace;
    font-size: 10px;
    letter-spacing: 0.25em;
    color: var(--gold);
    text-transform: uppercase;
    margin-bottom: 14px;
  }
  .toc-list { display: flex; flex-wrap: wrap; gap: 10px; list-style: none; }
  .toc-list a {
    font-family: 'JetBrains Mono', monospace;
    font-size: 11px;
    color: var(--slate);
    text-decoration: none;
    border: 1px solid var(--border);
    padding: 5px 12px;
    border-radius: 2px;
    transition: all 0.2s;
  }
  .toc-list a:hover { border-color: var(--gold-dim); color: var(--gold); background: rgba(201,168,76,0.06); }

  .problem {
    background: var(--bg2);
    border: 1px solid var(--border);
    border-left: 3px solid var(--gold-dim);
    border-radius: 2px;
    margin-bottom: 36px;
    overflow: hidden;
    animation: fadeUp 0.5s ease both;
  }
  @keyframes fadeUp {
    from { opacity:0; transform:translateY(20px); }
    to   { opacity:1; transform:translateY(0); }
  }
  .problem:nth-child(2){ animation-delay:0.05s; }
  .problem:nth-child(3){ animation-delay:0.10s; }
  .problem:nth-child(4){ animation-delay:0.15s; }
  .problem:nth-child(5){ animation-delay:0.20s; }
  .problem:nth-child(6){ animation-delay:0.25s; }
  .problem:nth-child(7){ animation-delay:0.30s; }

  .problem-header {
    display: flex;
    align-items: center;
    gap: 16px;
    padding: 20px 28px 16px;
    border-bottom: 1px solid var(--border);
    background: var(--bg3);
    flex-wrap: wrap;
  }
  .problem-num {
    font-family: 'JetBrains Mono', monospace;
    font-size: 11px;
    font-weight: 500;
    letter-spacing: 0.18em;
    color: var(--gold);
    text-transform: uppercase;
    white-space: nowrap;
  }
  .problem-title {
    font-family: 'Playfair Display', serif;
    font-size: 1.05rem;
    color: #e8e2d0;
    font-weight: 400;
    flex: 1;
  }

  .problem-body { padding: 24px 28px; }

  .section-label {
    font-family: 'JetBrains Mono', monospace;
    font-size: 10px;
    color: var(--teal);
    letter-spacing: 0.18em;
    text-transform: uppercase;
    margin: 20px 0 10px;
  }
  .section-label:first-child { margin-top: 0; }

  .math-block {
    background: var(--bg);
    border: 1px solid var(--border);
    border-radius: 2px;
    padding: 16px 20px;
    margin: 10px 0 16px;
    overflow-x: auto;
    font-size: 0.96em;
  }

  .steps {
    list-style: none;
    padding-left: 0;
    margin: 10px 0 16px;
  }
  .steps li {
    padding: 5px 0 5px 22px;
    border-left: 2px solid var(--border);
    margin-bottom: 4px;
    font-size: 0.97em;
    color: var(--text-dim);
    position: relative;
  }
  .steps li::before {
    content: '→';
    position: absolute;
    left: 5px;
    color: var(--teal);
    font-size: 12px;
  }

  .answer {
    display: inline-block;
    background: rgba(201,168,76,0.08);
    border: 1px solid var(--gold-dim);
    border-radius: 2px;
    padding: 12px 20px;
    margin-top: 8px;
  }
  .answer-label {
    font-family: 'JetBrains Mono', monospace;
    font-size: 10px;
    letter-spacing: 0.2em;
    color: var(--gold-dim);
    text-transform: uppercase;
    display: block;
    margin-bottom: 6px;
  }

  .answer-none {
    display: inline-block;
    background: rgba(224,108,117,0.08);
    border: 1px solid rgba(224,108,117,0.35);
    border-radius: 2px;
    padding: 12px 20px;
    margin-top: 8px;
    color: var(--red);
  }

  .free-var {
    display: inline-block;
    background: rgba(78,201,176,0.08);
    border: 1px solid rgba(78,201,176,0.3);
    color: var(--teal);
    font-family: 'JetBrains Mono', monospace;
    font-size: 11px;
    letter-spacing: 0.1em;
    padding: 2px 9px;
    border-radius: 2px;
  }

  p { margin-bottom: 10px; }
  p:last-child { margin-bottom: 0; }

  .divider {
    height: 1px;
    background: var(--border);
    margin: 20px 0;
    opacity: 0.5;
  }

  footer {
    position: relative;
    z-index: 1;
    text-align: center;
    padding: 30px;
    border-top: 1px solid var(--border);
    font-family: 'JetBrains Mono', monospace;
    font-size: 11px;
    color: var(--slate);
    letter-spacing: 0.12em;
  }
</style>
</head>
<body>

<header>
  <div class="header-tag">Linear Algebra · Spring 2026</div>
  <h1>Homework <span>2</span></h1>
  <h1 style="font-size:1.3rem;margin-top:6px;color:var(--slate);font-weight:400;font-style:italic;">More Linear Systems Exercises</h1>
  <div class="header-sub">6 Problems · Augmented Matrices · Gaussian Elimination · Row Echelon Form</div>
  <div class="gold-line"></div>
</header>

<main>

  <nav class="toc">
    <div class="toc-title">Jump to Problem</div>
    <ul class="toc-list">
      <li><a href="#p1">P1 — 2 eqns · ∞ solutions</a></li>
      <li><a href="#p2">P2 — 2 eqns · ∞ solutions</a></li>
      <li><a href="#p3">P3 — 3 eqns · ∞ solutions</a></li>
      <li><a href="#p4">P4 — 4 eqns · ∞ solutions</a></li>
      <li><a href="#p5">P5 — 4 eqns · unique</a></li>
      <li><a href="#p6">P6 — 4 eqns · no solution</a></li>
    </ul>
  </nav>

  <!-- PROBLEM 1 -->
  <div class="problem" id="p1">
    <div class="problem-header">
      <span class="problem-num">Problem 01</span>
      <span class="problem-title">2 equations, 4 unknowns</span>
      <span class="badge badge-2p">2-parameter family</span>
    </div>
    <div class="problem-body">

      <div class="section-label">System</div>
      <div class="math-block">
        \\[\\begin{aligned}
        x_1 + 2x_2 - x_3 + 2x_4 &= 3\\\\
        x_1 + 3x_2 - x_3 + 3x_4 &= 4
        \\end{aligned}\\]
      </div>

      <div class="section-label">Augmented matrix → echelon form</div>
      <div class="math-block">
        \\[
        \\left[\\begin{array}{cccc|c}1&2&-1&2&3\\\\1&3&-1&3&4\\end{array}\\right]
        \\xrightarrow{R_2 \\to R_2 - R_1}
        \\left[\\begin{array}{cccc|c}1&2&-1&2&3\\\\0&1&0&1&1\\end{array}\\right]
        \\]
      </div>

      <div class="section-label">Free variables: <span class="free-var">x₃ = α</span> &nbsp;<span class="free-var">x₄ = β</span></div>
      <ul class="steps">
        <li>From \\(R_2\\): \\(x_2 + x_4 = 1 \\Rightarrow x_2 = 1 - \\beta\\)</li>
        <li>From \\(R_1\\): \\(x_1 + 2(1-\\beta) - \\alpha + 2\\beta = 3 \\Rightarrow x_1 = 1 + \\alpha\\)</li>
      </ul>

      <div class="answer">
        <span class="answer-label">Solution (α, β ∈ ℝ)</span>
        \\(x_1 = 1+\\alpha,\\quad x_2 = 1-\\beta,\\quad x_3 = \\alpha,\\quad x_4 = \\beta\\)
      </div>
    </div>
  </div>

  <!-- PROBLEM 2 -->
  <div class="problem" id="p2">
    <div class="problem-header">
      <span class="problem-num">Problem 02</span>
      <span class="problem-title">2 equations, 4 unknowns</span>
      <span class="badge badge-2p">2-parameter family</span>
    </div>
    <div class="problem-body">

      <div class="section-label">System</div>
      <div class="math-block">
        \\[\\begin{aligned}
        x_1 + 2x_2 - x_3 + 2x_4 &= 3\\\\
        3x_1 + 2x_2 - x_3 + 3x_4 &= 4
        \\end{aligned}\\]
      </div>

      <div class="section-label">Augmented matrix → echelon form</div>
      <div class="math-block">
        \\[
        \\left[\\begin{array}{cccc|c}1&2&-1&2&3\\\\3&2&-1&3&4\\end{array}\\right]
        \\xrightarrow{R_2 \\to R_2-3R_1}
        \\left[\\begin{array}{cccc|c}1&2&-1&2&3\\\\0&-4&2&-3&-5\\end{array}\\right]
        \\]
      </div>
      <p style="color:var(--text-dim);">Pivots are in columns 1 and 2, so \\(x_3\\) and the free-variable structure gives \\(x_4\\) as a determined pivot. Free variables: \\(x_2=\\alpha,\\; x_3=\\beta\\); pivot: \\(x_4=1\\).</p>

      <div class="section-label">Free variables: <span class="free-var">x₂ = α</span> &nbsp;<span class="free-var">x₃ = β</span></div>
      <ul class="steps">
        <li>From \\(R_2\\): \\(-4\\alpha + 2\\beta - 3x_4 = -5\\). With \\(x_4 = 1\\): \\(-4\\alpha+2\\beta-3=-5 \\Rightarrow\\) consistent.</li>
        <li>From \\(R_1\\): \\(x_1 = 3 - 2\\alpha + \\beta - 2(1) = 1 - 2\\alpha + \\beta\\)</li>
      </ul>

      <div class="answer">
        <span class="answer-label">Solution (α, β ∈ ℝ)</span>
        \\(x_1 = 1-2\\alpha+\\beta,\\quad x_2 = \\alpha,\\quad x_3 = \\beta,\\quad x_4 = 1\\)
      </div>
    </div>
  </div>

  <!-- PROBLEM 3 -->
  <div class="problem" id="p3">
    <div class="problem-header">
      <span class="problem-num">Problem 03</span>
      <span class="problem-title">3 equations, 4 unknowns</span>
      <span class="badge badge-inf">1-parameter family</span>
    </div>
    <div class="problem-body">

      <div class="section-label">System</div>
      <div class="math-block">
        \\[\\begin{aligned}
        x_1 - 2x_2 - 3x_3 - 2x_4 &= 0\\\\
        -x_1 + 4x_2 + 4x_3 + 2x_4 &= 4\\\\
        2x_1 - 2x_2 - 3x_3 - 8x_4 &= 8
        \\end{aligned}\\]
      </div>

      <div class="section-label">Row reduction</div>
      <div class="math-block">
        \\[
        \\left[\\begin{array}{cccc|c}1&-2&-3&-2&0\\\\-1&4&4&2&4\\\\2&-2&-3&-8&8\\end{array}\\right]
        \\xrightarrow{R_2+R_1,\\;R_3-2R_1}
        \\left[\\begin{array}{cccc|c}1&-2&-3&-2&0\\\\0&2&1&0&4\\\\0&2&3&-4&8\\end{array}\\right]
        \\xrightarrow{R_3-R_2}
        \\left[\\begin{array}{cccc|c}1&-2&-3&-2&0\\\\0&2&1&0&4\\\\0&0&2&-4&4\\end{array}\\right]
        \\]
      </div>

      <div class="section-label">Free variable: <span class="free-var">x₄ = α</span></div>
      <ul class="steps">
        <li>\\(R_3\\): \\(2x_3 - 4\\alpha = 4 \\Rightarrow x_3 = 2+2\\alpha\\)</li>
        <li>\\(R_2\\): \\(2x_2 + (2+2\\alpha) = 4 \\Rightarrow x_2 = 1-\\alpha\\)</li>
        <li>\\(R_1\\): \\(x_1 = 2(1-\\alpha)+3(2+2\\alpha)+2\\alpha = 2-2\\alpha+6+6\\alpha+2\\alpha = 8+6\\alpha\\)</li>
      </ul>

      <div class="answer">
        <span class="answer-label">Solution (α ∈ ℝ)</span>
        \\(x_1 = 8+6\\alpha,\\quad x_2 = 1-\\alpha,\\quad x_3 = 2+2\\alpha,\\quad x_4 = \\alpha\\)
      </div>
    </div>
  </div>

  <!-- PROBLEM 4 -->
  <div class="problem" id="p4">
    <div class="problem-header">
      <span class="problem-num">Problem 04</span>
      <span class="problem-title">4 equations, 4 unknowns</span>
      <span class="badge badge-inf">1-parameter family</span>
    </div>
    <div class="problem-body">

      <div class="section-label">System</div>
      <div class="math-block">
        \\[\\begin{aligned}
        x_1 - 2x_2 - 3x_3 - 2x_4 &= 0\\\\
        2x_1 - 2x_2 - 5x_3 - 4x_4 &= 4\\\\
        x_1 + 2x_2 + x_3 - 6x_4 &= 12\\\\
        -x_1 + 4x_2 + 6x_3 - 2x_4 &= 8
        \\end{aligned}\\]
      </div>

      <div class="section-label">Row reduction</div>
      <div class="math-block">
        \\[
        \\left[\\begin{array}{cccc|c}1&-2&-3&-2&0\\\\2&-2&-5&-4&4\\\\1&2&1&-6&12\\\\-1&4&6&-2&8\\end{array}\\right]
        \\xrightarrow{R_2-2R_1,\\;R_3-R_1,\\;R_4+R_1}
        \\left[\\begin{array}{cccc|c}1&-2&-3&-2&0\\\\0&2&1&0&4\\\\0&4&4&-4&12\\\\0&2&3&-4&8\\end{array}\\right]
        \\]
        \\[
        \\xrightarrow{R_3-2R_2,\\;R_4-R_2}
        \\left[\\begin{array}{cccc|c}1&-2&-3&-2&0\\\\0&2&1&0&4\\\\0&0&2&-4&4\\\\0&0&2&-4&4\\end{array}\\right]
        \\xrightarrow{R_4-R_3}
        \\left[\\begin{array}{cccc|c}1&-2&-3&-2&0\\\\0&2&1&0&4\\\\0&0&2&-4&4\\\\0&0&0&0&0\\end{array}\\right]
        \\]
      </div>

      <p>Zero row confirms one free variable — same structure as Problem 3.</p>

      <div class="section-label">Free variable: <span class="free-var">x₄ = α</span></div>
      <ul class="steps">
        <li>\\(R_3\\): \\(2x_3 - 4\\alpha = 4 \\Rightarrow x_3 = 2+2\\alpha\\)</li>
        <li>\\(R_2\\): \\(2x_2 + (2+2\\alpha) = 4 \\Rightarrow x_2 = 1-\\alpha\\)</li>
        <li>\\(R_1\\): \\(x_1 = 8+6\\alpha\\) (same as P3)</li>
      </ul>

      <div class="answer">
        <span class="answer-label">Solution (α ∈ ℝ) — identical to Problem 3</span>
        \\(x_1 = 8+6\\alpha,\\quad x_2 = 1-\\alpha,\\quad x_3 = 2+2\\alpha,\\quad x_4 = \\alpha\\)
      </div>
    </div>
  </div>

  <!-- PROBLEM 5 -->
  <div class="problem" id="p5">
    <div class="problem-header">
      <span class="problem-num">Problem 05</span>
      <span class="problem-title">4 equations, 4 unknowns</span>
      <span class="badge badge-uni">Unique solution</span>
    </div>
    <div class="problem-body">

      <div class="section-label">System</div>
      <div class="math-block">
        \\[\\begin{aligned}
        x_2 + 2x_3 - 4x_4 &= 1\\\\
        x_1 + 3x_2 - 2x_3 + 2x_4 &= 6\\\\
        -x_2 + 2x_3 + 7x_4 &= 6\\\\
        x_1 + 3x_2 - x_3 + 3x_4 &= 8
        \\end{aligned}\\]
      </div>

      <div class="section-label">Augmented matrix — reorder so leading x₁ row is first</div>
      <div class="math-block">
        \\[
        \\left[\\begin{array}{cccc|c}1&3&-2&2&6\\\\0&1&2&-4&1\\\\0&-1&2&7&6\\\\1&3&-1&3&8\\end{array}\\right]
        \\xrightarrow{R_4-R_1}
        \\left[\\begin{array}{cccc|c}1&3&-2&2&6\\\\0&1&2&-4&1\\\\0&-1&2&7&6\\\\0&0&1&1&2\\end{array}\\right]
        \\]
        \\[
        \\xrightarrow{R_3+R_2}
        \\left[\\begin{array}{cccc|c}1&3&-2&2&6\\\\0&1&2&-4&1\\\\0&0&4&3&7\\\\0&0&1&1&2\\end{array}\\right]
        \\xrightarrow{R_3-4R_4}
        \\left[\\begin{array}{cccc|c}1&3&-2&2&6\\\\0&1&2&-4&1\\\\0&0&0&-1&-1\\\\0&0&1&1&2\\end{array}\\right]
        \\xrightarrow{R_3\\leftrightarrow R_4}
        \\left[\\begin{array}{cccc|c}1&3&-2&2&6\\\\0&1&2&-4&1\\\\0&0&1&1&2\\\\0&0&0&-1&-1\\end{array}\\right]
        \\]
      </div>

      <div class="section-label">Back substitution — no free variables</div>
      <ul class="steps">
        <li>\\(-x_4 = -1 \\Rightarrow x_4 = 1\\)</li>
        <li>\\(x_3 + 1 = 2 \\Rightarrow x_3 = 1\\)</li>
        <li>\\(x_2 + 2(1) - 4(1) = 1 \\Rightarrow x_2 = 3\\)</li>
        <li>\\(x_1 + 3(3) - 2(1) + 2(1) = 6 \\Rightarrow x_1 = 6-9+2-2 = -3\\)</li>
      </ul>

      <div class="answer" style="border-color:rgba(152,195,121,0.4); background:rgba(152,195,121,0.06);">
        <span class="answer-label" style="color:var(--green);">Unique Solution</span>
        \\(x_1 = -3,\\quad x_2 = 3,\\quad x_3 = 1,\\quad x_4 = 1\\)
      </div>
    </div>
  </div>

  <!-- PROBLEM 6 -->
  <div class="problem" id="p6">
    <div class="problem-header">
      <span class="problem-num">Problem 06</span>
      <span class="problem-title">4 equations, 4 unknowns</span>
      <span class="badge badge-none">No solution</span>
    </div>
    <div class="problem-body">

      <div class="section-label">System</div>
      <div class="math-block">
        \\[\\begin{aligned}
        x_1 - 2x_2 + 2x_3 + 5x_4 &= 1\\\\
        x_2 + x_3 + 2x_4 &= 2\\\\
        x_1 - 2x_2 + x_3 + 8x_4 &= 5\\\\
        2x_2 + x_3 + 7x_4 &= 9
        \\end{aligned}\\]
      </div>

      <div class="section-label">Row reduction</div>
      <div class="math-block">
        \\[
        \\left[\\begin{array}{cccc|c}1&-2&2&5&1\\\\0&1&1&2&2\\\\1&-2&1&8&5\\\\0&2&1&7&9\\end{array}\\right]
        \\xrightarrow{R_3-R_1}
        \\left[\\begin{array}{cccc|c}1&-2&2&5&1\\\\0&1&1&2&2\\\\0&0&-1&3&4\\\\0&2&1&7&9\\end{array}\\right]
        \\xrightarrow{R_4-2R_2}
        \\left[\\begin{array}{cccc|c}1&-2&2&5&1\\\\0&1&1&2&2\\\\0&0&-1&3&4\\\\0&0&-1&3&5\\end{array}\\right]
        \\]
        \\[
        \\xrightarrow{R_4-R_3}
        \\left[\\begin{array}{cccc|c}1&-2&2&5&1\\\\0&1&1&2&2\\\\0&0&-1&3&4\\\\0&0&0&0&1\\end{array}\\right]
        \\]
      </div>

      <p>Last row reads \\(0x_1 + 0x_2 + 0x_3 + 0x_4 = 1\\) — a contradiction.</p>

      <div class="answer-none">
        <span class="answer-label" style="color:var(--red); font-family:'JetBrains Mono',monospace; font-size:10px; letter-spacing:0.2em; display:block; margin-bottom:6px;">Result</span>
        <strong>NO SOLUTION</strong> — inconsistent system
      </div>
    </div>
  </div>

</main>

<footer>
  Linear Algebra · HW 2 · More Linear Systems
</footer>

</body>
</html>
`;export{n as default};
