const e=`Symbols

& → address-of → gives memory address of a variable.

* → dereference → follows a pointer to get/change the value it points to.
`;export{e as default};
