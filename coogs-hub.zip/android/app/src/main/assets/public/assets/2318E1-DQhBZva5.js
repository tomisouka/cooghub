const n=`# Linear Algebra Exam Review · Step-by-Step Solutions

Each question includes the **restated problem**, general method, a worked **illustrative example**, and the final simple answer. (Original matrix entries are replaced with clear sample numbers.)

---

## Question 1 · Matrix Operations

> 📖 **Concept:** Matrix Addition, Scalar Multiplication & Matrix Product

**Restated:** Given matrices $A, B, C, D, E$ (all $2\\times2$ for this example), compute when defined:  
$(a)\\ D+E \\quad (b)\\ A+2C \\quad (c)\\ AB \\quad (d)\\ DC$.

**▸ General steps:**
- Check size compatibility: addition requires identical dimensions; multiplication requires $\\#\\text{cols}_\\text{first} = \\#\\text{rows}_\\text{second}$.
- For addition/scalar multiplication: operate entry-wise.
- For product $AB$: $(AB)_{ij} = \\sum_k A_{ik}B_{kj}$.

**📌 Illustrative example ($2\\times2$ matrices)**

$$
A=\\begin{bmatrix}1&2\\\\3&4\\end{bmatrix},\\;
B=\\begin{bmatrix}5&6\\\\7&8\\end{bmatrix},\\;
C=\\begin{bmatrix}9&10\\\\11&12\\end{bmatrix},\\;
D=\\begin{bmatrix}13&14\\\\15&16\\end{bmatrix},\\;
E=\\begin{bmatrix}17&18\\\\19&20\\end{bmatrix}
$$

**(a) $D+E$**
$$D+E = \\begin{bmatrix}13+17 & 14+18\\\\15+19 & 16+20\\end{bmatrix} = \\begin{bmatrix}30 & 32\\\\34 & 36\\end{bmatrix}$$

**(b) $A+2C$**
$$2C = \\begin{bmatrix}18&20\\\\22&24\\end{bmatrix},\\quad A+2C = \\begin{bmatrix}1+18 & 2+20\\\\3+22 & 4+24\\end{bmatrix} = \\begin{bmatrix}19 & 22\\\\25 & 28\\end{bmatrix}$$

**(c) $AB$**
$$AB = \\begin{bmatrix}1\\cdot5+2\\cdot7 & 1\\cdot6+2\\cdot8\\\\3\\cdot5+4\\cdot7 & 3\\cdot6+4\\cdot8\\end{bmatrix} = \\begin{bmatrix}19 & 22\\\\43 & 50\\end{bmatrix}$$

**(d) $DC$**
$$DC = \\begin{bmatrix}13\\cdot9+14\\cdot11 & 13\\cdot10+14\\cdot12\\\\15\\cdot9+16\\cdot11 & 15\\cdot10+16\\cdot12\\end{bmatrix} = \\begin{bmatrix}271 & 298\\\\311 & 342\\end{bmatrix}$$

✅ **Simple answers:**  
(a) $\\begin{bmatrix}30&32\\\\34&36\\end{bmatrix}$ &nbsp; (b) $\\begin{bmatrix}19&22\\\\25&28\\end{bmatrix}$ &nbsp; (c) $\\begin{bmatrix}19&22\\\\43&50\\end{bmatrix}$ &nbsp; (d) $\\begin{bmatrix}271&298\\\\311&342\\end{bmatrix}$

---

## Question 2 · Gaussian Elimination

> 📖 **Concept:** Gaussian Elimination & Row Echelon Form

**Restated:** Write the given linear system as an augmented matrix, reduce to echelon form by Gaussian elimination, and find all solutions (if any).

**▸ General steps:**
- Build augmented matrix $[A \\mid \\mathbf{b}]$.
- Use row operations (swap, scale, add multiple) to reach upper triangular (row echelon) form.
- Back-substitute to obtain solution(s). If a row $[0\\cdots0 \\mid c]$ with $c\\neq0$ appears, the system is inconsistent.

**📌 Illustrative example (2 equations, 2 unknowns)**

$$\\begin{cases}x + 2y = 3\\\\4x + 5y = 6\\end{cases} \\quad\\Rightarrow\\quad \\left[\\begin{array}{cc|c}1&2&3\\\\4&5&6\\end{array}\\right]$$

$R_2 \\leftarrow R_2 - 4R_1$:

$$\\left[\\begin{array}{cc|c}1&2&3\\\\0&-3&-6\\end{array}\\right]$$

From second row: $-3y = -6 \\Rightarrow y = 2$. Substitute into first: $x + 2(2) = 3 \\Rightarrow x = -1$.

✅ **Simple answer:** $x = -1,\\; y = 2$

---

## Question 3 · Linear Combinations

> 📖 **Concept:** Span & Linear Combinations

**Restated:** If true, write the given vector as a linear combination of the two spanning vectors. Show all work.

**▸ General steps:**
- Set up $c_1\\mathbf{v}_1 + c_2\\mathbf{v}_2 = \\mathbf{w}$.
- Solve the resulting linear system for $c_1, c_2$.
- If a solution exists, express $\\mathbf{w} = c_1\\mathbf{v}_1 + c_2\\mathbf{v}_2$; otherwise state impossible.

**📌 Illustrative example**

$$\\mathbf{v}_1 = \\begin{bmatrix}1\\\\2\\end{bmatrix},\\quad \\mathbf{v}_2 = \\begin{bmatrix}3\\\\4\\end{bmatrix},\\quad \\mathbf{w} = \\begin{bmatrix}5\\\\6\\end{bmatrix}$$

Need $c_1\\begin{bmatrix}1\\\\2\\end{bmatrix} + c_2\\begin{bmatrix}3\\\\4\\end{bmatrix} = \\begin{bmatrix}5\\\\6\\end{bmatrix}$.

$$\\begin{cases}c_1 + 3c_2 = 5\\\\2c_1 + 4c_2 = 6\\end{cases}$$

From first: $c_1 = 5-3c_2$. Substitute: $2(5-3c_2)+4c_2 = 6 \\Rightarrow -2c_2 = -4 \\Rightarrow c_2 = 2$. Then $c_1 = -1$.

Check: $-1\\begin{bmatrix}1\\\\2\\end{bmatrix}+2\\begin{bmatrix}3\\\\4\\end{bmatrix} = \\begin{bmatrix}5\\\\6\\end{bmatrix}$ ✓

✅ **Simple answer:** $\\mathbf{w} = -1\\,\\mathbf{v}_1 + 2\\,\\mathbf{v}_2$

---

## Question 4 · Subspaces — Basis & Dimension

> 📖 **Concept:** Basis, Dimension & Subspaces

**Restated:** For each of the two given subspaces, determine its standard basis and state its dimension.

**▸ General steps:**
- If subspace is given as a span of a set, extract a linearly independent subset (e.g., column reduce).
- If given as a solution set (e.g., null space of a matrix), solve the homogeneous system to find fundamental vectors.
- Dimension = number of vectors in any basis.

**📌 Two subspaces of $\\mathbb{R}^3$**

**Subspace $S_1$:** $\\text{span}\\left\\{\\begin{bmatrix}1\\\\0\\\\1\\end{bmatrix},\\begin{bmatrix}0\\\\1\\\\0\\end{bmatrix},\\begin{bmatrix}1\\\\1\\\\1\\end{bmatrix}\\right\\}$

Form matrix with these as columns and reduce:

$$\\begin{bmatrix}1&0&1\\\\0&1&1\\\\1&0&1\\end{bmatrix} \\xrightarrow{R_3-R_1} \\begin{bmatrix}1&0&1\\\\0&1&1\\\\0&0&0\\end{bmatrix}$$

Pivot columns 1 and 2 → basis: $\\left\\{\\begin{bmatrix}1\\\\0\\\\1\\end{bmatrix},\\begin{bmatrix}0\\\\1\\\\0\\end{bmatrix}\\right\\}$. Dimension = 2.

**Subspace $S_2$:** $\\left\\{\\begin{bmatrix}x\\\\y\\\\z\\end{bmatrix}\\mid x+y+z=0\\right\\}$ (plane).

$x = -y -z$ → vectors: $\\begin{bmatrix}-y-z\\\\y\\\\z\\end{bmatrix} = y\\begin{bmatrix}-1\\\\1\\\\0\\end{bmatrix}+z\\begin{bmatrix}-1\\\\0\\\\1\\end{bmatrix}$

Basis: $\\left\\{\\begin{bmatrix}-1\\\\1\\\\0\\end{bmatrix},\\begin{bmatrix}-1\\\\0\\\\1\\end{bmatrix}\\right\\}$. Dimension = 2.

✅ **Simple answers:**  
$S_1$ basis $\\left\\{\\begin{bmatrix}1\\\\0\\\\1\\end{bmatrix},\\begin{bmatrix}0\\\\1\\\\0\\end{bmatrix}\\right\\}$, dim = 2  
$S_2$ basis $\\left\\{\\begin{bmatrix}-1\\\\1\\\\0\\end{bmatrix},\\begin{bmatrix}-1\\\\0\\\\1\\end{bmatrix}\\right\\}$, dim = 2

---

## Question 5 · Null Space & Range (Column Space)

> 📖 **Concept:** Null Space, Column Space & Linear Operators

**Restated:** For the given matrix $A$ (defines $\\mathcal{L}(\\mathbf{x}) = A\\mathbf{x}$), determine a basis for the null space and a basis for the range space (standard basis for the column space).

**▸ General steps:**
- **Null space:** solve $A\\mathbf{x}= \\mathbf{0}$. Write augmented matrix, reduce; express pivot variables in terms of free variables. Special solutions form a basis.
- **Range (column space):** columns of $A$ span the range. Reduce $A$ to echelon form; pivot columns of the *original* matrix give a basis.

**📌 Example matrix $A = \\begin{bmatrix}1&2&3\\\\4&5&6\\end{bmatrix}$ (2×3)**

**Null space:** solve $A\\mathbf{x}=0$.

$$\\left[\\begin{array}{ccc|c}1&2&3&0\\\\4&5&6&0\\end{array}\\right] \\xrightarrow{R_2-4R_1} \\left[\\begin{array}{ccc|c}1&2&3&0\\\\0&-3&-6&0\\end{array}\\right]$$

$-3x_2-6x_3=0 \\Rightarrow x_2 = -2x_3$; &nbsp; $x_1+2(-2x_3)+3x_3=0 \\Rightarrow x_1 = x_3$.

$$\\mathbf{x} = x_3\\begin{bmatrix}1\\\\-2\\\\1\\end{bmatrix} \\quad\\Rightarrow\\quad \\text{null space basis: } \\left\\{\\begin{bmatrix}1\\\\-2\\\\1\\end{bmatrix}\\right\\}$$

**Range (column space):** echelon form has pivots in columns 1 and 2 → basis from original $A$:

$$\\left\\{\\begin{bmatrix}1\\\\4\\end{bmatrix},\\begin{bmatrix}2\\\\5\\end{bmatrix}\\right\\}$$

✅ **Simple answers:**  
Null space basis: $\\left\\{\\begin{bmatrix}1\\\\-2\\\\1\\end{bmatrix}\\right\\}$  
Range basis: $\\left\\{\\begin{bmatrix}1\\\\4\\end{bmatrix},\\begin{bmatrix}2\\\\5\\end{bmatrix}\\right\\}$

---

*All examples are illustrative. For the actual exam, replace numbers with the given ones — the procedures remain identical.*`;export{n as default};
