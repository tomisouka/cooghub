const n=`<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>COSC 3320 · Intro Exam Solutions</title>
    <link href="https://fonts.googleapis.com/css2?family=DM+Serif+Display:ital@0;1&family=DM+Mono:wght@400;500&family=Outfit:wght@300;400;500;600&display=swap" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/mathjax@3/es5/tex-chtml.js"><\/script>
    <style>
        :root {
            --bg: #0e0f14;
            --surface: #14161e;
            --surface2: #1c1f2b;
            --border: #252836;
            --accent: #c8a96e;
            --accent2: #7eb8c9;
            --green: #5dbd8a;
            --red: #e07070;
            --yellow: #d4a843;
            --text: #e8e6df;
            --muted: #7a7d8c;
        }

        * { box-sizing: border-box; margin: 0; padding: 0; }

        body {
            background: var(--bg);
            font-family: 'Outfit', sans-serif;
            color: var(--text);
            line-height: 1.7;
            padding: 2rem 1rem 6rem;
            min-height: 100vh;
        }

        body::before {
            content: '';
            position: fixed;
            inset: 0;
            background-image:
                linear-gradient(rgba(200,169,110,0.03) 1px, transparent 1px),
                linear-gradient(90deg, rgba(200,169,110,0.03) 1px, transparent 1px);
            background-size: 40px 40px;
            pointer-events: none;
            z-index: 0;
        }

        .page {
            max-width: 860px;
            margin: 0 auto;
            position: relative;
            z-index: 1;
        }

        /* HEADER */
        header {
            padding: 3rem 0 2.5rem;
            border-bottom: 1px solid var(--border);
            margin-bottom: 3rem;
            animation: fadeDown 0.6s ease both;
        }

        .course-tag {
            font-family: 'DM Mono', monospace;
            font-size: 0.75rem;
            color: var(--accent);
            letter-spacing: 0.2em;
            text-transform: uppercase;
            margin-bottom: 0.8rem;
        }

        h1 {
            font-family: 'DM Serif Display', serif;
            font-size: clamp(2rem, 5vw, 3.2rem);
            font-weight: 400;
            color: var(--text);
            line-height: 1.15;
            margin-bottom: 1rem;
        }

        h1 em { font-style: italic; color: var(--accent); }

        .header-meta {
            font-size: 0.95rem;
            color: var(--muted);
            max-width: 560px;
        }

        .score-badge {
            display: inline-block;
            margin-top: 1.2rem;
            font-family: 'DM Mono', monospace;
            font-size: 0.8rem;
            color: var(--red);
            background: rgba(224,112,112,0.08);
            border: 1px solid rgba(224,112,112,0.25);
            border-radius: 8px;
            padding: 0.3rem 0.8rem;
            letter-spacing: 0.05em;
        }

        /* NAV */
        .nav-pills {
            display: flex;
            flex-wrap: wrap;
            gap: 0.5rem;
            margin-bottom: 3rem;
            animation: fadeDown 0.6s 0.1s ease both;
        }

        .nav-pill {
            font-family: 'DM Mono', monospace;
            font-size: 0.72rem;
            color: var(--muted);
            border: 1px solid var(--border);
            border-radius: 100px;
            padding: 0.3rem 0.9rem;
            cursor: pointer;
            transition: all 0.2s;
            text-decoration: none;
            letter-spacing: 0.05em;
        }

        .nav-pill:hover {
            color: var(--accent);
            border-color: var(--accent);
            background: rgba(200,169,110,0.06);
        }

        /* PROBLEM CARD */
        .p-card {
            background: var(--surface);
            border: 1px solid var(--border);
            border-radius: 20px;
            margin-bottom: 2rem;
            overflow: hidden;
            animation: fadeUp 0.5s ease both;
        }

        .p-card:nth-child(1) { animation-delay: 0.05s; }
        .p-card:nth-child(2) { animation-delay: 0.10s; }
        .p-card:nth-child(3) { animation-delay: 0.15s; }

        .p-header {
            display: flex;
            align-items: center;
            gap: 1rem;
            padding: 1.4rem 1.8rem;
            border-bottom: 1px solid var(--border);
            background: var(--surface2);
        }

        .p-num {
            font-family: 'DM Mono', monospace;
            font-size: 0.7rem;
            color: var(--accent);
            background: rgba(200,169,110,0.1);
            border: 1px solid rgba(200,169,110,0.25);
            border-radius: 8px;
            padding: 0.25rem 0.6rem;
            letter-spacing: 0.1em;
            flex-shrink: 0;
        }

        .p-title {
            font-family: 'DM Serif Display', serif;
            font-size: 1.25rem;
            font-weight: 400;
            color: var(--text);
            flex: 1;
        }

        .p-points {
            font-family: 'DM Mono', monospace;
            font-size: 0.7rem;
            color: var(--muted);
            flex-shrink: 0;
        }

        /* CONCEPT ROW */
        .concept-row {
            padding: 0.9rem 1.8rem;
            border-bottom: 1px solid var(--border);
            display: flex;
            align-items: center;
            gap: 0.6rem;
            flex-wrap: wrap;
        }

        .concept-label {
            font-family: 'DM Mono', monospace;
            font-size: 0.65rem;
            color: var(--muted);
            text-transform: uppercase;
            letter-spacing: 0.15em;
        }

        .concept-tag {
            font-family: 'DM Mono', monospace;
            font-size: 0.72rem;
            color: var(--accent2);
            background: rgba(126,184,201,0.08);
            border: 1px solid rgba(126,184,201,0.2);
            border-radius: 100px;
            padding: 0.15rem 0.7rem;
        }

        .concept-ref {
            font-family: 'DM Mono', monospace;
            font-size: 0.68rem;
            color: var(--muted);
            font-style: italic;
        }

        /* CARD BODY */
        .p-body { padding: 1.6rem 1.8rem; }

        /* SUBPROBLEM */
        .subproblem {
            border: 1px solid var(--border);
            border-radius: 14px;
            margin-bottom: 1.2rem;
            overflow: hidden;
        }

        .sub-header {
            display: flex;
            align-items: center;
            justify-content: space-between;
            padding: 0.7rem 1.2rem;
            background: var(--surface2);
            border-bottom: 1px solid var(--border);
        }

        .sub-label {
            font-family: 'DM Mono', monospace;
            font-size: 0.75rem;
            color: var(--accent);
            letter-spacing: 0.08em;
        }

        .sub-points {
            font-family: 'DM Mono', monospace;
            font-size: 0.68rem;
            color: var(--muted);
        }

        .sub-body { padding: 1.1rem 1.3rem; }

        .section-label {
            font-family: 'DM Mono', monospace;
            font-size: 0.65rem;
            text-transform: uppercase;
            letter-spacing: 0.15em;
            color: var(--muted);
            margin-bottom: 0.4rem;
        }

        /* INFORMAL */
        .informal {
            background: rgba(200,169,110,0.05);
            border-left: 3px solid var(--accent);
            border-radius: 0 10px 10px 0;
            padding: 0.8rem 1rem;
            margin: 0.8rem 0;
            font-size: 0.9rem;
            color: #c8c4bb;
        }

        /* FORMAL */
        .formal {
            background: var(--surface2);
            border-radius: 10px;
            padding: 0.9rem 1.1rem;
            margin: 0.8rem 0;
            border: 1px solid var(--border);
            font-size: 0.9rem;
            color: #b8b4ac;
        }

        .formal strong { color: var(--text); }

        /* STUDENT ANSWER */
        .student-answer {
            display: flex;
            align-items: flex-start;
            gap: 0.6rem;
            padding: 0.7rem 1rem;
            border-radius: 10px;
            margin-top: 0.8rem;
            font-size: 0.88rem;
        }

        .student-answer.correct {
            background: rgba(93,189,138,0.07);
            border: 1px solid rgba(93,189,138,0.2);
            color: #d4f0e3;
        }

        .student-answer.incorrect {
            background: rgba(224,112,112,0.06);
            border: 1px solid rgba(224,112,112,0.18);
            color: #f0d4d4;
        }

        .student-answer.partial {
            background: rgba(212,168,67,0.07);
            border: 1px solid rgba(212,168,67,0.2);
            color: #f0e8d4;
        }

        .answer-icon { flex-shrink: 0; font-size: 0.9rem; }

        .answer-label-sm {
            font-family: 'DM Mono', monospace;
            font-size: 0.62rem;
            text-transform: uppercase;
            letter-spacing: 0.12em;
            opacity: 0.7;
            margin-bottom: 0.15rem;
        }

        /* CORRECT ANSWER BOX */
        .correct-answer {
            background: rgba(93,189,138,0.07);
            border: 1px solid rgba(93,189,138,0.25);
            border-radius: 12px;
            padding: 1rem 1.2rem;
            margin-top: 0.8rem;
            display: flex;
            gap: 0.8rem;
            align-items: flex-start;
        }

        .correct-answer .check { flex-shrink: 0; font-size: 1rem; }

        .correct-answer .content { flex: 1; }

        .correct-answer .answer-label {
            font-family: 'DM Mono', monospace;
            font-size: 0.63rem;
            text-transform: uppercase;
            letter-spacing: 0.15em;
            color: var(--green);
            margin-bottom: 0.3rem;
        }

        .correct-answer p { font-size: 0.9rem; color: #d4f0e3; }

        /* STEPS */
        .steps {
            background: var(--surface2);
            border-radius: 10px;
            padding: 0.9rem 1.1rem;
            border: 1px solid var(--border);
            margin: 0.8rem 0;
        }

        .steps ul { list-style: none; margin-top: 0.4rem; display: flex; flex-direction: column; gap: 0.4rem; }

        .steps li {
            display: flex;
            gap: 0.6rem;
            font-size: 0.88rem;
            color: #b8b4ac;
            align-items: flex-start;
        }

        .steps li::before {
            content: '→';
            color: var(--accent);
            font-family: 'DM Mono', monospace;
            font-size: 0.78rem;
            margin-top: 0.15rem;
            flex-shrink: 0;
        }

        /* CODE BLOCK */
        pre {
            background: #0a0b10;
            border: 1px solid var(--border);
            border-radius: 10px;
            padding: 1rem 1.2rem;
            font-family: 'DM Mono', monospace;
            font-size: 0.82rem;
            color: #a8d4b8;
            overflow-x: auto;
            margin: 0.8rem 0;
            line-height: 1.6;
        }

        /* SUMMARY TABLE */
        .summary-section {
            background: var(--surface);
            border: 1px solid var(--border);
            border-radius: 20px;
            overflow: hidden;
            margin-top: 2.5rem;
            animation: fadeUp 0.5s 0.3s ease both;
        }

        .summary-header {
            padding: 1.2rem 1.8rem;
            background: var(--surface2);
            border-bottom: 1px solid var(--border);
        }

        .summary-header h2 {
            font-family: 'DM Serif Display', serif;
            font-size: 1.3rem;
            font-weight: 400;
            color: var(--text);
        }

        table {
            width: 100%;
            border-collapse: collapse;
            font-size: 0.87rem;
        }

        th {
            font-family: 'DM Mono', monospace;
            font-size: 0.65rem;
            text-transform: uppercase;
            letter-spacing: 0.12em;
            color: var(--muted);
            padding: 0.7rem 1.2rem;
            text-align: left;
            border-bottom: 1px solid var(--border);
            background: var(--surface2);
        }

        td {
            padding: 0.65rem 1.2rem;
            border-bottom: 1px solid rgba(37,40,54,0.6);
            color: #c0bdb5;
            vertical-align: middle;
        }

        tr:last-child td { border-bottom: none; }
        tr:hover td { background: rgba(255,255,255,0.01); }

        .result-pass { color: var(--green); font-size: 1rem; }
        .result-fail { color: var(--red); font-size: 1rem; }
        .result-partial { color: var(--yellow); font-size: 0.85rem; font-family: 'DM Mono', monospace; }

        .total-row td {
            font-family: 'DM Mono', monospace;
            font-size: 0.8rem;
            color: var(--red);
            border-top: 1px solid var(--border);
            padding-top: 1rem;
            font-weight: 500;
        }

        /* PROOF BLOCK */
        .proof-block {
            background: #0a0b10;
            border: 1px solid var(--border);
            border-radius: 10px;
            padding: 1rem 1.3rem;
            margin: 0.8rem 0;
            font-size: 0.9rem;
            color: #c0bdb5;
            line-height: 1.9;
        }

        /* DIVIDER */
        .divider {
            border: none;
            border-top: 1px solid var(--border);
            margin: 1.5rem 0;
        }

        /* FOOTER */
        footer {
            margin-top: 4rem;
            padding-top: 2rem;
            border-top: 1px solid var(--border);
            text-align: center;
            font-family: 'DM Mono', monospace;
            font-size: 0.75rem;
            color: var(--muted);
            letter-spacing: 0.05em;
            animation: fadeUp 0.5s 0.4s ease both;
        }

        @keyframes fadeDown {
            from { opacity: 0; transform: translateY(-16px); }
            to   { opacity: 1; transform: translateY(0); }
        }

        @keyframes fadeUp {
            from { opacity: 0; transform: translateY(20px); }
            to   { opacity: 1; transform: translateY(0); }
        }

        ::-webkit-scrollbar { width: 6px; }
        ::-webkit-scrollbar-track { background: var(--bg); }
        ::-webkit-scrollbar-thumb { background: var(--border); border-radius: 3px; }

        @media (max-width: 600px) {
            .p-header { flex-wrap: wrap; }
            .p-body { padding: 1.2rem 1rem; }
            .concept-row { padding: 0.8rem 1rem; }
            td, th { padding: 0.5rem 0.8rem; }
        }
    </style>
</head>
<body>
<div class="page">

    <header>
        <div class="course-tag">COSC 3320 · Intro Exam · Solutions</div>
        <h1>Exam<br><em>solutions</em></h1>
        <p class="header-meta">Full solutions with formal answers, informal explanations, and student response analysis.</p>
        <div class="score-badge">Total as marked: 22 / 100</div>
    </header>

    <nav class="nav-pills">
        <a class="nav-pill" href="#p1">P1 · Combinatorics</a>
        <a class="nav-pill" href="#p2">P2 · Induction</a>
        <a class="nav-pill" href="#p3">P3 · Algorithms</a>
        <a class="nav-pill" href="#summary">Summary</a>
    </nav>

    <!-- ══════════════════ PROBLEM 1 ══════════════════ -->
    <div class="p-card" id="p1">
        <div class="p-header">
            <span class="p-num">P 01</span>
            <span class="p-title">Combinatorics</span>
            <span class="p-points">30 pts</span>
        </div>
        <div class="concept-row">
            <span class="concept-label">Concept</span>
            <span class="concept-tag">Permutations</span>
            <span class="concept-tag">Combinations</span>
            <span class="concept-tag">Arrangements with Repetition</span>
        </div>
        <div class="p-body">

            <p style="color:var(--muted); font-size:0.9rem; margin-bottom:1.2rem;">We have \\(n\\) students and \\(k \\le n\\) movie tickets.</p>

            <!-- (a) -->
            <div class="subproblem">
                <div class="sub-header">
                    <span class="sub-label">(a) Different movies · at most one ticket per student</span>
                    <span class="sub-points">8 pts</span>
                </div>
                <div class="sub-body">
                    <div class="section-label">Informal</div>
                    <div class="informal">You have \\(k\\) distinct tickets and \\(n\\) students. Pick which \\(k\\) students get tickets (\\(\\binom{n}{k}\\) ways), then assign tickets to them (\\(k!\\) ways). Multiply.</div>
                    <div class="formal">
                        <strong>Permutations</strong> of \\(n\\) items taken \\(k\\) at a time:
                        \\[P(n,k) = \\frac{n!}{(n-k)!} = n(n-1)\\cdots(n-k+1)\\]
                    </div>
                    <div class="student-answer incorrect">
                        <span class="answer-icon">❌</span>
                        <div><div class="answer-label-sm">Your answer</div>Mentioned \\(n!\\) and "distinct elements" but no correct formula.</div>
                    </div>
                </div>
            </div>

            <!-- (b) -->
            <div class="subproblem">
                <div class="sub-header">
                    <span class="sub-label">(b) Different movies · any number of tickets per student</span>
                    <span class="sub-points">7 pts</span>
                </div>
                <div class="sub-body">
                    <div class="section-label">Informal</div>
                    <div class="informal">Each of the \\(k\\) tickets can go to any of the \\(n\\) students independently. \\(n\\) choices for each ticket → multiply.</div>
                    <div class="formal">
                        <strong>Arrangements with repetition</strong> (functions from a \\(k\\)-set to an \\(n\\)-set):
                        \\[n^k\\]
                    </div>
                    <div class="student-answer incorrect">
                        <span class="answer-icon">❌</span>
                        <div><div class="answer-label-sm">Your answer</div>Wrote \\(P(n,k)\\) — that was the answer to part (a). Lost 4 points.</div>
                    </div>
                </div>
            </div>

            <!-- (c) -->
            <div class="subproblem">
                <div class="sub-header">
                    <span class="sub-label">(c) Same movie · at most one ticket per student</span>
                    <span class="sub-points">7 pts</span>
                </div>
                <div class="sub-body">
                    <div class="section-label">Informal</div>
                    <div class="informal">Tickets are identical — just choose which \\(k\\) students get one. Order doesn't matter.</div>
                    <div class="formal">
                        <strong>Combinations</strong> (binomial coefficient):
                        \\[\\binom{n}{k} = \\frac{n!}{k!(n-k)!}\\]
                    </div>
                    <div class="student-answer correct">
                        <span class="answer-icon">✅</span>
                        <div><div class="answer-label-sm">Your answer</div>Correct! Full credit.</div>
                    </div>
                </div>
            </div>

            <!-- (d) -->
            <div class="subproblem">
                <div class="sub-header">
                    <span class="sub-label">(d) Asymptotic ranking for \\(k = \\lfloor n/2 \\rfloor\\)</span>
                    <span class="sub-points">8 pts</span>
                </div>
                <div class="sub-body">
                    <div class="section-label">Informal</div>
                    <div class="informal">
                        When \\(n\\) is large: \\(\\binom{n}{n/2}\\) grows like \\(2^n\\); \\(\\frac{n!}{(n/2)!}\\) grows like \\(n^{n/2}\\) but slightly smaller; \\(n^{n/2}\\) is the largest. Slowest → fastest:
                    </div>
                    <div class="formal">
                        \\[\\binom{n}{n/2} \\;\\ll\\; \\frac{n!}{(n/2)!} \\;\\ll\\; n^{n/2}\\]
                        \\[\\binom{n}{n/2} = o\\!\\left(\\frac{n!}{(n/2)!}\\right) \\quad\\text{and}\\quad \\frac{n!}{(n/2)!} = o\\!\\left(n^{n/2}\\right)\\]
                    </div>
                    <div class="student-answer incorrect">
                        <span class="answer-icon">❌</span>
                        <div><div class="answer-label-sm">Your answer</div>Gave some equalities but no clear ordering.</div>
                    </div>
                </div>
            </div>

        </div>
    </div>

    <!-- ══════════════════ PROBLEM 2 ══════════════════ -->
    <div class="p-card" id="p2">
        <div class="p-header">
            <span class="p-num">P 02</span>
            <span class="p-title">Induction</span>
            <span class="p-points">30 pts</span>
        </div>
        <div class="concept-row">
            <span class="concept-label">Concept</span>
            <span class="concept-tag">Mathematical Induction</span>
        </div>
        <div class="p-body">

            <div class="informal" style="margin-bottom:1.2rem;">
                <strong style="color:var(--text);">Statement:</strong> For any positive integer \\(n\\), \\(6^n - 1\\) is divisible by \\(5\\).
            </div>

            <!-- 2.1 -->
            <div class="subproblem">
                <div class="sub-header">
                    <span class="sub-label">1 · Induction variable</span>
                    <span class="sub-points">2 pts</span>
                </div>
                <div class="sub-body">
                    <div class="correct-answer">
                        <span class="check">✓</span>
                        <div class="content">
                            <div class="answer-label">Answer</div>
                            <p>\\(n\\)</p>
                        </div>
                    </div>
                    <div class="student-answer correct" style="margin-top:0.6rem;">
                        <span class="answer-icon">✅</span>
                        <div><div class="answer-label-sm">Your answer</div>"variable we are solving for" — essentially correct.</div>
                    </div>
                </div>
            </div>

            <!-- 2.2 -->
            <div class="subproblem">
                <div class="sub-header">
                    <span class="sub-label">2 · Base case</span>
                    <span class="sub-points">3 pts</span>
                </div>
                <div class="sub-body">
                    <div class="correct-answer">
                        <span class="check">✓</span>
                        <div class="content">
                            <div class="answer-label">Answer</div>
                            <p>\\(n = 1:\\ 6^1 - 1 = 5\\), which is divisible by \\(5\\). ✓</p>
                        </div>
                    </div>
                    <div class="student-answer correct" style="margin-top:0.6rem;">
                        <span class="answer-icon">✅</span>
                        <div><div class="answer-label-sm">Your answer</div>Correct.</div>
                    </div>
                </div>
            </div>

            <!-- 2.3 -->
            <div class="subproblem">
                <div class="sub-header">
                    <span class="sub-label">3 · Induction hypothesis</span>
                    <span class="sub-points">7 pts</span>
                </div>
                <div class="sub-body">
                    <div class="correct-answer">
                        <span class="check">✓</span>
                        <div class="content">
                            <div class="answer-label">Answer</div>
                            <p>Assume that for some positive integer \\(k\\), \\(6^k - 1 = 5m\\) for some integer \\(m\\).</p>
                        </div>
                    </div>
                    <div class="student-answer partial" style="margin-top:0.6rem;">
                        <span class="answer-icon">⚠️</span>
                        <div><div class="answer-label-sm">Your answer</div>"Assume \\(6^n - 1\\) is divisible by 5 for \\(n\\)" — too vague. Lost 3 points.</div>
                    </div>
                </div>
            </div>

            <!-- 2.4 -->
            <div class="subproblem">
                <div class="sub-header">
                    <span class="sub-label">4 · Induction step</span>
                    <span class="sub-points">15 pts</span>
                </div>
                <div class="sub-body">
                    <div class="section-label">What to prove</div>
                    <div class="informal">If \\(6^k - 1\\) is divisible by \\(5\\), then \\(6^{k+1} - 1\\) is also divisible by \\(5\\).</div>
                    <div class="proof-block">
                        \\[\\begin{aligned}
                        6^{k+1} - 1 &= 6\\cdot 6^k - 1 \\\\
                        &= 6(6^k - 1) + 6 - 1 \\\\
                        &= 6(6^k - 1) + 5 \\\\
                        &= 6(5m) + 5 \\quad\\text{(by induction hypothesis)}\\\\
                        &= 5(6m + 1)
                        \\end{aligned}\\]
                        Thus \\(6^{k+1} - 1\\) is a multiple of \\(5\\). ✓
                    </div>
                    <div class="student-answer incorrect" style="margin-top:0.6rem;">
                        <span class="answer-icon">❌</span>
                        <div><div class="answer-label-sm">Your answer</div>Incomplete and messy — lost 7 points.</div>
                    </div>
                </div>
            </div>

            <!-- 2.5 -->
            <div class="subproblem">
                <div class="sub-header">
                    <span class="sub-label">5 · Weak or strong induction?</span>
                    <span class="sub-points">3 pts</span>
                </div>
                <div class="sub-body">
                    <div class="correct-answer">
                        <span class="check">✓</span>
                        <div class="content">
                            <div class="answer-label">Answer</div>
                            <p>Weak induction — \\(P(k+1)\\) depends only on \\(P(k)\\).</p>
                        </div>
                    </div>
                    <div class="student-answer correct" style="margin-top:0.6rem;">
                        <span class="answer-icon">✅</span>
                        <div><div class="answer-label-sm">Your answer</div>Correct.</div>
                    </div>
                </div>
            </div>

        </div>
    </div>

    <!-- ══════════════════ PROBLEM 3 ══════════════════ -->
    <div class="p-card" id="p3">
        <div class="p-header">
            <span class="p-num">P 03</span>
            <span class="p-title">Algorithms</span>
            <span class="p-points">40 pts</span>
        </div>
        <div class="concept-row">
            <span class="concept-label">Concept</span>
            <span class="concept-tag">Recursive Algorithms</span>
            <span class="concept-tag">Recurrence Relations</span>
            <span class="concept-ref">— Pandurangan, Introduction to Algorithms</span>
        </div>
        <div class="p-body">

            <div class="informal" style="margin-bottom:1.2rem;">
                Array \\(A[1..n]\\) of 0s and 1s is <strong style="color:var(--text);">good</strong> if it has an even number of 1s.
            </div>

            <!-- 3a -->
            <div class="subproblem">
                <div class="sub-header">
                    <span class="sub-label">(a) Recursive algorithm — pseudocode</span>
                    <span class="sub-points">20 pts</span>
                </div>
                <div class="sub-body">
                    <div class="section-label">Informal</div>
                    <div class="informal">Check the last element. If 0, parity same as first \\(n-1\\). If 1, parity flips. Recurse.</div>
                    <pre>function isGood(A, n):
  if n == 0:
    return True
  else:
    prev = isGood(A, n-1)
    if A[n] == 0:
      return prev
    else:
      return not prev</pre>
                    <div class="student-answer incorrect" style="margin-top:0.6rem;">
                        <span class="answer-icon">❌</span>
                        <div><div class="answer-label-sm">Your answer</div>Too vague — "divide and conquer," "split mid".</div>
                    </div>
                </div>
            </div>

            <!-- 3b -->
            <div class="subproblem">
                <div class="sub-header">
                    <span class="sub-label">(b) Proof of correctness by induction</span>
                    <span class="sub-points">10 pts</span>
                </div>
                <div class="sub-body">
                    <div class="section-label">Proof</div>
                    <div class="proof-block">
                        <strong style="color:var(--accent2);">Claim:</strong> <code>isGood(A, n)</code> returns True iff first \\(n\\) elements have an even number of 1s.<br><br>
                        <strong style="color:var(--accent2);">Base case</strong> \\(n=0\\): Returns True. Empty array has 0 ones (even). ✓<br><br>
                        <strong style="color:var(--accent2);">Inductive hypothesis:</strong> For any \\(m &lt; n\\), <code>isGood(A, m)</code> is correct.<br><br>
                        <strong style="color:var(--accent2);">Inductive step:</strong> Let \\(p = \\text{isGood}(A, n-1)\\). By hypothesis, \\(p\\) is True iff first \\(n-1\\) elements have even ones.<br>
                        If \\(A[n] = 0\\): total parity unchanged → return \\(p\\). ✓<br>
                        If \\(A[n] = 1\\): parity flips → return \\(\\text{not}\\ p\\). ✓<br><br>
                        Thus the algorithm is correct for size \\(n\\). □
                    </div>
                    <div class="student-answer incorrect" style="margin-top:0.6rem;">
                        <span class="answer-icon">❌</span>
                        <div><div class="answer-label-sm">Your answer</div>No induction proof given.</div>
                    </div>
                </div>
            </div>

            <!-- 3c -->
            <div class="subproblem">
                <div class="sub-header">
                    <span class="sub-label">(c) Recurrence for runtime</span>
                    <span class="sub-points">5 pts</span>
                </div>
                <div class="sub-body">
                    <div class="informal">Each call does constant work + one recursive call on size \\(n-1\\).</div>
                    <div class="correct-answer">
                        <span class="check">✓</span>
                        <div class="content">
                            <div class="answer-label">Answer</div>
                            <p>\\(T(n) = T(n-1) + O(1),\\quad T(0) = O(1)\\)</p>
                        </div>
                    </div>
                    <div class="student-answer correct" style="margin-top:0.6rem;">
                        <span class="answer-icon">✅</span>
                        <div><div class="answer-label-sm">Your answer</div>\\(T(n) = T(n-1) + 1\\) — correct.</div>
                    </div>
                </div>
            </div>

            <!-- 3d -->
            <div class="subproblem">
                <div class="sub-header">
                    <span class="sub-label">(d) Solve the recurrence</span>
                    <span class="sub-points">5 pts</span>
                </div>
                <div class="sub-body">
                    <div class="informal">Unfolding: \\(T(n) = T(0) + n \\cdot O(1) = O(n)\\).</div>
                    <div class="correct-answer">
                        <span class="check">✓</span>
                        <div class="content">
                            <div class="answer-label">Answer</div>
                            <p>\\(T(n) = O(n)\\)</p>
                        </div>
                    </div>
                    <div class="student-answer correct" style="margin-top:0.6rem;">
                        <span class="answer-icon">✅</span>
                        <div><div class="answer-label-sm">Your answer</div>\\(T(n) = O(n)\\) — correct.</div>
                    </div>
                </div>
            </div>

        </div>
    </div>

    <!-- ══════════════════ SUMMARY ══════════════════ -->
    <div class="summary-section" id="summary">
        <div class="summary-header">
            <h2>Final Summary</h2>
        </div>
        <table>
            <thead>
                <tr>
                    <th>Part</th>
                    <th>Correct Answer</th>
                    <th>Result</th>
                </tr>
            </thead>
            <tbody>
                <tr><td>1(a)</td><td>\\(\\frac{n!}{(n-k)!}\\)</td><td><span class="result-fail">❌</span></td></tr>
                <tr><td>1(b)</td><td>\\(n^k\\)</td><td><span class="result-fail">❌</span></td></tr>
                <tr><td>1(c)</td><td>\\(\\binom{n}{k}\\)</td><td><span class="result-pass">✅</span></td></tr>
                <tr><td>1(d)</td><td>\\(\\binom{n}{n/2} = o\\!\\left(\\frac{n!}{(n/2)!}\\right) = o\\!\\left(n^{n/2}\\right)\\)</td><td><span class="result-fail">❌</span></td></tr>
                <tr><td>2.1</td><td>\\(n\\)</td><td><span class="result-pass">✅</span></td></tr>
                <tr><td>2.2</td><td>\\(n=1:\\ 6^1-1=5\\)</td><td><span class="result-pass">✅</span></td></tr>
                <tr><td>2.3</td><td>Assume \\(6^k-1=5m\\)</td><td><span class="result-partial">⚠️ Partial</span></td></tr>
                <tr><td>2.4</td><td>\\(6^{k+1}-1 = 5(6m+1)\\)</td><td><span class="result-fail">❌</span></td></tr>
                <tr><td>2.5</td><td>Weak induction</td><td><span class="result-pass">✅</span></td></tr>
                <tr><td>3(a)</td><td>Linear recursion pseudocode</td><td><span class="result-fail">❌</span></td></tr>
                <tr><td>3(b)</td><td>Induction proof</td><td><span class="result-fail">❌</span></td></tr>
                <tr><td>3(c)</td><td>\\(T(n) = T(n-1) + 1\\)</td><td><span class="result-pass">✅</span></td></tr>
                <tr><td>3(d)</td><td>\\(T(n) = O(n)\\)</td><td><span class="result-pass">✅</span></td></tr>
                <tr class="total-row"><td colspan="2">Total as marked</td><td>22 / 100</td></tr>
            </tbody>
        </table>
    </div>

    <footer>
        Practice pseudocode · master induction proofs · these are key to algorithm exams 🚀
    </footer>

</div>
</body>
</html>`;export{n as default};
