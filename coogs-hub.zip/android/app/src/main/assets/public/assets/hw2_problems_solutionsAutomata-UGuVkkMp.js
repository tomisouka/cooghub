const n=`<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>HW2 — COSC 3340 Automata</title>
<link href="https://fonts.googleapis.com/css2?family=Fira+Code:wght@400;500;600&family=DM+Sans:ital,wght@0,300;0,400;0,600;0,700;1,400&display=swap" rel="stylesheet">
<style>
  :root {
    --bg: #0f0f14;
    --surface: #16161e;
    --border: #252535;
    --accent: #bb9af7;
    --accent2: #7aa2f7;
    --green: #9ece6a;
    --amber: #e0af68;
    --red: #f7768e;
    --cyan: #7dcfff;
    --text: #cdd6f4;
    --muted: #565f89;
    --card: #1a1b26;
  }

  * { box-sizing: border-box; margin: 0; padding: 0; }

  body {
    background: var(--bg);
    color: var(--text);
    font-family: 'DM Sans', sans-serif;
    background-image: 
      linear-gradient(135deg, rgba(122,162,247,0.03) 0%, transparent 60%),
      radial-gradient(circle at 90% 5%, rgba(187,154,247,0.04) 0%, transparent 40%);
  }

  header {
    background: var(--card);
    border-bottom: 1px solid var(--border);
    padding: 1.5rem 3rem;
    display: flex;
    align-items: center;
    justify-content: space-between;
    position: sticky;
    top: 0;
    z-index: 100;
    backdrop-filter: blur(8px);
  }

  .header-left { display: flex; align-items: center; gap: 1rem; }

  .hw-pill {
    background: linear-gradient(135deg, rgba(187,154,247,0.2), rgba(122,162,247,0.2));
    border: 1px solid rgba(187,154,247,0.4);
    border-radius: 999px;
    padding: 0.3rem 1rem;
    font-size: 0.78rem;
    font-weight: 600;
    color: var(--accent);
    letter-spacing: 0.05em;
  }

  h1 { font-size: 1.25rem; font-weight: 700; color: var(--text); }

  .due-tag {
    font-family: 'Fira Code', monospace;
    font-size: 0.7rem;
    color: var(--amber);
    background: rgba(224,175,104,0.1);
    padding: 0.3rem 0.8rem;
    border-radius: 3px;
    border: 1px solid rgba(224,175,104,0.3);
  }

  .container { max-width: 920px; margin: 0 auto; padding: 2.5rem 2rem; }

  .section-title {
    font-family: 'Fira Code', monospace;
    font-size: 0.65rem;
    letter-spacing: 0.15em;
    text-transform: uppercase;
    color: var(--muted);
    margin-bottom: 1.2rem;
    margin-top: 2.5rem;
    display: flex;
    align-items: center;
    gap: 0.8rem;
  }
  .section-title::after { content: ''; flex: 1; height: 1px; background: var(--border); }

  .card {
    background: var(--card);
    border: 1px solid var(--border);
    border-radius: 8px;
    margin-bottom: 1.5rem;
    overflow: hidden;
    transition: border-color 0.2s, box-shadow 0.2s;
  }
  .card:hover { border-color: rgba(187,154,247,0.25); box-shadow: 0 0 20px rgba(187,154,247,0.05); }

  .card-head {
    padding: 1rem 1.5rem;
    display: flex;
    align-items: center;
    gap: 0.8rem;
    cursor: pointer;
    background: rgba(26,27,38,0.6);
  }

  .q-tag {
    font-family: 'Fira Code', monospace;
    font-size: 0.72rem;
    font-weight: 600;
    padding: 0.2rem 0.6rem;
    border-radius: 3px;
    min-width: 2.8rem;
    text-align: center;
    flex-shrink: 0;
  }
  .tag-blue { background: rgba(122,162,247,0.15); color: var(--accent2); border: 1px solid rgba(122,162,247,0.3); }
  .tag-purple { background: rgba(187,154,247,0.15); color: var(--accent); border: 1px solid rgba(187,154,247,0.3); }
  .tag-green { background: rgba(158,206,106,0.15); color: var(--green); border: 1px solid rgba(158,206,106,0.3); }

  .card-title { font-weight: 600; font-size: 0.95rem; flex: 1; }
  .pts { font-family: 'Fira Code', monospace; font-size: 0.7rem; color: var(--muted); }
  .chevron-icon { color: var(--muted); font-size: 0.7rem; transition: transform 0.3s; }
  .card.open .chevron-icon { transform: rotate(180deg); }

  .card-body { padding: 1.5rem; border-top: 1px solid var(--border); display: none; }
  .card.open .card-body { display: block; }

  .problem-stmt {
    color: #9399b2;
    font-size: 0.9rem;
    line-height: 1.75;
    padding: 1rem;
    background: rgba(0,0,0,0.2);
    border-left: 2px solid var(--muted);
    border-radius: 0 4px 4px 0;
    margin-bottom: 1.5rem;
  }

  .sol-label {
    font-family: 'Fira Code', monospace;
    font-size: 0.62rem;
    letter-spacing: 0.12em;
    text-transform: uppercase;
    color: var(--green);
    margin-bottom: 0.6rem;
    margin-top: 1.2rem;
  }
  .sol-label:first-child { margin-top: 0; }

  .sol-text { font-size: 0.92rem; line-height: 1.8; }
  .sol-text p { margin-bottom: 0.75rem; }
  .sol-text strong { color: var(--cyan); }
  .sol-text em { color: var(--amber); }

  code, .mono {
    font-family: 'Fira Code', monospace;
    font-size: 0.82rem;
    background: rgba(0,0,0,0.3);
    padding: 0.15rem 0.4rem;
    border-radius: 3px;
    color: var(--accent);
  }

  .code-block {
    font-family: 'Fira Code', monospace;
    background: #0d0e14;
    border: 1px solid var(--border);
    border-radius: 6px;
    padding: 1rem 1.25rem;
    margin: 0.8rem 0;
    font-size: 0.82rem;
    line-height: 1.65;
    color: #9399b2;
    overflow-x: auto;
  }
  .code-block .kw { color: var(--accent); }
  .code-block .val { color: var(--green); }
  .code-block .cm { color: var(--muted); font-style: italic; }

  table { width: 100%; border-collapse: collapse; margin: 0.8rem 0; font-size: 0.85rem; }
  th {
    font-family: 'Fira Code', monospace;
    font-size: 0.72rem;
    letter-spacing: 0.05em;
    padding: 0.6rem 1rem;
    background: rgba(187,154,247,0.06);
    color: var(--accent);
    border-bottom: 1px solid var(--border);
    text-align: left;
  }
  td { padding: 0.55rem 1rem; border-bottom: 1px solid rgba(37,37,53,0.7); font-family: 'Fira Code', monospace; font-size: 0.8rem; }
  tr:last-child td { border-bottom: none; }
  tr:hover td { background: rgba(255,255,255,0.015); }
  .s-acc { color: var(--green); font-weight: 500; }
  .s-start { color: var(--amber); }
  .s-dead { color: var(--red); }

  .insight {
    background: linear-gradient(135deg, rgba(187,154,247,0.06), rgba(122,162,247,0.04));
    border: 1px solid rgba(187,154,247,0.2);
    border-radius: 5px;
    padding: 1rem 1.2rem;
    margin: 0.8rem 0;
  }
  .insight-lbl {
    font-family: 'Fira Code', monospace;
    font-size: 0.6rem;
    letter-spacing: 0.12em;
    text-transform: uppercase;
    color: var(--accent);
    margin-bottom: 0.4rem;
  }
  .insight p { font-size: 0.88rem; color: var(--text); line-height: 1.65; }

  .dfa-box {
    background: #0a0b10;
    border: 1px solid #252535;
    border-radius: 6px;
    padding: 1.5rem;
    margin: 1rem 0;
    font-family: 'Fira Code', monospace;
    font-size: 0.8rem;
    color: #565f89;
    position: relative;
  }
  .dfa-box::before {
    content: 'JFLAP — DFA';
    position: absolute;
    top: 0.5rem; right: 0.8rem;
    font-size: 0.58rem; letter-spacing: 0.1em;
    color: #2a2b3d; text-transform: uppercase;
  }

  .regex-result {
    display: inline-block;
    font-family: 'Fira Code', monospace;
    font-size: 1.05rem;
    color: var(--cyan);
    background: rgba(125,207,255,0.08);
    border: 1px solid rgba(125,207,255,0.25);
    border-radius: 4px;
    padding: 0.5rem 1.2rem;
    margin: 0.5rem 0;
  }

  .test-strings { display: flex; flex-wrap: wrap; gap: 0.5rem; margin: 0.5rem 0; }
  .test-in { background: rgba(158,206,106,0.1); color: var(--green); border: 1px solid rgba(158,206,106,0.3); border-radius: 3px; padding: 0.2rem 0.6rem; font-family: 'Fira Code', monospace; font-size: 0.78rem; }
  .test-out { background: rgba(247,118,142,0.1); color: var(--red); border: 1px solid rgba(247,118,142,0.3); border-radius: 3px; padding: 0.2rem 0.6rem; font-family: 'Fira Code', monospace; font-size: 0.78rem; }
  .test-label { font-size: 0.75rem; color: var(--muted); margin-top: 0.3rem; margin-bottom: 0.2rem; }

  .qed { text-align: right; font-family: 'Fira Code', monospace; color: var(--green); font-size: 0.9rem; margin-top: 0.5rem; }

  footer {
    text-align: center;
    padding: 2rem;
    font-family: 'Fira Code', monospace;
    font-size: 0.68rem;
    color: var(--muted);
    border-top: 1px solid var(--border);
    margin-top: 3rem;
  }
</style>
</head>
<body>

<header>
  <div class="header-left">
    <span class="hw-pill">HW 2</span>
    <h1>Homework 2 — DFAs, NFAs & Regular Expressions</h1>
  </div>
  <span class="due-tag">Due Feb 19, 2026</span>
</header>

<div class="container">

  <div class="section-title">Part 1 — JFLAP DFA Design</div>

  <!-- Q1a -->
  <div class="card open">
    <div class="card-head" onclick="toggle(this)">
      <span class="q-tag tag-blue">Q1a</span>
      <span class="card-title">DFA: strings not containing substring "010"</span>
      <span class="pts">8 pts</span>
      <span class="chevron-icon">▼</span>
    </div>
    <div class="card-body">
      <div class="problem-stmt">
        {w ∈ {0,1}* | w does not contain the substring 010}
      </div>
      <div class="sol-label">Solution — State Design</div>
      <div class="sol-text">
        <p>Track how much of the "010" pattern has been matched as a suffix. States represent the longest suffix of the input so far that is also a prefix of "010".</p>
      </div>
      <table>
        <tr><th>State</th><th>Meaning</th><th>On 0</th><th>On 1</th><th>Accept?</th></tr>
        <tr><td class="s-start">q_ε (start)</td><td>No match</td><td>q_0</td><td>q_ε</td><td class="s-acc">✓</td></tr>
        <tr><td>q_0</td><td>Matched "0"</td><td>q_0</td><td>q_01</td><td class="s-acc">✓</td></tr>
        <tr><td>q_01</td><td>Matched "01"</td><td class="s-dead">q_dead</td><td>q_ε</td><td class="s-acc">✓</td></tr>
        <tr><td class="s-dead">q_dead</td><td>Seen "010" — REJECT</td><td class="s-dead">q_dead</td><td class="s-dead">q_dead</td><td class="s-dead">✗</td></tr>
      </table>

      <div class="dfa-box">
        <svg viewBox="0 0 620 200" fill="none" xmlns="http://www.w3.org/2000/svg" style="width:100%;max-width:600px;display:block;margin:0 auto">
          <!-- q_ε -->
          <line x1="10" y1="100" x2="75" y2="100" stroke="#565f89" stroke-width="1.5" marker-end="url(#a0)"/>
          <circle cx="110" cy="100" r="30" stroke="#e0af68" stroke-width="1.5" fill="rgba(224,175,104,0.05)"/>
          <circle cx="110" cy="100" r="25" stroke="#e0af68" stroke-width="0.8" fill="none"/>
          <text x="110" y="104" text-anchor="middle" font-family="monospace" font-size="11" fill="#e0af68">q_ε</text>

          <!-- q_ε self-loop on 1 -->
          <path d="M95 72 Q80 45 110 38 Q140 45 125 72" stroke="#565f89" stroke-width="1.3" fill="none" marker-end="url(#a0)"/>
          <text x="110" y="33" text-anchor="middle" font-family="monospace" font-size="11" fill="#9399b2">1</text>

          <!-- q_ε → q_0 on 0 -->
          <line x1="140" y1="100" x2="210" y2="100" stroke="#7aa2f7" stroke-width="1.3" marker-end="url(#a1)"/>
          <text x="175" y="94" text-anchor="middle" font-family="monospace" font-size="11" fill="#7aa2f7">0</text>

          <!-- q_0 -->
          <circle cx="245" cy="100" r="30" stroke="#e0af68" stroke-width="1.5" fill="rgba(224,175,104,0.05)"/>
          <circle cx="245" cy="100" r="25" stroke="#e0af68" stroke-width="0.8" fill="none"/>
          <text x="245" y="104" text-anchor="middle" font-family="monospace" font-size="11" fill="#e0af68">q_0</text>

          <!-- q_0 self-loop on 0 -->
          <path d="M230 72 Q215 45 245 38 Q275 45 260 72" stroke="#565f89" stroke-width="1.3" fill="none" marker-end="url(#a0)"/>
          <text x="245" y="33" text-anchor="middle" font-family="monospace" font-size="11" fill="#9399b2">0</text>

          <!-- q_0 → q_01 on 1 -->
          <line x1="275" y1="100" x2="345" y2="100" stroke="#7aa2f7" stroke-width="1.3" marker-end="url(#a1)"/>
          <text x="310" y="94" text-anchor="middle" font-family="monospace" font-size="11" fill="#7aa2f7">1</text>

          <!-- q_01 -->
          <circle cx="380" cy="100" r="30" stroke="#9ece6a" stroke-width="1.5" fill="rgba(158,206,106,0.05)"/>
          <circle cx="380" cy="100" r="25" stroke="#9ece6a" stroke-width="0.8" fill="none"/>
          <text x="380" y="104" text-anchor="middle" font-family="monospace" font-size="11" fill="#9ece6a">q_01</text>

          <!-- q_01 → q_dead on 0 -->
          <line x1="410" y1="100" x2="480" y2="100" stroke="#f7768e" stroke-width="1.3" marker-end="url(#a2)"/>
          <text x="445" y="94" text-anchor="middle" font-family="monospace" font-size="11" fill="#f7768e">0</text>

          <!-- q_01 → q_ε on 1 -->
          <path d="M365 72 Q320 25 155 72" stroke="#565f89" stroke-width="1.3" fill="none" marker-end="url(#a0)"/>
          <text x="265" y="48" text-anchor="middle" font-family="monospace" font-size="11" fill="#9399b2">1</text>

          <!-- q_dead -->
          <circle cx="515" cy="100" r="30" stroke="#f7768e" stroke-width="1.5" fill="rgba(247,118,142,0.05)"/>
          <text x="515" y="104" text-anchor="middle" font-family="monospace" font-size="11" fill="#f7768e">DEAD</text>

          <!-- q_dead self-loop -->
          <path d="M500 72 Q485 45 515 38 Q545 45 530 72" stroke="#f7768e" stroke-width="1.3" fill="none" marker-end="url(#a2)"/>
          <text x="515" y="33" text-anchor="middle" font-family="monospace" font-size="11" fill="#f7768e">0,1</text>

          <defs>
            <marker id="a0" markerWidth="7" markerHeight="7" refX="6" refY="3" orient="auto"><path d="M0,0 L0,6 L7,3 z" fill="#565f89"/></marker>
            <marker id="a1" markerWidth="7" markerHeight="7" refX="6" refY="3" orient="auto"><path d="M0,0 L0,6 L7,3 z" fill="#7aa2f7"/></marker>
            <marker id="a2" markerWidth="7" markerHeight="7" refX="6" refY="3" orient="auto"><path d="M0,0 L0,6 L7,3 z" fill="#f7768e"/></marker>
          </defs>
        </svg>
      </div>

      <div class="test-label">✓ Strings IN language (accept):</div>
      <div class="test-strings">
        <span class="test-in">ε</span>
        <span class="test-in">0</span>
        <span class="test-in">1</span>
        <span class="test-in">01</span>
        <span class="test-in">001</span>
        <span class="test-in">110</span>
        <span class="test-in">1100</span>
      </div>
      <div class="test-label">✗ Strings NOT in language (reject):</div>
      <div class="test-strings">
        <span class="test-out">010</span>
        <span class="test-out">0101</span>
        <span class="test-out">1010</span>
        <span class="test-out">00100</span>
        <span class="test-out">11010</span>
      </div>
    </div>
  </div>

  <!-- Q1b -->
  <div class="card open">
    <div class="card-head" onclick="toggle(this)">
      <span class="q-tag tag-blue">Q1b</span>
      <span class="card-title">DFA: number of 0's + number of 1's is odd (= length is odd)</span>
      <span class="pts">8 pts</span>
      <span class="chevron-icon">▼</span>
    </div>
    <div class="card-body">
      <div class="problem-stmt">
        {w ∈ {0,1}* | the number of 0's in w + the number of 1's in w is odd}
      </div>
      <div class="sol-label">Key Insight</div>
      <div class="sol-text">
        <p>The number of 0's + number of 1's = <strong>|w|</strong> (the length of w). So this language is simply all strings of <em>odd length</em>.</p>
      </div>
      <table>
        <tr><th>State</th><th>Meaning</th><th>On 0</th><th>On 1</th><th>Accept?</th></tr>
        <tr><td class="s-start">q_even (start)</td><td>|w| even so far</td><td>q_odd</td><td>q_odd</td><td class="s-dead">✗</td></tr>
        <tr><td class="s-acc">q_odd</td><td>|w| odd so far</td><td>q_even</td><td>q_even</td><td class="s-acc">✓</td></tr>
      </table>
      <div class="test-label">✓ Strings IN language:</div>
      <div class="test-strings">
        <span class="test-in">0</span><span class="test-in">1</span><span class="test-in">010</span><span class="test-in">101</span><span class="test-in">000</span>
      </div>
      <div class="test-label">✗ Strings NOT in language:</div>
      <div class="test-strings">
        <span class="test-out">ε</span><span class="test-out">00</span><span class="test-out">11</span><span class="test-out">0101</span>
      </div>
    </div>
  </div>

  <div class="section-title">Part 2 — JFLAP NFA Design</div>

  <!-- Q2b -->
  <div class="card open">
    <div class="card-head" onclick="toggle(this)">
      <span class="q-tag tag-purple">Q2b</span>
      <span class="card-title">NFA: at least one 'a' and no more than two 'b's</span>
      <span class="pts">8 pts</span>
      <span class="chevron-icon">▼</span>
    </div>
    <div class="card-body">
      <div class="problem-stmt">
        {w ∈ {a,b}* | w has at least one a and no more than two b's}
      </div>
      <div class="sol-label">NFA Design</div>
      <div class="sol-text">
        <p>States encode (b_count ∈ {0, 1, 2, 3+}) × (has_a ∈ {false, true}). Accept when has_a = true and b_count ≤ 2.</p>
      </div>
      <table>
        <tr><th>State</th><th>Meaning</th><th>On a</th><th>On b</th><th>Accept?</th></tr>
        <tr><td class="s-start">q00 (start)</td><td>0 b's, no a seen</td><td>q01</td><td>q10</td><td class="s-dead">✗</td></tr>
        <tr><td>q10</td><td>1 b, no a</td><td>q11</td><td>q20</td><td class="s-dead">✗</td></tr>
        <tr><td>q20</td><td>2 b's, no a</td><td>q21</td><td>q_dead</td><td class="s-dead">✗</td></tr>
        <tr><td class="s-acc">q01</td><td>0 b's, has a</td><td>q01</td><td>q11</td><td class="s-acc">✓</td></tr>
        <tr><td class="s-acc">q11</td><td>1 b, has a</td><td>q11</td><td>q21</td><td class="s-acc">✓</td></tr>
        <tr><td class="s-acc">q21</td><td>2 b's, has a</td><td>q21</td><td>q_dead</td><td class="s-acc">✓</td></tr>
        <tr><td class="s-dead">q_dead</td><td>3+ b's — reject</td><td class="s-dead">q_dead</td><td class="s-dead">q_dead</td><td class="s-dead">✗</td></tr>
      </table>

      <div class="test-label">✓ Strings IN language:</div>
      <div class="test-strings">
        <span class="test-in">a</span><span class="test-in">ab</span><span class="test-in">ba</span><span class="test-in">aba</span><span class="test-in">bba</span><span class="test-in">abb</span>
      </div>
      <div class="test-label">✗ Strings NOT in language:</div>
      <div class="test-strings">
        <span class="test-out">ε</span><span class="test-out">b</span><span class="test-out">bbb</span><span class="test-out">bbba</span><span class="test-out">bb</span>
      </div>
    </div>
  </div>

  <div class="section-title">Part 3 — Regular Expressions</div>

  <!-- Q3a -->
  <div class="card open">
    <div class="card-head" onclick="toggle(this)">
      <span class="q-tag tag-green">Q3a</span>
      <span class="card-title">Regex: no substring "00" over {0,1,2}</span>
      <span class="pts">8 pts</span>
      <span class="chevron-icon">▼</span>
    </div>
    <div class="card-body">
      <div class="problem-stmt">
        {w ∈ {0,1,2}* | w does not contain the substring 00}
      </div>
      <div class="sol-label">Solution</div>
      <div class="sol-text">
        <p>Between any two 0's there must be at least one non-zero character (1 or 2). A 0 can only appear if it is immediately followed by a 1 or 2 (or end of string).</p>
        <p>Structure: start with zero or more non-zero chars, then repeatedly: a 0 followed by one or more non-zeros, ending with an optional 0.</p>
      </div>
      <div class="regex-result">(1|2|0(1|2))*(ε|0)</div>
      <div class="insight">
        <div class="insight-lbl">Justification</div>
        <p>Each "block" is either a non-zero character (1|2) or a 0 that is immediately followed by a non-zero (0(1|2)). After all complete blocks, we can optionally end with a single 0. This ensures no two 0's are adjacent.</p>
      </div>
    </div>
  </div>

  <!-- Q3b -->
  <div class="card open">
    <div class="card-head" onclick="toggle(this)">
      <span class="q-tag tag-green">Q3b</span>
      <span class="card-title">Regex: contains "01" and is of even length</span>
      <span class="pts">12 pts</span>
      <span class="chevron-icon">▼</span>
    </div>
    <div class="card-body">
      <div class="problem-stmt">
        {w ∈ {0,1,2}* | w contains the substring 01 and is of even length}
      </div>
      <div class="sol-label">Solution</div>
      <div class="sol-text">
        <p>Let Σ = (0|1|2). A string is even-length if it can be split into pairs. The substring "01" starts at some position; that position is either at an even index (0-based) or an odd index.</p>

        <div class="code-block">
Let P = (ΣΣ)* = even-length strings
Let Σ = (0|1|2)

Case 1: "01" starts at even position:
  P · 01 · P

Case 2: "01" starts at odd position:
  P · Σ · 01 · Σ · P
        </div>

        <div class="regex-result">((0|1|2)(0|1|2))*·01·((0|1|2)(0|1|2))* | ((0|1|2)(0|1|2))*(0|1|2)·01·(0|1|2)((0|1|2)(0|1|2))*</div>
      </div>
    </div>
  </div>

  <!-- Q3c -->
  <div class="card open">
    <div class="card-head" onclick="toggle(this)">
      <span class="q-tag tag-green">Q3c</span>
      <span class="card-title">Regex: no substring "11" OR odd length</span>
      <span class="pts">12 pts</span>
      <span class="chevron-icon">▼</span>
    </div>
    <div class="card-body">
      <div class="problem-stmt">
        {w ∈ {0,1,2}* | w does not contain the substring 11 or is of odd length}
      </div>
      <div class="sol-label">Solution (Union of two languages)</div>
      <div class="sol-text">
        <p>L = L₁ ∪ L₂ where:</p>
        <p><strong>L₁</strong> = strings with no "11": Between any two 1's there must be a non-1. Regex: <code>(0|2|1(0|2))*(1|ε)</code></p>
        <p><strong>L₂</strong> = strings of odd length: <code>(0|1|2)((0|1|2)(0|1|2))*</code></p>
      </div>
      <div class="regex-result">(0|2|1(0|2))*(1|ε) | (0|1|2)((0|1|2)(0|1|2))*</div>
    </div>
  </div>

  <div class="section-title">Part 4 — DFA Conversion (Q2b NFA → DFA)</div>

  <!-- Q4 -->
  <div class="card open">
    <div class="card-head" onclick="toggle(this)">
      <span class="q-tag tag-blue">Q4</span>
      <span class="card-title">Convert NFA (Q2b) to DFA — Subset Construction</span>
      <span class="pts">8 pts</span>
      <span class="chevron-icon">▼</span>
    </div>
    <div class="card-body">
      <div class="sol-label">Subset Construction</div>
      <div class="sol-text">
        <p>Starting from the NFA for {at least one a, no more than two b's}. Track subsets of NFA states reachable.</p>
      </div>
      <table>
        <tr><th>DFA State (subset)</th><th>On a</th><th>On b</th><th>Accept?</th></tr>
        <tr><td class="s-start">{q00}</td><td>{q00,q01}</td><td>{q10}</td><td class="s-dead">✗</td></tr>
        <tr><td>{q00,q01}</td><td>{q00,q01}</td><td>{q10,q11}</td><td class="s-acc">✓ (q01)</td></tr>
        <tr><td>{q10}</td><td>{q10,q11}</td><td>{q20}</td><td class="s-dead">✗</td></tr>
        <tr><td class="s-acc">{q10,q11}</td><td>{q10,q11}</td><td>{q20,q21}</td><td class="s-acc">✓ (q11)</td></tr>
        <tr><td>{q20}</td><td>{q20,q21}</td><td>{q_dead}</td><td class="s-dead">✗</td></tr>
        <tr><td class="s-acc">{q20,q21}</td><td>{q20,q21}</td><td>{q_dead}</td><td class="s-acc">✓ (q21)</td></tr>
        <tr><td class="s-dead">{q_dead}</td><td class="s-dead">{q_dead}</td><td class="s-dead">{q_dead}</td><td class="s-dead">✗</td></tr>
      </table>
      <div class="insight">
        <div class="insight-lbl">Accept States in DFA</div>
        <p>Any DFA state containing at least one NFA accept state (q01, q11, q21) is an accept state in the DFA.</p>
      </div>
    </div>
  </div>

  <div class="section-title">Part 5 — Regex → NFA (Thompson's Construction)</div>

  <!-- Q5 -->
  <div class="card open">
    <div class="card-head" onclick="toggle(this)">
      <span class="q-tag tag-purple">Q5</span>
      <span class="card-title">Convert regex (1|2|0(1|2))*(ε|0) to NFA</span>
      <span class="pts">8 pts</span>
      <span class="chevron-icon">▼</span>
    </div>
    <div class="card-body">
      <div class="sol-label">Thompson's Construction Steps</div>
      <div class="sol-text">
        <p><strong>Step 1:</strong> NFA for <code>1</code>: s₁ →1→ a₁</p>
        <p><strong>Step 2:</strong> NFA for <code>2</code>: s₂ →2→ a₂</p>
        <p><strong>Step 3:</strong> NFA for <code>(1|2)</code> — union: new start s, ε to s₁ and s₂; new accept a, ε from a₁ and a₂</p>
        <p><strong>Step 4:</strong> NFA for <code>0</code>: s₃ →0→ a₃</p>
        <p><strong>Step 5:</strong> NFA for <code>0(1|2)</code> — concatenate NFA(0) with NFA(1|2)</p>
        <p><strong>Step 6:</strong> NFA for <code>(1|2|0(1|2))</code> — union of NFA(1|2) and NFA(0(1|2))</p>
        <p><strong>Step 7:</strong> Apply Kleene star: add ε back-loop from accept to start; make start also accept (for zero repetitions)</p>
        <p><strong>Step 8:</strong> NFA for <code>(ε|0)</code> — union of empty string (ε-path) and single 0</p>
        <p><strong>Step 9:</strong> Concatenate step 7 and step 8 results</p>
      </div>
      <div class="code-block">
Total states: ~14 states using standard Thompson's construction
Start: s_new
Accept: a_final (after optional 0)

Key structure:
  s_new --ε--> [star block start]
  [star block] handles (1|2|0(1|2)) with ε back-loop
  [star block accept] --ε--> s_opt0
  s_opt0 --ε--> a_final       (ε path for no trailing 0)
  s_opt0 --0--> a_final       (0 path for trailing 0)
      </div>
    </div>
  </div>

  <div class="section-title">Part 6 — NFA → Regex (GNFA Elimination)</div>

  <!-- Q6 -->
  <div class="card open">
    <div class="card-head" onclick="toggle(this)">
      <span class="q-tag tag-purple">Q6</span>
      <span class="card-title">Convert NFA from Q5 back to regex using GNFA elimination</span>
      <span class="pts">12 pts</span>
      <span class="chevron-icon">▼</span>
    </div>
    <div class="card-body">
      <div class="sol-label">GNFA Method — State Elimination</div>
      <div class="sol-text">
        <p><strong>Setup:</strong> Add new start state q_s with ε to original start, and new accept state q_f with ε from original accept states.</p>

        <p><strong>Elimination rule:</strong> When removing state q_rip with incoming states Qᵢ and outgoing states Qⱼ, for each pair (qᵢ, qⱼ):</p>
        <div class="code-block">
R(qᵢ → qⱼ) := R(qᵢ → qⱼ) ∪ R(qᵢ → q_rip) · R(q_rip → q_rip)* · R(q_rip → qⱼ)
        </div>

        <p><strong>Eliminate states one by one</strong> (in any order). After all internal states are removed, the single edge from q_s to q_f carries the final regular expression.</p>

        <p><strong>Result:</strong> Since the NFA was constructed from <code>(1|2|0(1|2))*(ε|0)</code>, the GNFA elimination (when fully carried out) recovers:</p>
      </div>
      <div class="regex-result">(1|2|0(1|2))*(ε|0)</div>
      <div class="insight">
        <div class="insight-lbl">Full Step-by-Step Trace</div>
        <p>1. Add q_s →ε→ s_new, q_f ←ε← a_final<br>
        2. Eliminate a_final: merge ε-path into q_s → q_f edge<br>
        3. Eliminate s_opt0: produces (ε|0) on the surviving edge<br>
        4. Eliminate star-block states one by one; each elimination re-derives the union structure<br>
        5. Final edge label: (1|2|0(1|2))*(ε|0) □</p>
      </div>
    </div>
  </div>

</div>

<footer>COSC 3340 — Spring 2026 · Homework 2 · Dr. Rakesh Verma, Vu Minh Hoang Dang, Bryan Tuck</footer>

<script>
function toggle(head) {
  const card = head.closest('.card');
  card.classList.toggle('open');
}
<\/script>

</body>
</html>
`;export{n as default};
