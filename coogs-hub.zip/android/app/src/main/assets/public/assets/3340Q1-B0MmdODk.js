const n=`<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>COSC 3340 · Quiz 1 Solutions</title>
    <link href="https://fonts.googleapis.com/css2?family=DM+Serif+Display:ital@0;1&family=DM+Mono:wght@400;500&family=Outfit:wght@300;400;500;600&display=swap" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/mathjax@3/es5/tex-chtml.js"><\/script>
    <style>
        :root {
            --bg: #0e0f14;
            --surface: #14161e;
            --surface2: #1c1f2b;
            --border: #252836;
            --accent: #c8a96e;
            --accent2: #7eb8c9;
            --green: #5dbd8a;
            --red: #e07070;
            --yellow: #d4a843;
            --text: #e8e6df;
            --muted: #7a7d8c;
        }

        * { box-sizing: border-box; margin: 0; padding: 0; }

        body {
            background: var(--bg);
            font-family: 'Outfit', sans-serif;
            color: var(--text);
            line-height: 1.7;
            padding: 2rem 1rem 6rem;
            min-height: 100vh;
        }

        body::before {
            content: '';
            position: fixed;
            inset: 0;
            background-image:
                linear-gradient(rgba(200,169,110,0.03) 1px, transparent 1px),
                linear-gradient(90deg, rgba(200,169,110,0.03) 1px, transparent 1px);
            background-size: 40px 40px;
            pointer-events: none;
            z-index: 0;
        }

        .page { max-width: 860px; margin: 0 auto; position: relative; z-index: 1; }

        header {
            padding: 3rem 0 2.5rem;
            border-bottom: 1px solid var(--border);
            margin-bottom: 3rem;
            animation: fadeDown 0.6s ease both;
        }

        .course-tag {
            font-family: 'DM Mono', monospace;
            font-size: 0.75rem;
            color: var(--accent);
            letter-spacing: 0.2em;
            text-transform: uppercase;
            margin-bottom: 0.8rem;
        }

        h1 {
            font-family: 'DM Serif Display', serif;
            font-size: clamp(2rem, 5vw, 3.2rem);
            font-weight: 400;
            line-height: 1.15;
            margin-bottom: 1rem;
        }

        h1 em { font-style: italic; color: var(--accent); }

        .header-meta { font-size: 0.95rem; color: var(--muted); max-width: 580px; }

        .diff-easy {
            font-family: 'DM Mono', monospace; font-size: 0.65rem;
            color: var(--green); background: rgba(93,189,138,0.08);
            border: 1px solid rgba(93,189,138,0.2); border-radius: 100px; padding: 0.12rem 0.6rem;
        }
        .diff-medium {
            font-family: 'DM Mono', monospace; font-size: 0.65rem;
            color: var(--yellow); background: rgba(212,168,67,0.08);
            border: 1px solid rgba(212,168,67,0.2); border-radius: 100px; padding: 0.12rem 0.6rem;
        }
        .diff-hard {
            font-family: 'DM Mono', monospace; font-size: 0.65rem;
            color: var(--red); background: rgba(224,112,112,0.08);
            border: 1px solid rgba(224,112,112,0.2); border-radius: 100px; padding: 0.12rem 0.6rem;
        }

        .nav-pills {
            display: flex; flex-wrap: wrap; gap: 0.5rem;
            margin-bottom: 3rem; animation: fadeDown 0.6s 0.1s ease both;
        }

        .nav-pill {
            font-family: 'DM Mono', monospace; font-size: 0.72rem;
            color: var(--muted); border: 1px solid var(--border);
            border-radius: 100px; padding: 0.3rem 0.9rem;
            text-decoration: none; transition: all 0.2s; letter-spacing: 0.05em;
        }

        .nav-pill:hover { color: var(--accent); border-color: var(--accent); background: rgba(200,169,110,0.06); }

        .q-card {
            background: var(--surface); border: 1px solid var(--border);
            border-radius: 20px; margin-bottom: 2rem; overflow: hidden;
            animation: fadeUp 0.5s ease both;
        }

        .q-card:nth-child(1){animation-delay:0.05s} .q-card:nth-child(2){animation-delay:0.10s}
        .q-card:nth-child(3){animation-delay:0.13s} .q-card:nth-child(4){animation-delay:0.16s}
        .q-card:nth-child(5){animation-delay:0.19s} .q-card:nth-child(6){animation-delay:0.22s}
        .q-card:nth-child(7){animation-delay:0.25s} .q-card:nth-child(8){animation-delay:0.28s}

        .q-header {
            display: flex; align-items: center; gap: 1rem; flex-wrap: wrap;
            padding: 1.4rem 1.8rem; border-bottom: 1px solid var(--border); background: var(--surface2);
        }

        .q-num {
            font-family: 'DM Mono', monospace; font-size: 0.7rem; color: var(--accent);
            background: rgba(200,169,110,0.1); border: 1px solid rgba(200,169,110,0.25);
            border-radius: 8px; padding: 0.25rem 0.6rem; letter-spacing: 0.1em; flex-shrink: 0;
        }

        .q-title { font-family: 'DM Serif Display', serif; font-size: 1.2rem; font-weight: 400; flex: 1; }

        .q-meta { display: flex; align-items: center; gap: 0.5rem; flex-shrink: 0; }

        .q-points { font-family: 'DM Mono', monospace; font-size: 0.68rem; color: var(--muted); }

        .concept-row {
            padding: 0.9rem 1.8rem; border-bottom: 1px solid var(--border);
            display: flex; align-items: center; gap: 0.6rem; flex-wrap: wrap;
        }

        .concept-label {
            font-family: 'DM Mono', monospace; font-size: 0.65rem;
            color: var(--muted); text-transform: uppercase; letter-spacing: 0.15em;
        }

        .concept-tag {
            font-family: 'DM Mono', monospace; font-size: 0.72rem;
            color: var(--accent2); background: rgba(126,184,201,0.08);
            border: 1px solid rgba(126,184,201,0.2); border-radius: 100px; padding: 0.15rem 0.7rem;
        }

        .concept-ref { font-family: 'DM Mono', monospace; font-size: 0.68rem; color: var(--muted); font-style: italic; }

        .q-body { padding: 1.6rem 1.8rem; display: flex; flex-direction: column; gap: 1rem; }

        .section-label {
            font-family: 'DM Mono', monospace; font-size: 0.65rem;
            text-transform: uppercase; letter-spacing: 0.15em; color: var(--muted); margin-bottom: 0.35rem;
        }

        .student-block {
            background: var(--surface2); border-radius: 10px; padding: 0.8rem 1rem;
            border: 1px solid var(--border); font-size: 0.88rem; color: #b0acaa; font-style: italic;
        }

        .formal {
            background: rgba(200,169,110,0.04); border-left: 3px solid var(--accent);
            border-radius: 0 10px 10px 0; padding: 0.9rem 1.1rem;
            font-size: 0.9rem; color: #c8c4bb;
        }

        .formal strong { color: var(--text); }

        .informal {
            background: var(--surface2); border-radius: 10px; padding: 0.9rem 1.1rem;
            border: 1px solid var(--border); font-size: 0.9rem; color: #b8b4ac;
        }

        .answer-box {
            background: rgba(93,189,138,0.07); border: 1px solid rgba(93,189,138,0.25);
            border-radius: 12px; padding: 1rem 1.2rem;
            display: flex; gap: 0.8rem; align-items: flex-start;
        }

        .answer-box .check { flex-shrink: 0; font-size: 1rem; margin-top: 0.1rem; }
        .answer-box .content { flex: 1; }

        .answer-box .answer-label {
            font-family: 'DM Mono', monospace; font-size: 0.63rem;
            text-transform: uppercase; letter-spacing: 0.15em; color: var(--green); margin-bottom: 0.3rem;
        }

        .answer-box p { font-size: 0.92rem; color: #d4f0e3; }

        .answer-box blockquote {
            font-size: 0.9rem; color: #d4f0e3;
            border-left: 2px solid rgba(93,189,138,0.4); padding-left: 0.8rem; margin-top: 0.4rem;
        }

        .steps {
            background: var(--surface2); border-radius: 10px;
            padding: 0.9rem 1.1rem; border: 1px solid var(--border);
        }

        .steps ol { padding-left: 1.2rem; margin-top: 0.4rem; display: flex; flex-direction: column; gap: 0.3rem; }
        .steps ol li { font-size: 0.88rem; color: #b8b4ac; }
        .steps ol li strong { color: var(--text); }

        .diag-table { width: 100%; border-collapse: collapse; font-family: 'DM Mono', monospace; font-size: 0.82rem; margin: 0.4rem 0; }
        .diag-table th { padding: 0.5rem 0.8rem; background: var(--surface2); border: 1px solid var(--border); color: var(--muted); font-size: 0.63rem; text-transform: uppercase; letter-spacing: 0.1em; text-align: left; }
        .diag-table td { padding: 0.5rem 0.8rem; border: 1px solid var(--border); color: #b8b4ac; }
        .diag-table .hi { color: var(--accent); }
        .diag-table .flip { color: var(--accent2); }

        .divider { border: none; border-top: 1px solid var(--border); margin: 0.3rem 0; }

        footer {
            margin-top: 4rem; padding-top: 2rem; border-top: 1px solid var(--border);
            text-align: center; font-family: 'DM Mono', monospace;
            font-size: 0.75rem; color: var(--muted); letter-spacing: 0.05em;
            animation: fadeUp 0.5s 0.4s ease both;
        }

        @keyframes fadeDown { from { opacity: 0; transform: translateY(-16px); } to { opacity: 1; transform: translateY(0); } }
        @keyframes fadeUp   { from { opacity: 0; transform: translateY(20px);  } to { opacity: 1; transform: translateY(0); } }

        ::-webkit-scrollbar { width: 6px; }
        ::-webkit-scrollbar-track { background: var(--bg); }
        ::-webkit-scrollbar-thumb { background: var(--border); border-radius: 3px; }

        @media (max-width: 600px) {
            .q-body { padding: 1.1rem 1rem; }
            .concept-row { padding: 0.8rem 1rem; }
        }
    </style>
</head>
<body>
<div class="page">

    <header>
        <div class="course-tag">COSC 3340 · Automata & Computability · Quiz 1</div>
        <h1>Complete<br><em>solutions</em></h1>
        <p class="header-meta">Formal definitions, informal explanations, and highlighted answers. Student responses noted with corrections.</p>
    </header>

    <nav class="nav-pills">
        <a class="nav-pill" href="#q1">Q1 · Diagonalization</a>
        <a class="nav-pill" href="#q2">Q2 · Induction</a>
        <a class="nav-pill" href="#q3">Q3 · Pigeonhole</a>
        <a class="nav-pill" href="#q4">Q4 · Cardinality</a>
        <a class="nav-pill" href="#q5">Q5 · Relations</a>
        <a class="nav-pill" href="#q6">Q6 · Equivalence</a>
        <a class="nav-pill" href="#q7">Q7 · Probability</a>
        <a class="nav-pill" href="#q8">Q8 · Course Content</a>
    </nav>

    <!-- Q1 -->
    <div class="q-card" id="q1">
        <div class="q-header">
            <span class="q-num">Q 01</span>
            <span class="q-title">Diagonalization</span>
            <div class="q-meta"><span class="diff-hard">Medium-Hard</span><span class="q-points">12 pts</span></div>
        </div>
        <div class="concept-row">
            <span class="concept-label">Concept</span>
            <span class="concept-tag">Diagonalization</span>
            <span class="concept-ref">— Sipser §4.2</span>
        </div>
        <div class="q-body">
            <div>
                <div class="section-label">Part (a) · Your Answer</div>
                <div class="student-block">"set up a natrice [matrix], pick a point, and reduce"</div>
            </div>
            <div>
                <div class="section-label">Formal Definition</div>
                <div class="formal"><strong>Diagonalization Principle:</strong> Given a list \\(s_1, s_2, s_3, \\dots\\) of infinite binary strings, construct \\(t\\) such that \\(t_i \\neq (s_i)_i\\) for every \\(i\\). Then \\(t\\) is guaranteed <em>not</em> to appear anywhere in the list.</div>
            </div>
            <div>
                <div class="section-label">Informal</div>
                <div class="informal">Look at diagonal entries (1st bit of \\(s_1\\), 2nd bit of \\(s_2\\), …). Flip each one. The result differs from every listed string at its diagonal position — so it can't be in the list.</div>
            </div>
            <div class="answer-box">
                <span class="check">✓</span>
                <div class="content">
                    <div class="answer-label">Answer (a)</div>
                    <blockquote>The diagonalization principle constructs an element not in a given list by flipping diagonal entries — the new string differs from every listed string at at least one position.</blockquote>
                </div>
            </div>
            <hr class="divider">
            <div>
                <div class="section-label">Part (b) · Construction of \\(t\\)</div>
                <div class="formal"><strong>Cantor's Diagonal Argument:</strong> \\[t_i = \\text{NOT}\\big((s_i)_i\\big) \\quad \\text{for all } i \\in \\mathbb{N}\\]</div>
            </div>
            <table class="diag-table">
                <thead><tr><th>String</th><th>Position</th><th>Diagonal bit</th><th>\\(t_i\\) flipped</th></tr></thead>
                <tbody>
                    <tr><td>\\(s_1 = 010101\\ldots\\)</td><td>1st</td><td class="hi">0</td><td class="flip">1</td></tr>
                    <tr><td>\\(s_2 = 11001100\\ldots\\)</td><td>2nd</td><td class="hi">1</td><td class="flip">0</td></tr>
                    <tr><td>\\(s_3 = 00000000\\ldots\\)</td><td>3rd</td><td class="hi">0</td><td class="flip">1</td></tr>
                    <tr><td>\\(s_4 = 10101010\\ldots\\)</td><td>4th</td><td class="hi">1</td><td class="flip">0</td></tr>
                </tbody>
            </table>
            <div class="answer-box">
                <span class="check">✓</span>
                <div class="content">
                    <div class="answer-label">Answer (b)</div>
                    <p>\\(t = 1010\\ldots\\) &ensp; For any \\(s_i\\), \\(t\\) differs at position \\(i\\) by construction, so \\(t \\neq s_i\\) for all \\(i\\).</p>
                </div>
            </div>
        </div>
    </div>

    <!-- Q2 -->
    <div class="q-card" id="q2">
        <div class="q-header">
            <span class="q-num">Q 02</span>
            <span class="q-title">Proof by Induction</span>
            <div class="q-meta"><span class="diff-easy">Easy</span><span class="q-points">10 pts</span></div>
        </div>
        <div class="concept-row">
            <span class="concept-label">Concept</span><span class="concept-tag">Mathematical Induction</span>
        </div>
        <div class="q-body">
            <div class="formal"><strong>Statement:</strong> \\(\\displaystyle\\sum_{i=1}^{n}(2i-1)=n^2\\) for all \\(n\\ge1\\) &ensp; (i.e., \\(1+3+5+\\cdots+(2n-1)=n^2\\))</div>
            <div>
                <div class="section-label">Method</div>
                <div class="steps"><ol>
                    <li><strong>Base case:</strong> Show \\(P(1)\\) is true.</li>
                    <li><strong>Inductive hypothesis:</strong> Assume \\(P(k)\\) is true for some \\(k\\ge1\\).</li>
                    <li><strong>Inductive step:</strong> Prove \\(P(k+1)\\) using \\(P(k)\\).</li>
                </ol></div>
            </div>
            <div>
                <div class="section-label">Informal</div>
                <div class="informal">Like dominoes — show the first falls, then show each domino knocks down the next.</div>
            </div>
            <div>
                <div class="section-label">Solution</div>
                <div class="formal">
                    <strong>(a) Base case \\(n=1\\):</strong> LHS \\(=1\\), RHS \\(=1^2=1\\) ✓<br><br>
                    <strong>(b) Inductive hypothesis:</strong> Assume \\(\\sum_{i=1}^{k}(2i-1)=k^2\\).<br><br>
                    <strong>(c) Inductive step:</strong>
                    \\[\\sum_{i=1}^{k+1}(2i-1)=k^2+(2(k+1)-1)=k^2+2k+1=(k+1)^2\\]
                </div>
            </div>
            <div class="answer-box">
                <span class="check">✓</span>
                <div class="content">
                    <div class="answer-label">Answer</div>
                    <p>The formula \\(\\sum_{i=1}^{n}(2i-1)=n^2\\) is proven true for all \\(n\\ge1\\) by mathematical induction.</p>
                </div>
            </div>
        </div>
    </div>

    <!-- Q3 -->
    <div class="q-card" id="q3">
        <div class="q-header">
            <span class="q-num">Q 03</span>
            <span class="q-title">Pigeonhole Principle</span>
            <div class="q-meta"><span class="diff-easy">Easy</span><span class="q-points">8 pts</span></div>
        </div>
        <div class="concept-row">
            <span class="concept-label">Concept</span><span class="concept-tag">Pigeonhole Principle</span>
        </div>
        <div class="q-body">
            <div class="informal">6 pairs of socks (6 colors, 2 each). Minimum draws to guarantee a matching pair?</div>
            <div>
                <div class="section-label">Your Answer</div>
                <div class="student-block">"pigeonhole principle" — partial credit only</div>
            </div>
            <div>
                <div class="section-label">Formal Principle</div>
                <div class="formal">If \\(n\\) items are placed into \\(m\\) containers and \\(n>m\\), at least one container has \\(\\ge2\\) items.
                \\[\\text{Minimum to guarantee a duplicate}=m+1\\]</div>
            </div>
            <div>
                <div class="section-label">Informal</div>
                <div class="informal">First 6 draws could each be a different color. The 7th must repeat — like 7 pigeons into 6 holes.</div>
            </div>
            <div class="answer-box">
                <span class="check">✓</span>
                <div class="content">
                    <div class="answer-label">Answer</div>
                    <p><strong>7 socks.</strong> Worst case: first 6 are all different colors. The 7th must match one.</p>
                </div>
            </div>
        </div>
    </div>

    <!-- Q4 -->
    <div class="q-card" id="q4">
        <div class="q-header">
            <span class="q-num">Q 04</span>
            <span class="q-title">Sets and Cardinality</span>
            <div class="q-meta"><span class="diff-medium">Medium</span><span class="q-points">9 pts</span></div>
        </div>
        <div class="concept-row">
            <span class="concept-label">Concept</span>
            <span class="concept-tag">Cardinality & Bijections</span>
            <span class="concept-ref">— Sipser §0.4</span>
        </div>
        <div class="q-body">
            <div class="formal">\\(E=\\{0,2,4,6,\\dots\\}\\) (even naturals) · \\(F=\\{0,4,8,12,\\dots\\}\\) (multiples of 4)</div>
            <div>
                <div class="section-label">Your Answer</div>
                <div class="student-block">"\\(F\\) is a subset of \\(E\\). \\(E\\) and \\(F\\) have the same [incomplete]"</div>
            </div>
            <div>
                <div class="section-label">Formal Definition</div>
                <div class="formal"><strong>Cantor — Equal Cardinality:</strong> Two sets have the same cardinality iff there exists a <strong>bijection</strong> (one-to-one and onto) between them.</div>
            </div>
            <div>
                <div class="section-label">Informal</div>
                <div class="informal">Infinite sets can be the same size as their proper subsets. Pair each \\(2k\\in E\\) with \\(4k\\in F\\) — a perfect matching.</div>
            </div>
            <div>
                <div class="section-label">Solution</div>
                <div class="formal">
                    Define \\(f:E\\to F\\) by \\(f(x)=2x\\).<br>
                    <strong>One-to-one:</strong> \\(f(a)=f(b)\\Rightarrow a=b\\).<br>
                    <strong>Onto:</strong> For \\(y=4k\\in F\\), let \\(x=2k\\in E\\); then \\(f(x)=4k=y\\).
                </div>
            </div>
            <div class="answer-box">
                <span class="check">✓</span>
                <div class="content">
                    <div class="answer-label">Answer</div>
                    <p>\\(E\\) and \\(F\\) have the same cardinality — both are countably infinite.</p>
                </div>
            </div>
        </div>
    </div>

    <!-- Q5 -->
    <div class="q-card" id="q5">
        <div class="q-header">
            <span class="q-num">Q 05</span>
            <span class="q-title">Relations and Functions</span>
            <div class="q-meta"><span class="diff-easy">Easy</span><span class="q-points">8 pts</span></div>
        </div>
        <div class="concept-row">
            <span class="concept-label">Concept</span><span class="concept-tag">Relations & Functions</span>
        </div>
        <div class="q-body">
            <div class="informal">\\(S\\) = set of students. Define a binary relation on \\(S\\) that is also a function, and justify.</div>
            <div>
                <div class="section-label">Formal Definition</div>
                <div class="formal">A relation \\(R\\subseteq S\\times T\\) is a <strong>function</strong> from \\(S\\) to \\(T\\) if for every \\(x\\in S\\) there exists <strong>exactly one</strong> \\(y\\in T\\) with \\((x,y)\\in R\\).</div>
            </div>
            <div>
                <div class="section-label">Informal</div>
                <div class="informal">A function gives each input exactly one output. "Student maps to their student ID" works — every student has exactly one ID.</div>
            </div>
            <div class="answer-box">
                <span class="check">✓</span>
                <div class="content">
                    <div class="answer-label">Answer</div>
                    <p>Let \\(R=\\{(x,y)\\mid y\\text{ is }x\\text{'s assigned desk partner}\\}\\).</p>
                    <p style="margin-top:0.3rem; font-size:0.87rem; color:#a8d4be;">This is a function: every student has exactly one desk partner (existence + uniqueness).</p>
                </div>
            </div>
        </div>
    </div>

    <!-- Q6 -->
    <div class="q-card" id="q6">
        <div class="q-header">
            <span class="q-num">Q 06</span>
            <span class="q-title">Equivalence Relations</span>
            <div class="q-meta"><span class="diff-medium">Medium</span><span class="q-points">10 pts</span></div>
        </div>
        <div class="concept-row">
            <span class="concept-label">Concept</span>
            <span class="concept-tag">Equivalence Relations</span>
            <span class="concept-tag">Modular Arithmetic</span>
        </div>
        <div class="q-body">
            <div class="formal">Set \\(E=\\{0,2,4,6,\\dots\\}\\) · Relation: \\(a\\sim b\\) iff \\(a\\equiv b\\pmod{4}\\)</div>
            <div>
                <div class="section-label">Definition</div>
                <div class="steps"><ol>
                    <li><strong>Reflexive:</strong> \\(a\\sim a\\) for all \\(a\\)</li>
                    <li><strong>Symmetric:</strong> \\(a\\sim b\\Rightarrow b\\sim a\\)</li>
                    <li><strong>Transitive:</strong> \\(a\\sim b\\) and \\(b\\sim c\\Rightarrow a\\sim c\\)</li>
                </ol></div>
            </div>
            <div>
                <div class="section-label">Informal</div>
                <div class="informal">Groups even numbers by remainder mod 4. Like mutual friendship: reflexive, symmetric, transitive.</div>
            </div>
            <div>
                <div class="section-label">Verification</div>
                <div class="formal">
                    <strong>Reflexive:</strong> \\(a-a=0\\), divisible by 4 ✓<br>
                    <strong>Symmetric:</strong> \\(4\\mid(a-b)\\Rightarrow4\\mid(b-a)\\) ✓<br>
                    <strong>Transitive:</strong> \\(a-b=4k,\\ b-c=4m\\Rightarrow a-c=4(k+m)\\) ✓
                </div>
            </div>
            <div class="answer-box">
                <span class="check">✓</span>
                <div class="content">
                    <div class="answer-label">Answer</div>
                    <p>\\(a\\sim b\\) iff \\(a\\equiv b\\pmod{4}\\) is an equivalence relation on \\(E\\).</p>
                    <p style="margin-top:0.4rem; font-size:0.88rem; color:#a8d4be;">Classes: \\([0]=\\{0,4,8,\\dots\\}\\) · \\([2]=\\{2,6,10,\\dots\\}\\)</p>
                </div>
            </div>
        </div>
    </div>

    <!-- Q7 -->
    <div class="q-card" id="q7">
        <div class="q-header">
            <span class="q-num">Q 07</span>
            <span class="q-title">Probability</span>
            <div class="q-meta"><span class="diff-easy">Easy</span><span class="q-points">11 pts</span></div>
        </div>
        <div class="concept-row">
            <span class="concept-label">Concept</span><span class="concept-tag">Discrete Probability</span>
        </div>
        <div class="q-body">
            <div class="informal">Fair coin \\(P(H)=P(T)=\\tfrac{1}{2}\\) · fair six-sided die \\(P(k)=\\tfrac{1}{6}\\)</div>
            <hr class="divider">
            <div>
                <div class="section-label">Part (a) · At least one head in three tosses</div>
                <div class="formal"><strong>Complement Rule:</strong> \\(P(\\text{at least one})=1-P(\\text{none})\\)
                \\[P(\\text{no heads})=\\left(\\tfrac{1}{2}\\right)^3=\\tfrac{1}{8}\\]</div>
                <div class="informal" style="margin-top:0.5rem;">"All tails" is \\(\\tfrac{1}{8}\\), so "at least one head" is everything else.</div>
            </div>
            <div class="answer-box">
                <span class="check">✓</span>
                <div class="content">
                    <div class="answer-label">Answer (a)</div>
                    <p>\\(P(\\text{at least one head})=\\dfrac{7}{8}\\)</p>
                </div>
            </div>
            <hr class="divider">
            <div>
                <div class="section-label">Part (b) · Even die AND tail</div>
                <div class="formal"><strong>Multiplication Rule (independent):</strong> \\(P(A\\cap B)=P(A)\\cdot P(B)\\)
                \\[P(\\text{even})=\\tfrac{1}{2},\\quad P(\\text{tail})=\\tfrac{1}{2}\\]</div>
                <div class="informal" style="margin-top:0.5rem;">Die and coin are independent — multiply.</div>
            </div>
            <div class="answer-box">
                <span class="check">✓</span>
                <div class="content">
                    <div class="answer-label">Answer (b)</div>
                    <p>\\(P(\\text{even and tail})=\\dfrac{1}{4}\\)</p>
                </div>
            </div>
        </div>
    </div>

    <!-- Q8 -->
    <div class="q-card" id="q8">
        <div class="q-header">
            <span class="q-num">Q 08</span>
            <span class="q-title">Weekly Course Content</span>
            <div class="q-meta"><span class="diff-easy">Easy</span><span class="q-points">12 pts</span></div>
        </div>
        <div class="concept-row">
            <span class="concept-label">Concept</span>
            <span class="concept-tag">Finite Automata</span>
            <span class="concept-tag">Regular Languages</span>
            <span class="concept-ref">— Sipser §1.1–1.3</span>
        </div>
        <div class="q-body">
            <div>
                <div class="section-label">Your Summary</div>
                <div class="student-block">Learned about NFA and DFA, 5-tuples, regular languages, DFA ⊆ NFA, Kleene's theorem, regular expressions.</div>
            </div>
            <div>
                <div class="section-label">Formal Concepts</div>
                <div class="formal">
                    <strong>DFA/NFA 5-tuple:</strong> \\((Q,\\Sigma,\\delta,q_0,F)\\)<br><br>
                    <strong>Kleene's Theorem:</strong> Finite automata and regular expressions are equivalent in expressive power — both describe exactly the regular languages.
                </div>
            </div>
            <div>
                <div class="section-label">Informal</div>
                <div class="informal">DFA always knows the next move. NFA "guesses" multiple paths. Both share the same 5-part blueprint. Kleene's theorem ties them to regex patterns like <code style="color:var(--accent2);">a*b*</code> used in text search.</div>
            </div>
            <div class="answer-box">
                <span class="check">✓</span>
                <div class="content">
                    <div class="answer-label">Answer</div>
                    <blockquote>In week 1 of COSC 3340 we defined DFAs and NFAs using the 5-tuple \\((Q,\\Sigma,\\delta,q_0,F)\\). DFAs are a special case of NFAs; both recognize the class of regular languages. Kleene's theorem establishes the equivalence between finite automata and regular expressions.</blockquote>
                </div>
            </div>
        </div>
    </div>

    <footer>
        COSC 3340 · Automata & Computability · Quiz 1 · Complete Solutions
    </footer>

</div>
</body>
</html>`;export{n as default};
