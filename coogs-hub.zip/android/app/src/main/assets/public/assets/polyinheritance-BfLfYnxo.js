const e=`nheritance = Share code between classes.

Polymorphism = Share code and allow different behavior for the same method.
`;export{e as default};
