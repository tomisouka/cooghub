const n=`<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>COSC 3320 Intro Exam — Review & Solutions</title>
<link href="https://fonts.googleapis.com/css2?family=JetBrains+Mono:ital,wght@0,400;0,600;0,700;1,400&family=Space+Grotesk:wght@300;400;500;600;700&display=swap" rel="stylesheet">
<style>
  :root {
    --bg: #030508;
    --surface: #080c12;
    --card: #0a0f1a;
    --card2: #0d1320;
    --border: #141e30;
    --border2: #1e2e48;
    --accent: #f5a623;
    --blue: #4a9eff;
    --blue2: #2563eb;
    --green: #00e676;
    --red: #ff4757;
    --purple: #c084fc;
    --cyan: #00e5ff;
    --teal: #1de9b6;
    --text: #cdd9ed;
    --muted: #3a4d68;
    --sub: #6880a2;
    --mono: 'JetBrains Mono', monospace;
    --sans: 'Space Grotesk', sans-serif;
  }

  * { box-sizing: border-box; margin: 0; padding: 0; }

  body {
    background: var(--bg);
    color: var(--text);
    font-family: var(--sans);
    font-weight: 400;
    min-height: 100vh;
    overflow-x: hidden;
  }

  body::before {
    content: '';
    position: fixed;
    inset: 0;
    background-image:
      linear-gradient(rgba(74,158,255,0.025) 1px, transparent 1px),
      linear-gradient(90deg, rgba(74,158,255,0.025) 1px, transparent 1px);
    background-size: 40px 40px;
    pointer-events: none;
    z-index: 0;
  }

  body::after {
    content: '';
    position: fixed;
    inset: 0;
    background:
      radial-gradient(ellipse at 5% 0%, rgba(245,166,35,0.06) 0%, transparent 40%),
      radial-gradient(ellipse at 95% 100%, rgba(74,158,255,0.06) 0%, transparent 40%);
    pointer-events: none;
    z-index: 0;
  }

  header, .container, footer { position: relative; z-index: 1; }

  /* HEADER */
  header {
    background: var(--surface);
    border-bottom: 1px solid var(--border);
    position: relative;
  }
  header::after {
    content: '';
    position: absolute;
    bottom: 0; left: 0; right: 0;
    height: 1px;
    background: linear-gradient(90deg, transparent, var(--accent), transparent);
    opacity: 0.4;
  }
  .header-main {
    display: flex;
    justify-content: space-between;
    align-items: center;
    padding: 1.8rem 3rem;
    gap: 1.5rem;
  }
  .course-id {
    font-family: var(--mono);
    font-size: 0.65rem;
    letter-spacing: 0.18em;
    color: var(--accent);
    text-transform: uppercase;
    margin-bottom: 0.35rem;
    display: flex; align-items: center; gap: 0.5rem;
  }
  .course-id::before {
    content: '>';
    color: var(--green);
    animation: blink 1.2s step-end infinite;
  }
  @keyframes blink { 50% { opacity: 0; } }

  h1 {
    font-family: var(--mono);
    font-size: 1.3rem;
    font-weight: 700;
    color: #fff;
  }
  h1 .dim { color: var(--sub); font-weight: 400; }
  .header-sub {
    font-family: var(--mono);
    font-size: 0.68rem;
    color: var(--muted);
    margin-top: 0.3rem;
    letter-spacing: 0.04em;
  }

  .score-grid {
    display: flex;
    gap: 1px;
    background: var(--border);
    border: 1px solid var(--border2);
    border-radius: 6px;
    overflow: hidden;
    flex-shrink: 0;
    box-shadow: 0 0 20px rgba(74,158,255,0.1);
  }
  .score-cell {
    background: var(--card);
    padding: 0.75rem 1.3rem;
    text-align: center;
    min-width: 5rem;
  }
  .score-cell-label {
    font-family: var(--mono);
    font-size: 0.5rem;
    letter-spacing: 0.12em;
    text-transform: uppercase;
    color: var(--muted);
    margin-bottom: 0.25rem;
  }
  .score-cell-val { font-family: var(--mono); font-size: 1.25rem; font-weight: 700; line-height: 1; }
  .sv-earned { color: var(--red); }
  .sv-max { color: var(--muted); font-size: 0.8rem; }
  .sv-student { color: var(--accent); font-size: 1rem; font-weight: 700; }

  .header-bar {
    display: flex;
    border-top: 1px solid var(--border);
    font-family: var(--mono);
    font-size: 0.62rem;
    letter-spacing: 0.07em;
  }
  .hbar-item {
    padding: 0.55rem 1.5rem;
    color: var(--muted);
    border-right: 1px solid var(--border);
  }
  .hbar-item span { color: var(--sub); }

  /* CONTAINER */
  .container { max-width: 980px; margin: 0 auto; padding: 2.5rem 2rem; }

  /* SECTION HEADING */
  .section-head {
    display: flex;
    align-items: center;
    gap: 1rem;
    margin: 2.8rem 0 1.3rem;
    font-family: var(--mono);
    font-size: 0.6rem;
    letter-spacing: 0.16em;
    text-transform: uppercase;
    color: var(--muted);
  }
  .section-head::after { content: ''; flex: 1; height: 1px; background: linear-gradient(90deg, var(--border2), transparent); }
  .section-head .sn {
    color: var(--accent);
    font-size: 0.78rem;
    font-weight: 700;
    padding: 0.15rem 0.65rem;
    border: 1px solid rgba(245,166,35,0.3);
    border-radius: 3px;
    background: rgba(245,166,35,0.05);
  }

  /* PROBLEM CARD */
  .pcard {
    background: var(--card);
    border: 1px solid var(--border);
    border-radius: 6px;
    margin-bottom: 1.5rem;
    overflow: hidden;
    transition: border-color 0.2s;
  }
  .pcard:hover { border-color: var(--border2); }

  .pcard-head {
    display: flex;
    align-items: center;
    gap: 0.9rem;
    padding: 1rem 1.4rem;
    cursor: pointer;
    border-bottom: 1px solid var(--border);
    background: rgba(8,12,18,0.8);
    user-select: none;
  }
  .pcard-head:hover { background: rgba(20,30,48,0.5); }

  .p-num {
    font-family: var(--mono);
    font-size: 0.65rem;
    font-weight: 700;
    padding: 0.2rem 0.6rem;
    border-radius: 3px;
    flex-shrink: 0;
    letter-spacing: 0.06em;
  }
  .pn-gold { background: rgba(245,166,35,0.1); color: var(--accent); border: 1px solid rgba(245,166,35,0.25); }
  .pn-blue { background: rgba(74,158,255,0.1); color: var(--blue); border: 1px solid rgba(74,158,255,0.25); }
  .pn-purple { background: rgba(192,132,252,0.1); color: var(--purple); border: 1px solid rgba(192,132,252,0.25); }

  .p-title { font-weight: 600; flex: 1; font-size: 0.93rem; color: var(--text); }
  .p-pts { font-family: var(--mono); font-size: 0.65rem; color: var(--muted); }

  .score-pill {
    font-family: var(--mono);
    font-size: 0.62rem;
    padding: 0.18rem 0.65rem;
    border-radius: 99px;
    border: 1px solid;
    flex-shrink: 0;
  }
  .sp-bad { color: var(--red); border-color: rgba(255,71,87,0.3); background: rgba(255,71,87,0.07); }
  .sp-mid { color: var(--accent); border-color: rgba(245,166,35,0.3); background: rgba(245,166,35,0.07); }
  .sp-ok { color: var(--green); border-color: rgba(0,230,118,0.3); background: rgba(0,230,118,0.07); }

  .chevron { color: var(--muted); font-size: 0.6rem; transition: transform 0.25s; }
  .pcard.open .chevron { transform: rotate(180deg); }

  .pcard-body { display: none; padding: 1.4rem; }
  .pcard.open .pcard-body { display: block; }

  /* FORMULA BOX */
  .formula-box {
    background: rgba(0,0,0,0.45);
    border: 1px solid var(--border2);
    border-left: 3px solid var(--cyan);
    border-radius: 0 6px 6px 0;
    padding: 1.2rem 1.5rem;
    margin: 1.2rem 0;
    position: relative;
  }
  .formula-box::before {
    content: 'FORMULA';
    position: absolute;
    top: -0.55rem; left: 1rem;
    font-family: var(--mono);
    font-size: 0.5rem;
    letter-spacing: 0.2em;
    color: var(--cyan);
    background: var(--card);
    padding: 0 0.5rem;
    font-weight: 700;
  }
  .formula-box .formula-main {
    font-family: var(--mono);
    font-size: 1.1rem;
    color: var(--cyan);
    font-weight: 700;
    text-align: center;
    letter-spacing: 0.02em;
    padding: 0.3rem 0;
  }
  .formula-box .formula-alt {
    font-family: var(--mono);
    font-size: 0.78rem;
    color: var(--sub);
    text-align: center;
    margin-top: 0.45rem;
  }
  .formula-box .formula-note {
    font-family: var(--mono);
    font-size: 0.68rem;
    color: var(--muted);
    margin-top: 0.7rem;
    border-top: 1px solid var(--border);
    padding-top: 0.65rem;
    line-height: 1.7;
  }
  .formula-box .formula-note em { color: var(--accent); font-style: normal; font-weight: 600; }

  /* PROBLEM STATEMENT */
  .stmt {
    background: rgba(0,0,0,0.3);
    border-left: 3px solid var(--muted);
    border-radius: 0 4px 4px 0;
    padding: 0.9rem 1.1rem;
    margin-bottom: 1.3rem;
    font-size: 0.87rem;
    color: var(--sub);
    line-height: 1.8;
  }
  .stmt strong { color: var(--accent); font-weight: 600; }
  .stmt em { color: var(--blue); font-style: normal; font-weight: 500; }

  /* SUBSECTION LABEL */
  .slabel {
    font-family: var(--mono);
    font-size: 0.55rem;
    letter-spacing: 0.15em;
    text-transform: uppercase;
    margin: 1.3rem 0 0.55rem;
    display: flex;
    align-items: center;
    gap: 0.5rem;
  }
  .slabel.green { color: var(--green); }
  .slabel.green::before { content: '✓'; }
  .slabel.red { color: var(--red); }
  .slabel.red::before { content: '✗'; }
  .slabel.blue { color: var(--cyan); }
  .slabel.blue::before { content: '→'; }
  .slabel.amber { color: var(--accent); }
  .slabel.amber::before { content: '!'; }

  /* COMPARISON GRID */
  .cmp-grid { display: grid; grid-template-columns: 1fr 1fr; gap: 0.8rem; margin-bottom: 0.8rem; }
  @media (max-width: 600px) { .cmp-grid { grid-template-columns: 1fr; } }

  .cmp-student {
    background: rgba(245,166,35,0.03);
    border: 1px solid rgba(245,166,35,0.15);
    border-radius: 5px;
    padding: 1rem;
  }
  .cmp-label-s {
    font-family: var(--mono); font-size: 0.55rem; letter-spacing: 0.12em; text-transform: uppercase;
    color: var(--accent); margin-bottom: 0.5rem; display: flex; align-items: center; gap: 0.4rem;
  }
  .cmp-label-s::before { content: '✏'; }

  .cmp-correct {
    background: rgba(0,230,118,0.03);
    border: 1px solid rgba(0,230,118,0.15);
    border-radius: 5px;
    padding: 1rem;
  }
  .cmp-label-c {
    font-family: var(--mono); font-size: 0.55rem; letter-spacing: 0.12em; text-transform: uppercase;
    color: var(--green); margin-bottom: 0.5rem; display: flex; align-items: center; gap: 0.4rem;
  }
  .cmp-label-c::before { content: '✓'; font-weight: 700; }

  .cmp-student p, .cmp-correct p { font-size: 0.84rem; color: var(--text); line-height: 1.75; margin-bottom: 0.4rem; }
  .cmp-student p:last-child, .cmp-correct p:last-child { margin: 0; }

  /* PROSE */
  p { font-size: 0.88rem; line-height: 1.85; margin-bottom: 0.7rem; }
  p:last-child { margin-bottom: 0; }
  strong { color: var(--cyan); font-weight: 600; }
  em { color: var(--accent); font-style: italic; }

  /* CODE BLOCK */
  .code {
    font-family: var(--mono);
    background: #020406;
    border: 1px solid var(--border);
    border-radius: 5px;
    padding: 1.1rem 1.3rem;
    margin: 0.7rem 0;
    font-size: 0.8rem;
    line-height: 1.75;
    color: #6880a2;
    overflow-x: auto;
    position: relative;
  }
  .code::before {
    content: '';
    position: absolute;
    top: 0; left: 0;
    width: 2px; height: 100%;
    background: linear-gradient(to bottom, var(--blue2), var(--purple));
    border-radius: 5px 0 0 5px;
  }
  .code .kw { color: var(--purple); font-weight: 600; }
  .code .fn { color: var(--blue); }
  .code .ok { color: var(--green); font-weight: 600; }
  .code .hi { color: var(--cyan); font-weight: 600; }
  .code .cm { color: #2a3d58; font-style: italic; }
  .code .acc { color: var(--accent); }
  .code .rd { color: var(--red); }

  /* MATH INLINE */
  .math {
    font-family: var(--mono);
    color: var(--purple);
    background: rgba(192,132,252,0.08);
    padding: 0.1rem 0.4rem;
    border-radius: 3px;
    font-size: 0.85rem;
    border: 1px solid rgba(192,132,252,0.15);
  }

  /* ANSWER BOX */
  .ans-box {
    display: inline-block;
    font-family: var(--mono);
    font-size: 1rem;
    font-weight: 700;
    color: var(--teal);
    background: rgba(29,233,182,0.06);
    border: 1px solid rgba(29,233,182,0.25);
    border-radius: 4px;
    padding: 0.5rem 1.4rem;
    margin: 0.6rem 0;
    letter-spacing: 0.02em;
  }

  /* TABLE */
  table { width: 100%; border-collapse: collapse; margin: 0.7rem 0; font-size: 0.82rem; }
  th {
    font-family: var(--mono); font-size: 0.6rem; letter-spacing: 0.08em;
    padding: 0.6rem 1rem; background: rgba(74,158,255,0.05);
    color: var(--blue); border-bottom: 1px solid var(--border); text-align: left;
    text-transform: uppercase;
  }
  td { padding: 0.55rem 1rem; border-bottom: 1px solid rgba(20,30,48,0.8); font-family: var(--mono); font-size: 0.78rem; }
  tr:last-child td { border-bottom: none; }
  tr:hover td { background: rgba(74,158,255,0.02); }
  td.g { color: var(--green); } td.r { color: var(--red); } td.am { color: var(--accent); }

  /* CALLOUT */
  .callout { border-radius: 4px; padding: 0.9rem 1.15rem; margin: 0.8rem 0; }
  .callout-lbl { font-family: var(--mono); font-size: 0.55rem; letter-spacing: 0.14em; text-transform: uppercase; margin-bottom: 0.4rem; font-weight: 700; }
  .callout p { font-size: 0.84rem; margin: 0; }
  .c-red { background: rgba(255,71,87,0.05); border: 1px solid rgba(255,71,87,0.18); border-left: 3px solid var(--red); }
  .c-red .callout-lbl { color: var(--red); }
  .c-green { background: rgba(0,230,118,0.04); border: 1px solid rgba(0,230,118,0.18); border-left: 3px solid var(--green); }
  .c-green .callout-lbl { color: var(--green); }
  .c-blue { background: rgba(74,158,255,0.04); border: 1px solid rgba(74,158,255,0.18); border-left: 3px solid var(--blue); }
  .c-blue .callout-lbl { color: var(--blue); }
  .c-amber { background: rgba(245,166,35,0.04); border: 1px solid rgba(245,166,35,0.18); border-left: 3px solid var(--accent); }
  .c-amber .callout-lbl { color: var(--accent); }

  .qed { text-align: right; font-family: var(--mono); color: var(--green); font-size: 0.9rem; margin-top: 0.5rem; }

  /* ASYMPTOTIC RANKING */
  .rank-row {
    display: flex; align-items: center; gap: 1rem; padding: 0.65rem 1rem;
    background: rgba(0,0,0,0.25); border-radius: 4px; margin: 0.3rem 0;
    border: 1px solid var(--border); transition: border-color 0.2s;
  }
  .rank-row:hover { border-color: var(--border2); }
  .rank-pos { font-family: var(--mono); font-size: 0.63rem; color: var(--muted); min-width: 5rem; font-weight: 600; }
  .rank-expr { font-family: var(--mono); font-size: 0.86rem; color: var(--purple); flex: 1; }
  .rank-tag { font-family: var(--mono); font-size: 0.62rem; padding: 0.15rem 0.55rem; border-radius: 3px; }
  .rt-fast { background: rgba(0,230,118,0.1); color: var(--green); }
  .rt-mid { background: rgba(245,166,35,0.1); color: var(--accent); }
  .rt-slow { background: rgba(255,71,87,0.1); color: var(--red); }

  footer {
    text-align: center; padding: 2.5rem;
    font-family: var(--mono); font-size: 0.62rem; color: var(--muted);
    border-top: 1px solid var(--border); margin-top: 3rem;
    letter-spacing: 0.08em;
  }
</style>
</head>
<body>

<header>
  <div class="header-main">
    <div>
      <div class="course-id">COSC 3320 — Algorithms &amp; Data Structures</div>
      <h1>Intro Exam <span class="dim">—</span> Complete Review &amp; Solutions</h1>
      <div class="header-sub">// Thursday, February 5, 2026 · 45 minutes · Student: Jesrah Agudele</div>
    </div>
    <div class="score-grid">
      <div class="score-cell">
        <div class="score-cell-label">Problem 1</div>
        <div class="score-cell-val sv-earned">7</div>
        <div class="score-cell-val sv-max">/30</div>
      </div>
      <div class="score-cell">
        <div class="score-cell-label">Problem 2</div>
        <div class="score-cell-val sv-earned">15</div>
        <div class="score-cell-val sv-max">/30</div>
      </div>
      <div class="score-cell">
        <div class="score-cell-label">Problem 3</div>
        <div class="score-cell-val sv-earned">0</div>
        <div class="score-cell-val sv-max">/40</div>
      </div>
      <div class="score-cell">
        <div class="score-cell-label">Total</div>
        <div class="score-cell-val sv-student">22/100</div>
      </div>
    </div>
  </div>
  <div class="header-bar">
    <div class="hbar-item">Topics: <span>Combinatorics · Induction · Recursion · Recurrences</span></div>
    <div class="hbar-item">Skills: <span>Big-O · Permutations · Counting · D&amp;C · Master Theorem</span></div>
  </div>
</header>

<div class="container">

  <!-- P1 -->
  <div class="section-head"><span class="sn">P1</span> Combinatorics — Permutations &amp; Combinations — 30 pts</div>

  <!-- 1a -->
  <div class="pcard open">
    <div class="pcard-head" onclick="toggle(this)">
      <span class="p-num pn-gold">1a</span>
      <span class="p-title">Different tickets, different movies, each student ≤ 1 ticket</span>
      <span class="p-pts">8 pts</span>
      <span class="score-pill sp-bad">~0 pts</span>
      <span class="chevron">▼</span>
    </div>
    <div class="pcard-body">
      <div class="stmt">
        There are <em>n</em> students and <em>k ≤ n</em> movie tickets. Tickets are for <strong>different</strong> movies, each student gets <strong>at most one ticket</strong>. In how many different ways can k tickets be distributed?
      </div>

      <div class="formula-box">
        <div class="formula-main">P(n, k) = n! / (n − k)!</div>
        <div class="formula-alt">= n × (n−1) × (n−2) × … × (n−k+1)</div>
        <div class="formula-note">
          <em>Why?</em> Tickets are DISTINCT (different movies) → order matters → k-permutation of n items.<br>
          C(n,k) ways to choose which k students get tickets × k! ways to assign the distinct tickets = C(n,k)·k! = P(n,k).
        </div>
      </div>

      <div class="cmp-grid">
        <div class="cmp-student">
          <div class="cmp-label-s">Student wrote</div>
          <p>Wrote "n!" — confusing permutations of all n students with the correct formula. Also wrote P(n,k) to the side (correct!) but didn't commit to it.</p>
        </div>
        <div class="cmp-correct">
          <div class="cmp-label-c">Correct Answer</div>
          <p>This is a <strong>k-permutation</strong>. Giving ticket A to student X differs from giving ticket B to student X — order matters.</p>
          <p><span class="math">P(n, k) = n! / (n−k)!</span></p>
        </div>
      </div>

      <div class="code">
<span class="acc">Example (n=3, k=2):</span>  students {A,B,C}, tickets {movie1, movie2}
  A→m1,B→m2  |  A→m2,B→m1  |  B→m1,C→m2  |  B→m2,C→m1  |  A→m1,C→m2  |  A→m2,C→m1
  P(3,2) = 3!/1! = <span class="ok">6</span>  ✓
      </div>
      <div class="ans-box">Answer: P(n, k) = n! / (n − k)!</div>
    </div>
  </div>

  <!-- 1b -->
  <div class="pcard open">
    <div class="pcard-head" onclick="toggle(this)">
      <span class="p-num pn-gold">1b</span>
      <span class="p-title">Different tickets, different movies, each student can get any number ≤ k</span>
      <span class="p-pts">7 pts</span>
      <span class="score-pill sp-bad">~0 pts</span>
      <span class="chevron">▼</span>
    </div>
    <div class="pcard-body">
      <div class="stmt">
        Tickets are for <strong>different</strong> movies, each student can get <strong>any number</strong> of tickets (not exceeding k). How many ways?
      </div>

      <div class="formula-box">
        <div class="formula-main">n^k  =  n × n × … × n  (k times)</div>
        <div class="formula-alt">Each of k distinct tickets independently assigned to any of n students</div>
        <div class="formula-note">
          <em>Why?</em> Each ticket independently has n choices of student (repetition allowed). k independent decisions → Multiplication Principle → n^k.
        </div>
      </div>

      <div class="cmp-grid">
        <div class="cmp-student">
          <div class="cmp-label-s">Student wrote</div>
          <p>Tried a summation with C(n,u)·C(n-u, j-u). Over-complicated. Crossed out and marked wrong.</p>
        </div>
        <div class="cmp-correct">
          <div class="cmp-label-c">Correct Answer</div>
          <p>Each of the k distinct tickets independently goes to any of n students (same student allowed). By the multiplication principle: <span class="math">n^k</span>.</p>
        </div>
      </div>

      <div class="code">
<span class="cm">-- Ticket 1: n choices of student</span>
<span class="cm">-- Ticket 2: n choices of student (repetition allowed)</span>
<span class="cm">-- ...        (independently)</span>
<span class="cm">-- Ticket k: n choices of student</span>
<span class="cm">-- Total: n × n × … × n  (k times) = n^k</span>

<span class="acc">Example (n=3, k=2):</span>  3² = <span class="ok">9</span> ways ✓
  (A,A), (A,B), (A,C), (B,A), (B,B), (B,C), (C,A), (C,B), (C,C)
      </div>
      <div class="ans-box">Answer: n^k</div>
    </div>
  </div>

  <!-- 1c -->
  <div class="pcard open">
    <div class="pcard-head" onclick="toggle(this)">
      <span class="p-num pn-gold">1c</span>
      <span class="p-title">Same movie tickets, each student ≤ 1 ticket</span>
      <span class="p-pts">7 pts</span>
      <span class="score-pill sp-mid">~7 pts</span>
      <span class="chevron">▼</span>
    </div>
    <div class="pcard-body">
      <div class="stmt">
        All k tickets are for the <strong>same</strong> movie. Each student may get at most one ticket. How many ways?
      </div>

      <div class="formula-box">
        <div class="formula-main">C(n, k) = n! / (k! · (n − k)!)</div>
        <div class="formula-alt">Also written as nCk or "n choose k"</div>
        <div class="formula-note">
          <em>Why?</em> Tickets are IDENTICAL (same movie) → only the SET of chosen students matters → order doesn't matter → combination, not permutation.
        </div>
      </div>

      <div class="cmp-grid">
        <div class="cmp-student">
          <div class="cmp-label-s">Student wrote</div>
          <p><span class="math">C(n, k)</span> — "the tickets are fixed and the students won't get up the same amount of ways for each ticket so n chooses k" ✓</p>
          <p>Correct formula, reasoning partially correct. Full credit.</p>
        </div>
        <div class="cmp-correct">
          <div class="cmp-label-c">Correct Answer</div>
          <p>Since all tickets are <em>identical</em> (same movie), only the <em>set</em> of students who receive a ticket matters.</p>
          <p>Choose k of n students: <span class="math">C(n,k) = n! / (k!(n−k)!)</span></p>
        </div>
      </div>
      <div class="ans-box">Answer: C(n, k) = n! / (k!(n−k)!)</div>
    </div>
  </div>

  <!-- 1d -->
  <div class="pcard open">
    <div class="pcard-head" onclick="toggle(this)">
      <span class="p-num pn-gold">1d</span>
      <span class="p-title">Rank the three answers by asymptotic growth (k = ⌈n/2⌉)</span>
      <span class="p-pts">8 pts</span>
      <span class="score-pill sp-bad">~0 pts</span>
      <span class="chevron">▼</span>
    </div>
    <div class="pcard-body">
      <div class="stmt">
        Rank the answers from (a), (b), (c) in order of asymptotic growth with respect to n, assuming k = ⌈n/2⌉. Use Big-O, Big-Θ, or little-o notation.
      </div>

      <div class="formula-box">
        <div class="formula-main">C(n, n/2)  =  o( n^(n/2) )  =  o( P(n, n/2) )</div>
        <div class="formula-alt">Slowest → Middle → Fastest  (as n → ∞)</div>
        <div class="formula-note">
          <em>(c)</em> C(n,n/2) = Θ(2^n / √n)  — exponential base 2<br>
          <em>(b)</em> n^k = n^(n/2) = Θ(n^(n/2))  — super-exponential<br>
          <em>(a)</em> P(n,n/2) = n!/(n/2)! = ω(n^k)  — fastest (larger constant per factor)
        </div>
      </div>

      <div class="cmp-grid">
        <div class="cmp-student">
          <div class="cmp-label-s">Student wrote</div>
          <p>Fastest: (c) O(n^n) — <strong>WRONG</strong></p>
          <p>(a) O(n!) — right direction, wrong value</p>
          <p>Slowest: (b) O(n^n) — <strong>WRONG</strong></p>
        </div>
        <div class="cmp-correct">
          <div class="cmp-label-c">Correct Ranking</div>
          <p>C(n,n/2) = Θ(2^n/√n) → exponential</p>
          <p>n^k = n^(n/2) → super-exponential</p>
          <p>P(n,n/2) = n!/(n/2)! → fastest (ω above n^k)</p>
        </div>
      </div>

      <div class="code">
<span class="hi">Part (a):</span>  P(n, k) = n!/(n−k)! = n!/(n/2)!
  Each of n/2 factors is in range (n/2, n], so &gt; (n/2)^(n/2)
  <span class="acc">≈ Θ(n^(n/2)) with larger constant — FASTEST</span>

<span class="hi">Part (b):</span>  n^k = n^(n/2)
  <span class="acc">Θ(n^(n/2)) — middle; P(n,n/2) = ω(n^k)</span>

<span class="hi">Part (c):</span>  C(n, k) = n! / ((n/2)!)²
  Central binomial coefficient: C(n, n/2) = Θ(2^n / √n)
  <span class="acc">Θ(2^n/√n) — SLOWEST (exponential, base 2 &lt; base √n)</span>
      </div>

      <div class="slabel green">Correct Ranking (slowest → fastest)</div>
      <div class="rank-row">
        <div class="rank-pos">🥉 Slowest</div>
        <div class="rank-expr">C(n, n/2) = Θ(2^n / √n)</div>
        <div class="rank-tag rt-slow">Part (c)</div>
      </div>
      <div class="rank-row">
        <div class="rank-pos">🥈 Middle</div>
        <div class="rank-expr">n^k = n^(n/2) = Θ(n^(n/2))</div>
        <div class="rank-tag rt-mid">Part (b)</div>
      </div>
      <div class="rank-row">
        <div class="rank-pos">🥇 Fastest</div>
        <div class="rank-expr">P(n, n/2) = n!/(n/2)! = ω(n^k)</div>
        <div class="rank-tag rt-fast">Part (a)</div>
      </div>

      <div class="callout c-blue">
        <div class="callout-lbl">Key Insight</div>
        <p>C(n, n/2) = Θ(2^n/√n) grows exponentially (base 2). But n^(n/2) = (√n)^n grows super-exponentially since base √n &gt; 2 for n &gt; 4. So (c) &lt; (b) ≤ (a) asymptotically.</p>
      </div>
    </div>
  </div>

  <!-- P2 -->
  <div class="section-head"><span class="sn">P2</span> Mathematical Induction: 6^n − 1 divisible by 5 — 30 pts</div>

  <!-- 2.1 -->
  <div class="pcard open">
    <div class="pcard-head" onclick="toggle(this)">
      <span class="p-num pn-blue">2.1</span>
      <span class="p-title">Induction variable</span>
      <span class="p-pts">2 pts</span>
      <span class="score-pill sp-ok">✓ 2 pts</span>
      <span class="chevron">▼</span>
    </div>
    <div class="pcard-body">
      <div class="stmt">What is the induction variable?</div>
      <div class="formula-box">
        <div class="formula-main">Induction variable:  n</div>
        <div class="formula-alt">We prove P(n): "5 | (6^n − 1)" for all integers n ≥ 1</div>
      </div>
      <div class="cmp-grid">
        <div class="cmp-student">
          <div class="cmp-label-s">Student: n — "main variable we're solving for" ✓</div>
          <p>Correct.</p>
        </div>
        <div class="cmp-correct">
          <div class="cmp-label-c">Correct: n</div>
          <p>The induction variable is <strong>n</strong>, the positive integer exponent. We prove P(n): "5 | (6^n − 1)" for all n ≥ 1.</p>
        </div>
      </div>
    </div>
  </div>

  <!-- 2.2 -->
  <div class="pcard open">
    <div class="pcard-head" onclick="toggle(this)">
      <span class="p-num pn-blue">2.2</span>
      <span class="p-title">Base case</span>
      <span class="p-pts">3 pts</span>
      <span class="score-pill sp-ok">✓ 3 pts</span>
      <span class="chevron">▼</span>
    </div>
    <div class="pcard-body">
      <div class="stmt">What is the base case of the induction?</div>
      <div class="formula-box">
        <div class="formula-main">n = 1 :  6^1 − 1 = 5  ✓</div>
        <div class="formula-alt">5 divides 5 → base case holds</div>
      </div>
      <div class="cmp-grid">
        <div class="cmp-student">
          <div class="cmp-label-s">Student wrote: 6^(1) − 1 = 5, divisible by 5 ✓</div>
          <p>Correct base case and arithmetic.</p>
        </div>
        <div class="cmp-correct">
          <div class="cmp-label-c">Correct</div>
          <p><strong>n = 1:</strong> 6^1 − 1 = 5. Since 5 | 5, the base case holds. ✓</p>
        </div>
      </div>
    </div>
  </div>

  <!-- 2.3 -->
  <div class="pcard open">
    <div class="pcard-head" onclick="toggle(this)">
      <span class="p-num pn-blue">2.3</span>
      <span class="p-title">Inductive hypothesis</span>
      <span class="p-pts">7 pts</span>
      <span class="score-pill sp-mid">~4 pts</span>
      <span class="chevron">▼</span>
    </div>
    <div class="pcard-body">
      <div class="stmt">What is the induction hypothesis?</div>
      <div class="formula-box">
        <div class="formula-main">IH:  Assume  5 | (6^k − 1)  for some integer k ≥ 1</div>
        <div class="formula-alt">Equivalently:  6^k − 1 = 5m  for some integer m  ⟺  6^k = 5m + 1</div>
        <div class="formula-note">
          <em>Goal of inductive step:</em> Use IH to show P(k+1): that 5 | (6^(k+1) − 1) also holds.
        </div>
      </div>
      <div class="cmp-grid">
        <div class="cmp-student">
          <div class="cmp-label-s">Student wrote</div>
          <p>"Assume P(n) = P(n+1), and n≥0" — <strong>wrong</strong></p>
          <p>"Given 6^(n-1) − 1 = 6^(n+1) − 1 is also divisible by 5" — confused</p>
        </div>
        <div class="cmp-correct">
          <div class="cmp-label-c">Correct IH</div>
          <p><strong>IH:</strong> Assume that for some integer k ≥ 1, <span class="math">5 | (6^k − 1)</span>. Equivalently: 6^k − 1 = 5m for some integer m.</p>
        </div>
      </div>
      <div class="callout c-red">
        <div class="callout-lbl">Student Error</div>
        <p>"P(n) = P(n+1)" is nonsensical as an IH. The correct IH is: <em>Assume P(k) is true</em> (assume 5 | 6^k−1 for some specific k), then prove P(k+1).</p>
      </div>
    </div>
  </div>

  <!-- 2.4 -->
  <div class="pcard open">
    <div class="pcard-head" onclick="toggle(this)">
      <span class="p-num pn-blue">2.4</span>
      <span class="p-title">Inductive step — prove it</span>
      <span class="p-pts">15 pts</span>
      <span class="score-pill sp-bad">~3 pts</span>
      <span class="chevron">▼</span>
    </div>
    <div class="pcard-body">
      <div class="stmt">State what you should prove in the inductive step and prove it.</div>

      <div class="formula-box">
        <div class="formula-main">Goal: Show  5 | (6^(k+1) − 1)</div>
        <div class="formula-alt">Key identity: 6^(k+1) = 6 · 6^k  →  substitute IH (6^k = 5m+1)</div>
        <div class="formula-note">
          <em>Derivation:</em> 6^(k+1) − 1 = 6·(5m+1) − 1 = 30m + 6 − 1 = 30m + 5 = 5(6m+1) ✓
        </div>
      </div>

      <div class="slabel red">Student's Attempt</div>
      <div class="cmp-student" style="margin-bottom:1rem">
        <div class="cmp-label-s">Student wrote</div>
        <p>Computed 6^(k+1) − 1 for specific values (k=1: 35, k=2: 215...) without a general algebraic proof. "This proves n times will always end up divisible by 5" — examples only demonstrate, never prove.</p>
      </div>

      <div class="slabel green">Correct Inductive Step</div>
      <div class="code">
<span class="kw">Inductive Hypothesis (IH):</span>  5 | (6^k − 1)
                           i.e., 6^k − 1 = 5m  for some integer m
                           i.e., <span class="hi">6^k = 5m + 1</span>

<span class="kw">Want to show:</span>  5 | (6^(k+1) − 1)

<span class="hi">Proof:</span>
  6^(k+1) − 1
  = 6 · 6^k − 1                <span class="cm">-- rewrite using exponent rule</span>
  = 6 · (5m + 1) − 1          <span class="cm">-- substitute IH: 6^k = 5m + 1</span>
  = 30m + 6 − 1
  = 30m + 5
  = 5(6m + 1)                 <span class="cm">-- factor out 5</span>

Since (6m + 1) is an integer, <span class="ok">5 | (6^(k+1) − 1)</span>.  ✓
      </div>
      <p>By the principle of mathematical induction, 5 | (6^n − 1) for all positive integers n.</p>
      <div class="qed">□</div>
    </div>
  </div>

  <!-- 2.5 -->
  <div class="pcard open">
    <div class="pcard-head" onclick="toggle(this)">
      <span class="p-num pn-blue">2.5</span>
      <span class="p-title">Weak or strong induction?</span>
      <span class="p-pts">3 pts</span>
      <span class="score-pill sp-ok">✓ 3 pts</span>
      <span class="chevron">▼</span>
    </div>
    <div class="pcard-body">
      <div class="stmt">Did you use weak or strong induction, and why?</div>
      <div class="formula-box">
        <div class="formula-main">Weak Induction:  P(k)  →  P(k+1)</div>
        <div class="formula-alt">Proof of P(k+1) requires only the immediately preceding case P(k)</div>
        <div class="formula-note">
          <em>Strong induction</em> would require P(1)∧P(2)∧…∧P(k) → P(k+1). Here P(k) alone suffices.
        </div>
      </div>
      <div class="cmp-grid">
        <div class="cmp-student">
          <div class="cmp-label-s">Student: "Weak induction, because we only have to prove P(n+1)" ✓</div>
          <p>Essentially correct — weak induction suffices.</p>
        </div>
        <div class="cmp-correct">
          <div class="cmp-label-c">Correct</div>
          <p><strong>Weak induction.</strong> Proof of P(k+1) only requires P(k) — the immediately preceding case. Strong induction is unnecessary here.</p>
        </div>
      </div>
    </div>
  </div>

  <!-- P3 -->
  <div class="section-head"><span class="sn">P3</span> Recursive Algorithm: "Good" Arrays (Even Number of 1s) — 40 pts</div>

  <!-- 3a -->
  <div class="pcard open">
    <div class="pcard-head" onclick="toggle(this)">
      <span class="p-num pn-purple">3a</span>
      <span class="p-title">Describe a recursive algorithm (pseudocode) to determine if A[1..n] is good</span>
      <span class="p-pts">20 pts</span>
      <span class="score-pill sp-bad">0 pts</span>
      <span class="chevron">▼</span>
    </div>
    <div class="pcard-body">
      <div class="stmt">
        An array A of 0s and 1s is <strong>good</strong> if it has an <strong>even number of 1s</strong>. Describe a recursive algorithm (pseudocode) to determine if A[1,…,n] is good.
      </div>

      <div class="formula-box">
        <div class="formula-main">isGood(A, n) = isGood(A, n−1) XOR (A[n] == 1)</div>
        <div class="formula-alt">Base: isGood(A, 0) = True  |  A[n]=0 preserves parity; A[n]=1 flips it</div>
        <div class="formula-note">
          <em>D&amp;C variant:</em>  isGood(A, lo, hi)  =  (isGood(A, lo, mid) == isGood(A, mid+1, hi))<br>
          Parity is additive: good(full) = good(left) XNOR good(right) = (good(left) == good(right))
        </div>
      </div>

      <div class="slabel red">Student's Answer</div>
      <div class="cmp-student" style="margin-bottom:1rem">
        <div class="cmp-label-s">Student wrote</div>
        <p>Attempted D&amp;C with split at n/2. Right idea, but pseudocode was incomplete and unclear. Mentioned "if odd bad, if even good" without completing the logic. Received 0 pts.</p>
      </div>

      <div class="slabel green">Correct Recursive Algorithms</div>
      <div class="code">
<span class="cm">-- APPROACH 1: Simple Linear Recursion (reduce from right)</span>

<span class="fn">isGood</span>(A, n):
  <span class="kw">if</span> n == 0:
    <span class="kw">return</span> <span class="ok">True</span>          <span class="cm">-- 0 ones → even → good (base case)</span>
  <span class="kw">else</span>:
    subResult = <span class="fn">isGood</span>(A, n−1)   <span class="cm">-- is A[1..n-1] good?</span>
    <span class="kw">if</span> A[n] == 0:
      <span class="kw">return</span> subResult           <span class="cm">-- adding a 0 doesn't change parity</span>
    <span class="kw">else</span>:  <span class="cm">-- A[n] == 1</span>
      <span class="kw">return</span> NOT subResult       <span class="cm">-- adding a 1 flips the parity</span>
      </div>

      <div class="code">
<span class="cm">-- APPROACH 2: Divide and Conquer</span>

<span class="fn">isGood</span>(A, lo, hi):
  <span class="kw">if</span> lo == hi:
    <span class="kw">return</span> (A[lo] == 0)          <span class="cm">-- single element: good iff it's 0</span>
  <span class="kw">if</span> lo &gt; hi:
    <span class="kw">return</span> <span class="ok">True</span>                  <span class="cm">-- empty: 0 ones → good</span>
  
  mid = floor((lo + hi) / 2)
  leftGood  = <span class="fn">isGood</span>(A, lo, mid)
  rightGood = <span class="fn">isGood</span>(A, mid+1, hi)
  
  <span class="kw">return</span> (leftGood == rightGood)   <span class="cm">-- XNOR: both even OR both odd → sum is even</span>

<span class="cm">-- Call as: isGood(A, 1, n)</span>
      </div>

      <div class="callout c-blue">
        <div class="callout-lbl">Correctness Intuition</div>
        <p>Parity of 1s is additive: count_1s(A) = count_1s(left) + count_1s(right). Sum is even iff both have even count OR both have odd count → good(A) = (good(left) XNOR good(right)) = (good(left) == good(right)).</p>
      </div>
    </div>
  </div>

  <!-- 3b -->
  <div class="pcard open">
    <div class="pcard-head" onclick="toggle(this)">
      <span class="p-num pn-purple">3b</span>
      <span class="p-title">Prove correctness by mathematical induction</span>
      <span class="p-pts">10 pts</span>
      <span class="score-pill sp-bad">0 pts</span>
      <span class="chevron">▼</span>
    </div>
    <div class="pcard-body">
      <div class="stmt">Prove the correctness of your algorithm using mathematical induction.</div>

      <div class="formula-box">
        <div class="formula-main">Claim:  isGood(A, n) = True  ⟺  #{i : A[i]=1} is even</div>
        <div class="formula-alt">Prove by induction on n (the array length)</div>
        <div class="formula-note">
          <em>Base (n=0):</em> empty → 0 ones → even → True ✓<br>
          <em>Step:</em> A[k+1]=0 → count unchanged → parity preserved; A[k+1]=1 → count +1 → parity flipped (NOT subResult)
        </div>
      </div>

      <div class="slabel red">Student's Answer</div>
      <div class="cmp-student" style="margin-bottom:1rem">
        <div class="cmp-label-s">Student wrote</div>
        <p>"3 constant operations along w/ N/2 or log n operations... show P(n) ≠ P(n+1)... O(log(3))" — this is a runtime analysis, not a correctness proof. Not induction at all.</p>
      </div>

      <div class="slabel green">Correct Inductive Correctness Proof (Linear Recursion)</div>
      <div class="code">
<span class="kw">Base Case (n = 0):</span>
  isGood(A, 0) returns True.
  A[1..0] is empty → 0 ones → even → algorithm is correct. ✓

<span class="kw">Inductive Hypothesis (IH):</span>
  Assume isGood(A, k) returns True iff A[1..k] has an even # of 1s,
  for some k ≥ 0.

<span class="kw">Inductive Step:</span> Show isGood(A, k+1) is correct for all A of length k+1.

  <span class="hi">Case 1:</span> A[k+1] = 0
    isGood(A, k+1) = isGood(A, k)       <span class="cm">-- by algorithm</span>
    By IH: isGood(A, k) = True iff A[1..k] has even 1s.
    Since A[k+1] = 0: count_1s(A[1..k+1]) = count_1s(A[1..k]).
    So isGood(A, k+1) = True iff A[1..k+1] has even 1s. ✓

  <span class="hi">Case 2:</span> A[k+1] = 1
    isGood(A, k+1) = NOT isGood(A, k)   <span class="cm">-- by algorithm</span>
    By IH: isGood(A, k) = True iff A[1..k] has even 1s.
    count_1s(A[1..k+1]) = count_1s(A[1..k]) + 1  →  parity flips.
    NOT isGood(A, k) = True iff A[1..k] has odd 1s
                     = True iff A[1..k+1] has even 1s. ✓

<span class="ok">By induction, isGood(A, n) is correct for all n ≥ 0. □</span>
      </div>
    </div>
  </div>

  <!-- 3c -->
  <div class="pcard open">
    <div class="pcard-head" onclick="toggle(this)">
      <span class="p-num pn-purple">3c</span>
      <span class="p-title">Give a recurrence for the runtime</span>
      <span class="p-pts">5 pts</span>
      <span class="score-pill sp-bad">0 pts</span>
      <span class="chevron">▼</span>
    </div>
    <div class="pcard-body">
      <div class="stmt">Give a recurrence for the runtime of your algorithm.</div>

      <div class="formula-box">
        <div class="formula-main">Linear:  T(n) = T(n−1) + Θ(1),   T(0) = Θ(1)</div>
        <div class="formula-alt">D&amp;C:  T(n) = 2T(n/2) + Θ(1),   T(1) = Θ(1)</div>
        <div class="formula-note">
          <em>Linear:</em> 1 recursive call on n−1 elements + Θ(1) work per call.<br>
          <em>D&amp;C:</em> 2 recursive calls each on n/2 elements + Θ(1) to combine results.
        </div>
      </div>

      <div class="cmp-grid">
        <div class="cmp-student">
          <div class="cmp-label-s">Student wrote: T(n) = T(n−1) + 1</div>
          <p>Correct for linear recursion! But student also wrote "T(n) &lt; n/2 &lt; (n+1)/2" — this is a bound, not the recurrence. Graded 0 due to the confusion.</p>
        </div>
        <div class="cmp-correct">
          <div class="cmp-label-c">Correct Recurrences</div>
          <p><strong>Linear:</strong> <span class="math">T(n) = T(n−1) + Θ(1), T(0) = Θ(1)</span></p>
          <p><strong>D&amp;C:</strong> <span class="math">T(n) = 2T(n/2) + Θ(1), T(1) = Θ(1)</span></p>
        </div>
      </div>
    </div>
  </div>

  <!-- 3d -->
  <div class="pcard open">
    <div class="pcard-head" onclick="toggle(this)">
      <span class="p-num pn-purple">3d</span>
      <span class="p-title">Solve the recurrence and find the runtime</span>
      <span class="p-pts">5 pts</span>
      <span class="score-pill sp-bad">0 pts</span>
      <span class="chevron">▼</span>
    </div>
    <div class="pcard-body">
      <div class="stmt">Solve your recurrence and find the runtime.</div>

      <div class="formula-box">
        <div class="formula-main">T(n) = Θ(n)   for BOTH approaches</div>
        <div class="formula-alt">Linear: unrolling → Θ(n)  |  D&amp;C: Master Theorem Case 1 → Θ(n^log₂2) = Θ(n)</div>
        <div class="formula-note">
          <em>Master Theorem (D&amp;C):</em> a=2, b=2, f(n)=Θ(1). n^(log_b a) = n^1 = n. f(n) = O(n^(1−ε)) → Case 1 → T(n) = Θ(n).<br>
          <em>O(log n) is IMPOSSIBLE</em> — must examine all n elements → Ω(n) lower bound.
        </div>
      </div>

      <div class="cmp-grid">
        <div class="cmp-student">
          <div class="cmp-label-s">Student wrote: T(n) = O(log n)</div>
          <p><strong>WRONG</strong> — O(log n) is impossible for either recursion.</p>
        </div>
        <div class="cmp-correct">
          <div class="cmp-label-c">Correct Solutions</div>
          <p><strong>Linear:</strong> T(n) = Θ(n)  (by unrolling)</p>
          <p><strong>D&amp;C:</strong> T(n) = Θ(n)  (Master Theorem)</p>
        </div>
      </div>

      <div class="code">
<span class="hi">Linear Recursion — Unrolling:</span>
  T(n) = T(n−1) + c
       = T(n−2) + 2c
       = T(n−3) + 3c
       = ...
       = T(0) + n·c
       = Θ(1) + Θ(n)
       = <span class="ok">Θ(n)</span>

<span class="hi">Divide &amp; Conquer — Master Theorem:</span>
  T(n) = 2T(n/2) + Θ(1)
  a=2, b=2, f(n)=Θ(1)
  n^(log_b a) = n^(log_2 2) = n^1 = n
  f(n) = Θ(1) = O(n^(1−ε)) for ε=1  →  <span class="acc">Case 1 applies</span>
  T(n) = Θ(n^(log_b a)) = <span class="ok">Θ(n)</span>

<span class="cm">-- Both approaches give Θ(n).</span>
<span class="cm">-- O(log n) is wrong: we must visit every element at least once.</span>
<span class="cm">-- Lower bound: Ω(n) since any single element could flip the parity.</span>
      </div>

      <div class="callout c-red">
        <div class="callout-lbl">Why O(log n) is impossible</div>
        <p>Any algorithm determining if an array has an even number of 1s must examine all n elements in the worst case — one unexamined element could flip the parity. Therefore T(n) = Ω(n), and O(log n) is impossible. The correct answer is <strong>Θ(n)</strong>.</p>
      </div>
    </div>
  </div>

  <!-- SUMMARY -->
  <div class="section-head"><span class="sn">∑</span> Score Summary &amp; Key Takeaways</div>

  <div class="pcard open">
    <div class="pcard-head" onclick="toggle(this)">
      <span class="p-num pn-gold">📊</span>
      <span class="p-title">Score Breakdown &amp; Study Priorities</span>
      <span class="chevron">▼</span>
    </div>
    <div class="pcard-body">
      <table>
        <tr><th>Problem</th><th>Topic</th><th>Earned</th><th>Max</th><th>Main Error</th></tr>
        <tr><td>1a</td><td>Permutations</td><td class="r">~0</td><td>8</td><td>Confused n! with P(n,k); wrote formula but didn't commit</td></tr>
        <tr><td>1b</td><td>Balls-in-bins counting</td><td class="r">~0</td><td>7</td><td>Over-complicated; answer is simply n^k</td></tr>
        <tr><td>1c</td><td>Combinations</td><td class="g">~7</td><td>7</td><td>Correct! C(n,k) ✓</td></tr>
        <tr><td>1d</td><td>Asymptotic ranking</td><td class="r">~0</td><td>8</td><td>Wrong ordering; misidentified growth rates</td></tr>
        <tr><td>2.1–2.2</td><td>IH variable &amp; base case</td><td class="g">5</td><td>5</td><td>Correct ✓</td></tr>
        <tr><td>2.3</td><td>Inductive hypothesis</td><td class="am">~4</td><td>7</td><td>"P(n)=P(n+1)" is not a valid IH statement</td></tr>
        <tr><td>2.4</td><td>Inductive step</td><td class="r">~3</td><td>15</td><td>Used examples, not algebraic proof; 6^(k+1)=6·6^k identity not used</td></tr>
        <tr><td>2.5</td><td>Weak vs strong induction</td><td class="g">3</td><td>3</td><td>Correct ✓</td></tr>
        <tr><td>3a</td><td>Recursive pseudocode</td><td class="r">0</td><td>20</td><td>D&amp;C idea correct but pseudocode incomplete &amp; unclear</td></tr>
        <tr><td>3b</td><td>Correctness by induction</td><td class="r">0</td><td>10</td><td>Wrote runtime analysis instead of inductive correctness proof</td></tr>
        <tr><td>3c</td><td>Recurrence</td><td class="r">0</td><td>5</td><td>T(n)=T(n-1)+1 is correct but confused with bound</td></tr>
        <tr><td>3d</td><td>Solve recurrence</td><td class="r">0</td><td>5</td><td>O(log n) is wrong; correct is Θ(n)</td></tr>
      </table>

      <div class="callout c-amber">
        <div class="callout-lbl">Top 3 Study Priorities</div>
        <p><strong>1. Inductive Step Algebra:</strong> You must show 5|(6^(k+1)−1) algebraically using 6^(k+1) = 6·6^k and the IH. Examples only demonstrate — they never prove.</p>
        <p><strong>2. Permutations vs Combinations:</strong> P(n,k) = n!/(n−k)! when order matters; C(n,k) = n!/(k!(n−k)!) when order doesn't; n^k when each of k items independently has n choices.</p>
        <p><strong>3. Recurrence Solving &amp; Runtime:</strong> T(n)=T(n−1)+1 → Θ(n) by unrolling. Any algorithm examining all n elements is Ω(n). O(log n) is impossible for "count all 1s" problems.</p>
      </div>
    </div>
  </div>

</div>

<footer>COSC 3320 — Intro Exam · Spring 2026 · Review prepared for Jesrah Agudele</footer>

<script>
function toggle(head) {
  const card = head.closest('.pcard');
  card.classList.toggle('open');
}
<\/script>

</body>
</html>
`;export{n as default};
