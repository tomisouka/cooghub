const n=`<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Linear Algebra · Exam Review</title>
    <link href="https://fonts.googleapis.com/css2?family=DM+Serif+Display:ital@0;1&family=DM+Mono:wght@400;500&family=Outfit:wght@300;400;500;600&display=swap" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/mathjax@3/es5/tex-chtml.js"><\/script>
    <style>
        :root {
            --bg: #0e0f14;
            --surface: #14161e;
            --surface2: #1c1f2b;
            --border: #252836;
            --accent: #c8a96e;
            --accent2: #7eb8c9;
            --green: #5dbd8a;
            --text: #e8e6df;
            --muted: #7a7d8c;
            --q-color: var(--accent);
        }

        * { box-sizing: border-box; margin: 0; padding: 0; }

        body {
            background: var(--bg);
            font-family: 'Outfit', sans-serif;
            color: var(--text);
            line-height: 1.7;
            padding: 2rem 1rem 6rem;
            min-height: 100vh;
        }

        /* Background grid texture */
        body::before {
            content: '';
            position: fixed;
            inset: 0;
            background-image:
                linear-gradient(rgba(200,169,110,0.03) 1px, transparent 1px),
                linear-gradient(90deg, rgba(200,169,110,0.03) 1px, transparent 1px);
            background-size: 40px 40px;
            pointer-events: none;
            z-index: 0;
        }

        .page {
            max-width: 860px;
            margin: 0 auto;
            position: relative;
            z-index: 1;
        }

        /* ── HEADER ── */
        header {
            padding: 3rem 0 2.5rem;
            border-bottom: 1px solid var(--border);
            margin-bottom: 3rem;
            animation: fadeDown 0.6s ease both;
        }

        .course-tag {
            font-family: 'DM Mono', monospace;
            font-size: 0.75rem;
            color: var(--accent);
            letter-spacing: 0.2em;
            text-transform: uppercase;
            margin-bottom: 0.8rem;
        }

        h1 {
            font-family: 'DM Serif Display', serif;
            font-size: clamp(2rem, 5vw, 3.2rem);
            font-weight: 400;
            color: var(--text);
            line-height: 1.15;
            margin-bottom: 1rem;
        }

        h1 em {
            font-style: italic;
            color: var(--accent);
        }

        .header-meta {
            font-size: 0.95rem;
            color: var(--muted);
            max-width: 560px;
        }

        /* ── NAV PILLS ── */
        .nav-pills {
            display: flex;
            flex-wrap: wrap;
            gap: 0.5rem;
            margin-bottom: 3rem;
            animation: fadeDown 0.6s 0.1s ease both;
        }

        .nav-pill {
            font-family: 'DM Mono', monospace;
            font-size: 0.72rem;
            color: var(--muted);
            border: 1px solid var(--border);
            border-radius: 100px;
            padding: 0.3rem 0.9rem;
            cursor: pointer;
            transition: all 0.2s;
            text-decoration: none;
            letter-spacing: 0.05em;
        }

        .nav-pill:hover {
            color: var(--accent);
            border-color: var(--accent);
            background: rgba(200,169,110,0.06);
        }

        /* ── QUESTION CARD ── */
        .q-card {
            background: var(--surface);
            border: 1px solid var(--border);
            border-radius: 20px;
            margin-bottom: 2rem;
            overflow: hidden;
            animation: fadeUp 0.5s ease both;
        }

        .q-card:nth-child(1) { animation-delay: 0.05s; }
        .q-card:nth-child(2) { animation-delay: 0.10s; }
        .q-card:nth-child(3) { animation-delay: 0.15s; }
        .q-card:nth-child(4) { animation-delay: 0.20s; }
        .q-card:nth-child(5) { animation-delay: 0.25s; }

        /* ── CARD HEADER ── */
        .q-header {
            display: flex;
            align-items: center;
            gap: 1rem;
            padding: 1.4rem 1.8rem;
            border-bottom: 1px solid var(--border);
            background: var(--surface2);
        }

        .q-num {
            font-family: 'DM Mono', monospace;
            font-size: 0.7rem;
            color: var(--accent);
            background: rgba(200,169,110,0.1);
            border: 1px solid rgba(200,169,110,0.25);
            border-radius: 8px;
            padding: 0.25rem 0.6rem;
            letter-spacing: 0.1em;
            flex-shrink: 0;
        }

        .q-title {
            font-family: 'DM Serif Display', serif;
            font-size: 1.25rem;
            font-weight: 400;
            color: var(--text);
            flex: 1;
        }

        .q-icon {
            font-size: 1.4rem;
            flex-shrink: 0;
        }

        /* ── CONCEPT BADGE ── */
        .concept-row {
            padding: 0.9rem 1.8rem;
            border-bottom: 1px solid var(--border);
            display: flex;
            align-items: center;
            gap: 0.6rem;
            flex-wrap: wrap;
        }

        .concept-label {
            font-family: 'DM Mono', monospace;
            font-size: 0.65rem;
            color: var(--muted);
            text-transform: uppercase;
            letter-spacing: 0.15em;
        }

        .concept-tag {
            font-family: 'DM Mono', monospace;
            font-size: 0.72rem;
            color: var(--accent2);
            background: rgba(126,184,201,0.08);
            border: 1px solid rgba(126,184,201,0.2);
            border-radius: 100px;
            padding: 0.15rem 0.7rem;
        }

        /* ── CARD BODY ── */
        .q-body {
            padding: 1.6rem 1.8rem;
            display: flex;
            flex-direction: column;
            gap: 1.2rem;
        }

        /* ── RESTATED ── */
        .restated {
            background: rgba(200,169,110,0.05);
            border-left: 3px solid var(--accent);
            border-radius: 0 12px 12px 0;
            padding: 1rem 1.2rem;
        }

        .section-label {
            font-family: 'DM Mono', monospace;
            font-size: 0.65rem;
            text-transform: uppercase;
            letter-spacing: 0.15em;
            color: var(--muted);
            margin-bottom: 0.4rem;
        }

        .restated p {
            font-size: 0.95rem;
            color: #c8c4bb;
        }

        /* ── STEPS ── */
        .steps {
            background: var(--surface2);
            border-radius: 12px;
            padding: 1.1rem 1.3rem;
            border: 1px solid var(--border);
        }

        .steps ul {
            list-style: none;
            display: flex;
            flex-direction: column;
            gap: 0.5rem;
            margin-top: 0.5rem;
        }

        .steps li {
            display: flex;
            gap: 0.7rem;
            font-size: 0.9rem;
            color: #b8b4ac;
            align-items: flex-start;
        }

        .steps li::before {
            content: '→';
            color: var(--accent);
            font-family: 'DM Mono', monospace;
            font-size: 0.8rem;
            margin-top: 0.15rem;
            flex-shrink: 0;
        }

        /* ── EXAMPLE BOX ── */
        .example-box {
            border: 1px dashed rgba(126,184,201,0.3);
            border-radius: 14px;
            padding: 1.3rem 1.5rem;
            background: rgba(126,184,201,0.03);
        }

        .example-header {
            font-family: 'DM Mono', monospace;
            font-size: 0.7rem;
            color: var(--accent2);
            text-transform: uppercase;
            letter-spacing: 0.15em;
            margin-bottom: 1rem;
            display: flex;
            align-items: center;
            gap: 0.5rem;
        }

        .example-header::after {
            content: '';
            flex: 1;
            height: 1px;
            background: rgba(126,184,201,0.15);
        }

        .example-box p {
            font-size: 0.92rem;
            color: #c0bdb5;
            margin: 0.6rem 0;
        }

        .example-box strong {
            color: var(--text);
        }

        /* ── MathJax override ── */
        .MJX-TEX { color: var(--text) !important; }

        /* ── ANSWER BOX ── */
        .answer-box {
            background: rgba(93,189,138,0.07);
            border: 1px solid rgba(93,189,138,0.25);
            border-radius: 14px;
            padding: 1.1rem 1.4rem;
            display: flex;
            gap: 0.8rem;
            align-items: flex-start;
        }

        .answer-check {
            font-size: 1.1rem;
            flex-shrink: 0;
            margin-top: 0.05rem;
        }

        .answer-content {
            flex: 1;
        }

        .answer-label {
            font-family: 'DM Mono', monospace;
            font-size: 0.65rem;
            text-transform: uppercase;
            letter-spacing: 0.15em;
            color: var(--green);
            margin-bottom: 0.3rem;
        }

        .answer-content p {
            font-size: 0.93rem;
            color: #d4f0e3;
        }

        /* ── FOOTER ── */
        footer {
            margin-top: 4rem;
            padding-top: 2rem;
            border-top: 1px solid var(--border);
            text-align: center;
            font-family: 'DM Mono', monospace;
            font-size: 0.75rem;
            color: var(--muted);
            letter-spacing: 0.05em;
            animation: fadeUp 0.5s 0.4s ease both;
        }

        /* ── ANIMATIONS ── */
        @keyframes fadeDown {
            from { opacity: 0; transform: translateY(-16px); }
            to   { opacity: 1; transform: translateY(0); }
        }

        @keyframes fadeUp {
            from { opacity: 0; transform: translateY(20px); }
            to   { opacity: 1; transform: translateY(0); }
        }

        /* ── SCROLLBAR ── */
        ::-webkit-scrollbar { width: 6px; }
        ::-webkit-scrollbar-track { background: var(--bg); }
        ::-webkit-scrollbar-thumb { background: var(--border); border-radius: 3px; }

        /* ── RESPONSIVE ── */
        @media (max-width: 600px) {
            .q-header { flex-wrap: wrap; }
            .q-body { padding: 1.2rem 1.1rem; }
            .concept-row { padding: 0.8rem 1.1rem; }
        }
    </style>
</head>
<body>
<div class="page">

    <header>
        <div class="course-tag">Linear Algebra · Exam 1 Review</div>
        <h1>Step-by-step<br><em>solutions</em></h1>
        <p class="header-meta">Each question shows the restated problem, general method, a worked illustrative example, and the final answer. Matrix entries are replaced with clear sample numbers.</p>
    </header>

    <nav class="nav-pills">
        <a class="nav-pill" href="#q1">Q1 · Matrix Ops</a>
        <a class="nav-pill" href="#q2">Q2 · Gaussian Elim</a>
        <a class="nav-pill" href="#q3">Q3 · Linear Combos</a>
        <a class="nav-pill" href="#q4">Q4 · Basis & Dim</a>
        <a class="nav-pill" href="#q5">Q5 · Null & Range</a>
    </nav>

    <!-- ══════════════════ Q1 ══════════════════ -->
    <div class="q-card" id="q1">
        <div class="q-header">
            <span class="q-num">Q 01</span>
            <span class="q-title">Matrix Operations</span>
            <span class="q-icon">➕</span>
        </div>
        <div class="concept-row">
            <span class="concept-label">Concepts</span>
            <span class="concept-tag">addition</span>
            <span class="concept-tag">scalar multiplication</span>
            <span class="concept-tag">matrix product</span>
        </div>
        <div class="q-body">

            <div class="restated">
                <div class="section-label">Problem</div>
                <p>Given matrices \\(A, B, C, D, E\\) (all \\(2\\times2\\)), compute when defined:
                \\((a)\\ D+E \\quad (b)\\ A+2C \\quad (c)\\ AB \\quad (d)\\ DC\\).</p>
            </div>

            <div class="steps">
                <div class="section-label">General Method</div>
                <ul>
                    <li>Check size compatibility: addition needs identical dimensions; multiplication needs \\(\\#\\text{cols}_\\text{first} = \\#\\text{rows}_\\text{second}\\).</li>
                    <li>For addition / scalar multiplication — operate entry-wise.</li>
                    <li>For product \\(AB\\): \\((AB)_{ij} = \\sum_k A_{ik}B_{kj}\\).</li>
                </ul>
            </div>

            <div class="example-box">
                <div class="example-header">📌 Illustrative Example — 2×2 matrices</div>
                \\[A=\\begin{bmatrix}1&2\\\\3&4\\end{bmatrix},\\; B=\\begin{bmatrix}5&6\\\\7&8\\end{bmatrix},\\; C=\\begin{bmatrix}9&10\\\\11&12\\end{bmatrix},\\; D=\\begin{bmatrix}13&14\\\\15&16\\end{bmatrix},\\; E=\\begin{bmatrix}17&18\\\\19&20\\end{bmatrix}\\]

                <p><strong>(a) \\(D+E\\)</strong></p>
                \\[D+E = \\begin{bmatrix}30 & 32\\\\34 & 36\\end{bmatrix}\\]

                <p><strong>(b) \\(A+2C\\)</strong></p>
                \\[2C = \\begin{bmatrix}18&20\\\\22&24\\end{bmatrix},\\quad A+2C = \\begin{bmatrix}19 & 22\\\\25 & 28\\end{bmatrix}\\]

                <p><strong>(c) \\(AB\\)</strong></p>
                \\[AB = \\begin{bmatrix}1\\cdot5+2\\cdot7 & 1\\cdot6+2\\cdot8\\\\3\\cdot5+4\\cdot7 & 3\\cdot6+4\\cdot8\\end{bmatrix} = \\begin{bmatrix}19 & 22\\\\43 & 50\\end{bmatrix}\\]

                <p><strong>(d) \\(DC\\)</strong></p>
                \\[DC = \\begin{bmatrix}13\\cdot9+14\\cdot11 & 13\\cdot10+14\\cdot12\\\\15\\cdot9+16\\cdot11 & 15\\cdot10+16\\cdot12\\end{bmatrix} = \\begin{bmatrix}271 & 298\\\\311 & 342\\end{bmatrix}\\]
            </div>

            <div class="answer-box">
                <span class="answer-check">✓</span>
                <div class="answer-content">
                    <div class="answer-label">Answers</div>
                    <p>(a) \\(\\begin{bmatrix}30&32\\\\34&36\\end{bmatrix}\\) &ensp; (b) \\(\\begin{bmatrix}19&22\\\\25&28\\end{bmatrix}\\) &ensp; (c) \\(\\begin{bmatrix}19&22\\\\43&50\\end{bmatrix}\\) &ensp; (d) \\(\\begin{bmatrix}271&298\\\\311&342\\end{bmatrix}\\)</p>
                </div>
            </div>
        </div>
    </div>

    <!-- ══════════════════ Q2 ══════════════════ -->
    <div class="q-card" id="q2">
        <div class="q-header">
            <span class="q-num">Q 02</span>
            <span class="q-title">Gaussian Elimination</span>
            <span class="q-icon">⚙️</span>
        </div>
        <div class="concept-row">
            <span class="concept-label">Concepts</span>
            <span class="concept-tag">linear systems</span>
            <span class="concept-tag">row echelon form</span>
            <span class="concept-tag">back-substitution</span>
        </div>
        <div class="q-body">

            <div class="restated">
                <div class="section-label">Problem</div>
                <p>Write the given linear system as an augmented matrix, reduce to echelon form by Gaussian elimination, and find all solutions (if any).</p>
            </div>

            <div class="steps">
                <div class="section-label">General Method</div>
                <ul>
                    <li>Build augmented matrix \\([A \\mid \\mathbf{b}]\\).</li>
                    <li>Use row operations (swap · scale · add multiple) to reach upper triangular form.</li>
                    <li>Back-substitute. A row \\([0\\cdots0 \\mid c],\\ c\\neq0\\) means the system is inconsistent.</li>
                </ul>
            </div>

            <div class="example-box">
                <div class="example-header">📌 Illustrative Example — 2 equations, 2 unknowns</div>
                \\[\\begin{cases}x + 2y = 3\\\\4x + 5y = 6\\end{cases} \\quad\\Rightarrow\\quad \\left[\\begin{array}{cc|c}1&2&3\\\\4&5&6\\end{array}\\right]\\]
                <p>\\(R_2 \\leftarrow R_2 - 4R_1\\):</p>
                \\[\\left[\\begin{array}{cc|c}1&2&3\\\\0&-3&-6\\end{array}\\right]\\]
                <p>From row 2: \\(-3y = -6 \\Rightarrow y = 2\\). Substitute back: \\(x + 4 = 3 \\Rightarrow x = -1\\).</p>
            </div>

            <div class="answer-box">
                <span class="answer-check">✓</span>
                <div class="answer-content">
                    <div class="answer-label">Answer</div>
                    <p>\\(x = -1,\\quad y = 2\\)</p>
                </div>
            </div>
        </div>
    </div>

    <!-- ══════════════════ Q3 ══════════════════ -->
    <div class="q-card" id="q3">
        <div class="q-header">
            <span class="q-num">Q 03</span>
            <span class="q-title">Linear Combinations</span>
            <span class="q-icon">🔗</span>
        </div>
        <div class="concept-row">
            <span class="concept-label">Concepts</span>
            <span class="concept-tag">span</span>
            <span class="concept-tag">linear combination</span>
        </div>
        <div class="q-body">

            <div class="restated">
                <div class="section-label">Problem</div>
                <p>If true, write the given vector as a linear combination of the two spanning vectors. Show all work.</p>
            </div>

            <div class="steps">
                <div class="section-label">General Method</div>
                <ul>
                    <li>Set up \\(c_1\\mathbf{v}_1 + c_2\\mathbf{v}_2 = \\mathbf{w}\\).</li>
                    <li>Solve the resulting linear system for \\(c_1, c_2\\).</li>
                    <li>If a solution exists, express \\(\\mathbf{w} = c_1\\mathbf{v}_1 + c_2\\mathbf{v}_2\\); otherwise state impossible.</li>
                </ul>
            </div>

            <div class="example-box">
                <div class="example-header">📌 Illustrative Example</div>
                \\[\\mathbf{v}_1 = \\begin{bmatrix}1\\\\2\\end{bmatrix},\\quad \\mathbf{v}_2 = \\begin{bmatrix}3\\\\4\\end{bmatrix},\\quad \\mathbf{w} = \\begin{bmatrix}5\\\\6\\end{bmatrix}\\]
                <p>Need \\(c_1\\begin{bmatrix}1\\\\2\\end{bmatrix} + c_2\\begin{bmatrix}3\\\\4\\end{bmatrix} = \\begin{bmatrix}5\\\\6\\end{bmatrix}\\), giving the system:</p>
                \\[\\begin{cases}c_1 + 3c_2 = 5\\\\2c_1 + 4c_2 = 6\\end{cases}\\]
                <p>From row 1: \\(c_1 = 5-3c_2\\). Substituting: \\(-2c_2 = -4 \\Rightarrow c_2 = 2,\\ c_1 = -1\\).</p>
                <p>Check: \\(-1\\begin{bmatrix}1\\\\2\\end{bmatrix}+2\\begin{bmatrix}3\\\\4\\end{bmatrix} = \\begin{bmatrix}5\\\\6\\end{bmatrix}\\) ✓</p>
            </div>

            <div class="answer-box">
                <span class="answer-check">✓</span>
                <div class="answer-content">
                    <div class="answer-label">Answer</div>
                    <p>\\(\\mathbf{w} = -1\\,\\mathbf{v}_1 + 2\\,\\mathbf{v}_2\\)</p>
                </div>
            </div>
        </div>
    </div>

    <!-- ══════════════════ Q4 ══════════════════ -->
    <div class="q-card" id="q4">
        <div class="q-header">
            <span class="q-num">Q 04</span>
            <span class="q-title">Subspaces — Basis & Dimension</span>
            <span class="q-icon">🧩</span>
        </div>
        <div class="concept-row">
            <span class="concept-label">Concepts</span>
            <span class="concept-tag">standard basis</span>
            <span class="concept-tag">dimension</span>
            <span class="concept-tag">span</span>
            <span class="concept-tag">null space description</span>
        </div>
        <div class="q-body">

            <div class="restated">
                <div class="section-label">Problem</div>
                <p>For each of the two given subspaces, determine its standard basis and state its dimension.</p>
            </div>

            <div class="steps">
                <div class="section-label">General Method</div>
                <ul>
                    <li>If given as a span — form a matrix with those vectors as columns and row-reduce; pivot columns of the <em>original</em> matrix form the basis.</li>
                    <li>If given as a solution set — solve the homogeneous system; write the solution in terms of free variables to find basis vectors.</li>
                    <li>Dimension = number of basis vectors.</li>
                </ul>
            </div>

            <div class="example-box">
                <div class="example-header">📌 Two Subspaces of ℝ³</div>
                <p><strong>Subspace \\(S_1\\):</strong> \\(\\text{span}\\left\\{\\begin{bmatrix}1\\\\0\\\\1\\end{bmatrix},\\begin{bmatrix}0\\\\1\\\\0\\end{bmatrix},\\begin{bmatrix}1\\\\1\\\\1\\end{bmatrix}\\right\\}\\)</p>
                \\[\\begin{bmatrix}1&0&1\\\\0&1&1\\\\1&0&1\\end{bmatrix} \\xrightarrow{R_3-R_1} \\begin{bmatrix}1&0&1\\\\0&1&1\\\\0&0&0\\end{bmatrix}\\]
                <p>Pivot columns 1 and 2 → dim = 2.</p>

                <p><strong>Subspace \\(S_2\\):</strong> \\(\\left\\{\\begin{bmatrix}x\\\\y\\\\z\\end{bmatrix}\\mid x+y+z=0\\right\\}\\)</p>
                <p>\\(x = -y-z\\) gives \\(\\begin{bmatrix}-y-z\\\\y\\\\z\\end{bmatrix} = y\\begin{bmatrix}-1\\\\1\\\\0\\end{bmatrix}+z\\begin{bmatrix}-1\\\\0\\\\1\\end{bmatrix}\\) → dim = 2.</p>
            </div>

            <div class="answer-box">
                <span class="answer-check">✓</span>
                <div class="answer-content">
                    <div class="answer-label">Answers</div>
                    <p>\\(S_1\\) basis: \\(\\left\\{\\begin{bmatrix}1\\\\0\\\\1\\end{bmatrix},\\begin{bmatrix}0\\\\1\\\\0\\end{bmatrix}\\right\\}\\), dim = 2</p>
                    <p>\\(S_2\\) basis: \\(\\left\\{\\begin{bmatrix}-1\\\\1\\\\0\\end{bmatrix},\\begin{bmatrix}-1\\\\0\\\\1\\end{bmatrix}\\right\\}\\), dim = 2</p>
                </div>
            </div>
        </div>
    </div>

    <!-- ══════════════════ Q5 ══════════════════ -->
    <div class="q-card" id="q5">
        <div class="q-header">
            <span class="q-num">Q 05</span>
            <span class="q-title">Null Space & Range</span>
            <span class="q-icon">🧠</span>
        </div>
        <div class="concept-row">
            <span class="concept-label">Concepts</span>
            <span class="concept-tag">null space</span>
            <span class="concept-tag">column space</span>
            <span class="concept-tag">linear operator</span>
        </div>
        <div class="q-body">

            <div class="restated">
                <div class="section-label">Problem</div>
                <p>For matrix \\(A\\) (defining \\(\\mathcal{L}(\\mathbf{x}) = A\\mathbf{x}\\)), find a basis for the null space and a basis for the range (column space).</p>
            </div>

            <div class="steps">
                <div class="section-label">General Method</div>
                <ul>
                    <li><strong>Null space:</strong> solve \\(A\\mathbf{x}=\\mathbf{0}\\) — reduce augmented matrix, express pivot variables via free variables; those vectors form the basis.</li>
                    <li><strong>Range (column space):</strong> reduce \\(A\\) to echelon form; pivot columns of the <em>original</em> \\(A\\) give the basis.</li>
                </ul>
            </div>

            <div class="example-box">
                <div class="example-header">📌 Example — A is 2×3</div>
                \\[A = \\begin{bmatrix}1&2&3\\\\4&5&6\\end{bmatrix}\\]
                <p><strong>Null space:</strong> solve \\(A\\mathbf{x}=0\\).</p>
                \\[\\left[\\begin{array}{ccc|c}1&2&3&0\\\\4&5&6&0\\end{array}\\right] \\xrightarrow{R_2-4R_1} \\left[\\begin{array}{ccc|c}1&2&3&0\\\\0&-3&-6&0\\end{array}\\right]\\]
                <p>\\(x_2 = -2x_3,\\ x_1 = x_3\\) → \\(\\mathbf{x} = x_3\\begin{bmatrix}1\\\\-2\\\\1\\end{bmatrix}\\).</p>
                <p><strong>Range:</strong> pivots in columns 1 and 2 of original \\(A\\).</p>
            </div>

            <div class="answer-box">
                <span class="answer-check">✓</span>
                <div class="answer-content">
                    <div class="answer-label">Answers</div>
                    <p>Null space basis: \\(\\left\\{\\begin{bmatrix}1\\\\-2\\\\1\\end{bmatrix}\\right\\}\\)</p>
                    <p>Range basis: \\(\\left\\{\\begin{bmatrix}1\\\\4\\end{bmatrix},\\begin{bmatrix}2\\\\5\\end{bmatrix}\\right\\}\\)</p>
                </div>
            </div>
        </div>
    </div>

    <footer>
        All examples are illustrative · replace numbers with exam values · procedures remain identical
    </footer>

</div>
</body>
</html>`;export{n as default};
