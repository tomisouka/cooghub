const n=`Windows App/Game
        |
        v
+----------------+
|     WINE       |
| (translator)   |
+----------------+
        |
        v
     Linux
     
----------------

Windows Game
     |
     v
+----------------+
|    PROTON      |
| (WINE + fixes) |
+----------------+
     |   \\
     v    v
  Linux  Steam magic
`;export{n as default};
