const e=`I am not gonna lie to you I lowkey have OCD when it comes to studying 
and it is showing right now. If this Is spaced weird it's because I am typign on  
VS Code. You must be like damn jo you are illiterate and can't type or 
read. Well that's kind of true. Now let's get to study gameplan.

I don't know how to study to be honest I am not going to lie to you, but when I do 
I am dangerous. 

Me: I am really hyper aware and addicted to stimming or just multitasking. 
I don't know if this is a medical or unique condition, but this is just how I am.

Layout: For laptop everything is much simpler. Brainstorming and Coding. That simple.
On PC, I have Brainstorming, Low Logic, High Logic, and Hobbies. Now you must be think-
ing damn this has nothign to do with studying. But yes this is the key, to getting it
all down. These are the workspaces I have, confined to the hardware that I am on.
The purpose here is to bounce off them to address my addictive multi-tasked person-
ality. We have to be more disciplined choosing our topic for each. Knowing this is 
mostly for laptop confined spaces. On phones we only can view and watch multi. Not
code. 

Skeleton: The skeleton is what I am calling the preset on all workspaces. I don't 
know if this will happen for the laptop, but we will see. If there is a game going on
or something else that we can put in the background and look it at from time to time
to feed that short spanned mind then we keep it. My prime example is the rockets game.
Other examples include audio in the background like music or podcasts,
popping up spotify to sing lyrics momentarily, BUT NO STORIES. 

Task: This is the most annoying thing because I am not sure how to organize this.
The following is a rant: But basically since there aren't really assignments due 
besides french. We have to ask questions constantly and assume where we are in the 
class and where the class is and where a student that passed this class would be at.
It kinda leans back to the layout, but first we have to ask ourselves questions. Are we
reviewing, doing, or questioning. This is the best I can come up for with right now.
Right now I would categorize myself as questioning. Writing and getting out of my head
but also getting somewhere with this. Which would lead us to either review or doing. 
Another example would be searching the web for an answer, interacting with an LLM
for a better insight, and etc. That is questioning.
Questioning.
When we are doing, we have to ask ourselves what do we want to accomplish? That is the
bridge from questioning to doing. Now doing means creating something new or getting
to a better insight. Same manner but different execution. And we bounce off questioning
to either doing or reviewing and fall back onto questioning to make our next jump.
Tasks like doing would be writing code or answering a question or making something
purely from our own and not practicing. When you are practicing or reviwing that 
is when you are lookiing over something and practicing your form to accomplish the goal
you set out on. AKA the jumping. The jumping is the goal from the questioning to either
reviewing ro doing.
Reveiwing / Doing.

Now that I have that out the way we have to have our priorities in check. 
This isn't like anki where we can purely do doing and reviewing. We have to constantly
create the task until we find a routine like anki. A routine is when you don't 
even question what you do and just accomplish that. You can question after, but
the goal is clear.

Priorities.
School
3320 Algos
IDNS algo workshops
3340 Automata
2318 Linear Algebra
1301 French

Burn this image in my head. We have to be tasking these everyday. Where am i at and 
how do i get there?

Tasking is when i sit down and can access my computer, put up a skeleton or not,
and work questioning, doing, or reviewing.
(means phone too but way less effective)

When I am not at my computer the best I can do is melt. 
The issue with melting is that you cannot do any doing. Mostly questioning and
reveiwing is hardly do-able. Melting is best at when you are confined to just your
brain and you can either multitask like walking to get somewhere, driving or etc.
I know my limit to multi tasking is two things. I can pipeline, but not multitask
more than two. Stimming is more difficult too since getting lost in my head and 
tangenting is really easy to do and hard to recover. So what's the point?
The point is to ask questions and leave trails to come back to when I do have a space
to work from. Even during lectures is like a switch from tasking and melting. Got 
to listen to the lecturer and at the same time mark my own questions.
A special kind of type of melting. but nonetheless melting as you cannot do anything.
Melting. 

Workshop is different though because you are doing with activities, so that would be
a heavy reveiew session more so, aka slow tasking.  

Now lastly this brings us to the hardhitting question, what do i have to do?
Think of your priorities and now ask questions. Start from root and build your way back
up. 

If i am at a space planning to task, but I don't this is what I call floating. 
You are there, but you aren't doing anything. Goodjob you showed up, but too bad
you spaced out. This is the next hurdle to overcome. The first thing is to acknowledge 
that you are floating. Second is either take a break and reset or pick a priority
to start questioning.
Floating.

root to question.`;export{e as default};
