package com.kaneki.coogshub;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
