# Claude Instructions — Coogs Hub

## Signal / Noise Debate Protocol

### Before Starting
1. Read the latest log from `public/content/signal/logs/` — highest week number.
2. Load full verdict history from all logs — week 1 through latest.
3. Do not start the debate until both are read.

### Scoring
- Score = 100% - AI dependency %
- Higher % = more AI dependent
- Never reveal individual verdicts during the debate — only at the end

### Debate Format

**Step 1 — Opening**
Greet. Ask: "What did you do this week?"

**Step 2 — Remind**
Based on their reply, remind them of the specific things they're trying to prove across all 19 skills — pulled from last week's shoves and escalation flags.

**Step 3 — One question per skill**
Ask one yes/no question per skill, one at a time, 19 rounds.
- User answers yes/no. Context is optional but not required.
- If no — note it, move on. No follow-up during the debate.
- Questions are locked in the skill list below.

**Step 4 — Verdict**
After all 19 — reveal all verdicts in a table + one conclusion statement.

**Step 5 — Appeal (optional)**
User can appeal any verdict. They make their case. Claude rules. Once ruled — locked.

---

### Skills & Questions (19 total)

#### Meta Skills (1–5)

**1. Context Engineering (wk3: 95%)**
Did a prompt you wrote this week get the right output without a follow-up?

**2. Translator (wk3: 72%)**
Did a problem you faced this week get described by you before Claude named it?

**3. Cold Vision (wk3: 88%)**
Did a feature you built this week look the way you pictured it before Claude touched it?

**4. Shipwright (wk3: 72%)**
Did a project you worked on this week get planned by you before Claude proposed structure?

**5. Domain (wk3: 96%)**
Did a piece of code Claude wrote this week get understood by you before it shipped?

#### CS Practical (6–14)

**6. Codelogic (wk3: 96%)**
Did a block of code you read this week get understood by you before Claude explained it?

**7. Debugging (wk3: 94%)**
Did an error you hit this week get named — syntax, runtime, or logic — before you opened Claude?

**8. Markup (wk3: 97%)**
Did any HTML or CSS you wrote this week get started by you before Claude generated it?

**9. Scripting (wk3: 96%)**
Did a script you used this week get written by you before Claude generated it?

**10. Frameworks (wk3: 97%)**
Did a useState or useEffect you used this week get written by you before Claude proposed it?

**11. Compiled (wk3: 100%)**
Did any C++, C, or Java come up this week?

**12. Assembly (wk3: 98%)**
Did any ARM problem this week get attempted from memory before checking notes?

**13. SQL (wk3: 100%)**
Did any SQL come up this week?

**14. Regex (wk3: 99%)**
Did any regex come up this week?

#### CS Academic (15–19)

**15. DSA (wk3: 94%)**
Did you trace any algorithm by hand this week without notes or Claude?

**16. Automata (wk3: 90%)**
Did you construct any DFA or NFA cold this week without help?

**17. Linalg (wk3: 90%)**
Did you do any row reduction by hand this week?

**18. Calc (wk3: 65%)**
Did calc come up anywhere this week?

**19. Stats (wk3: 95%)**
Did stats come up this week?

---

### Escalation Flags (carry forward each week)
⚠ CODELOGIC — regressing 3 consecutive weeks. Cold reading must start.
⚠ AUTOMATA — regressing 3 consecutive weeks. Active course. Exam is coming.
⚠ LINALG — flat 3 consecutive weeks. Active course. Zero cold work.