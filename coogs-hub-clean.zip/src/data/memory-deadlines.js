// src/data/memory-deadlines.js
// Runtime persistence for deadlines — auto-saved by DeadlinesPage on every change.
// Do not edit manually while the app is open.
// Last updated: 2026-03-16T03:53:50.098Z

export const DEADLINES = [
  {
    "title": "3320_AlgosMidterm",
    "course": "algos",
    "date": "2026-03-12",
    "time": "",
    "notes": "DC and Asymptotic",
    "type": "school",
    "priority": "normal",
    "id": "1773527905179",
    "done": true
  },
  {
    "title": "3340_HW3",
    "course": "automata",
    "date": "2026-03-12",
    "time": "",
    "notes": "Turing Machines && Pumping Lemma",
    "type": "school",
    "priority": "normal",
    "id": "1773527923143",
    "done": false
  },
  {
    "title": "1",
    "course": "",
    "date": "2026-03-15",
    "time": "",
    "notes": "",
    "type": "research",
    "priority": "normal",
    "id": "1773604803032",
    "done": true,
    "status": "done",
    "startedAt": "2026-03-15",
    "timeEst": "2 hours",
    "reflection": "",
    "firstStep": "[sfjks",
    "subtasks": [
      {
        "id": "1773604803032_step_0",
        "label": "1",
        "done": false
      },
      {
        "id": "1773604803032_step_1",
        "label": "3",
        "done": false
      },
      {
        "id": "1773604803032_step_2",
        "label": "4",
        "done": false
      }
    ],
    "completedAt": "2026-03-15"
  },
  {
    "title": "3320_HW2_Algos",
    "course": "algos",
    "date": "2026-04-05",
    "time": "",
    "notes": "",
    "type": "school",
    "priority": "normal",
    "id": "1773601933534",
    "done": false
  },
  {
    "title": "3340_Quiz3",
    "course": "automata",
    "date": "2026-04-07",
    "time": "",
    "notes": "Turing Machines",
    "type": "school",
    "priority": "normal",
    "id": "1773594038624",
    "done": false
  },
  {
    "title": "3340_HW4",
    "course": "automata",
    "date": "2026-04-09",
    "time": "",
    "notes": "",
    "type": "school",
    "priority": "normal",
    "id": "1773601894890",
    "done": false
  },
  {
    "title": "3320_Exam2",
    "course": "algos",
    "date": "2026-04-16",
    "time": "",
    "notes": "",
    "type": "school",
    "priority": "normal",
    "id": "1773601953280",
    "done": false
  },
  {
    "title": "3340_HW5",
    "course": "automata",
    "date": "2026-04-23",
    "time": "",
    "notes": "",
    "type": "school",
    "priority": "normal",
    "id": "1773601967920",
    "done": false
  },
  {
    "title": "3340_HW6",
    "course": "automata",
    "date": "2026-05-01",
    "time": "",
    "notes": "",
    "type": "school",
    "priority": "normal",
    "id": "1773602008265",
    "done": false
  },
  {
    "title": "3320_FINAL",
    "course": "algos",
    "date": "2026-05-12",
    "time": "",
    "notes": "",
    "type": "school",
    "priority": "normal",
    "id": "1773602046234",
    "done": false
  }
];
