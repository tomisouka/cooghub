// src/data/memory-progress.js
// Runtime persistence for skill levels and course tiers — auto-saved by ProgressPage on every change.
// Do not edit manually while the app is open.
// Last updated: 2026-03-16T22:49:30.390Z

export const SKILL_LEVELS = {};

export const COURSE_TIERS = {
  "algos": "current",
  "automata": "current",
  "opsystems": "current",
  "databases": "current",
  "linear": "current",
  "datastruct": "research",
  "discrete": "research",
  "comporg": "research",
  "cpp": "ambition",
  "python": "ambition"
};
