export const SIGNAL_NOISE_DATA = {
  "currentWeek": 4,
  "history": [
    {
      "week": 1,
      "date": "2026-03-26",
      "avgVerdict": 86,
      "skills": {
        "prompting": 97,
        "framing": 94,
        "creative": 72,
        "writing": 78,
        "research": 68,
        "systems": 75,
        "html": 97,
        "codelogic": 90,
        "debugging": 93,
        "docs": 97,
        "testing": 95,
        "dsa": 95,
        "automata": 85,
        "linalg": 88,
        "calc": 68,
        "stats": 95,
        "discrete": 78
      }
    },
    {
      "week": 2,
      "date": "2026-04-01",
      "avgVerdict": 85,
      "skills": {
        "prompting": 97,
        "framing": 88,
        "creative": 68,
        "writing": 70,
        "research": 58,
        "systems": 65,
        "html": 97,
        "codelogic": 92,
        "debugging": 95,
        "docs": 97,
        "testing": 95,
        "dsa": 96,
        "automata": 88,
        "linalg": 90,
        "calc": 63,
        "stats": 95
      }
    },
    {
      "week": 3,
      "date": "2026-04-03",
      "avgVerdict": 91,
      "skills": {
        "context_engineering": 95,
        "translator": 72,
        "cold_vision": 88,
        "shipwright": 72,
        "domain": 96,
        "codelogic": 96,
        "debugging": 94,
        "markup": 97,
        "scripting": 96,
        "frameworks": 97,
        "compiled": 100,
        "assembly": 98,
        "sql": 100,
        "regex": 99,
        "dsa": 94,
        "automata": 90,
        "linalg": 90,
        "calc": 65,
        "stats": 95
      }
    }
  ],
  "examDates": {},
  "evidence": {},
  "debateLog": {
    "context_engineering": [
      {
        "week": 1,
        "date": "2026-03-26",
        "aiPct": 100,
        "youPct": 99,
        "verdict": 97,
        "youReason": "I prompt everything and give as much context as I can. Only effective with Claude due to file uploads.",
        "swingPoint": "Prompting everything is evidence of dependency not skill. 3pts for iteration instinct.",
        "archived": true,
        "summary": "Wk 1: 97% (as 'prompting'). Prompting everything is dependency not skill.",
        "shove": ""
      },
      {
        "week": 2,
        "date": "2026-04-01",
        "aiPct": 97,
        "youPct": null,
        "verdict": 97,
        "youReason": "",
        "swingPoint": "",
        "archived": true,
        "summary": "Wk 2: 97%. No change.",
        "shove": ""
      },
      {
        "week": 3,
        "date": "2026-04-03",
        "aiPct": 95,
        "youPct": null,
        "verdict": 95,
        "youReason": "Gets what he needs first try, shapes outputs with test scripts.",
        "swingPoint": "First-try accuracy and test script direction earned 2pts. Skill renamed from 'prompting' to 'context engineering'.",
        "archived": false,
        "summary": "Wk 3: 95%. First-try outputs + test script direction. Renamed from prompting.",
        "shove": "Next session: before asking Claude anything, write the constraint and expected output format in one sentence first."
      }
    ],
    "translator": [
      {
        "week": 3,
        "date": "2026-04-03",
        "aiPct": null,
        "youPct": null,
        "verdict": 72,
        "youReason": "Can describe what's broken but not the code underneath it. Commit messages exist but nothing complex.",
        "swingPoint": "New skill week 3. Can articulate the problem surface but not the code logic.",
        "archived": false,
        "summary": "Wk 3: 72% baseline. Can name the problem, can't describe the code.",
        "shove": "Next time something breaks, write one sentence describing it before opening Claude. Just the surface \u2014 what you see, not why."
      }
    ],
    "cold_vision": [
      {
        "week": 3,
        "date": "2026-04-03",
        "aiPct": null,
        "youPct": null,
        "verdict": 88,
        "youReason": "New territory = ask Claude. Blind paste when stuck. No pre-thinking or vision before building.",
        "swingPoint": "Merged framing + creative. New skill week 3. No cold reasoning or pre-vision this week.",
        "archived": false,
        "summary": "Wk 3: 88% baseline. Merged from framing+creative. No pre-thinking this week.",
        "shove": "Before the next BetOnMe feature, write 3 words describing what you want it to look and feel like before opening Claude."
      }
    ],
    "shipwright": [
      {
        "week": 3,
        "date": "2026-04-03",
        "aiPct": null,
        "youPct": null,
        "verdict": 72,
        "youReason": "Explores with Claude, no prep, can't describe BetOnMe architecture cold.",
        "swingPoint": "Merged from systems. Exploration with Claude counts for something over pure dependency.",
        "archived": false,
        "summary": "Wk 3: 72% baseline. Merged from systems. Explores but doesn't map.",
        "shove": "Draw the data flow of BetOnMe on paper \u2014 what talks to what \u2014 before next session. 5 minutes, boxes and arrows."
      }
    ],
    "domain": [
      {
        "week": 3,
        "date": "2026-04-03",
        "aiPct": null,
        "youPct": null,
        "verdict": 96,
        "youReason": "Claude is Gojo, I'm volcano dude. All code is Claude's. Only catches errors when Claude explains reasoning, not from reading logic.",
        "swingPoint": "New skill week 3. Zero ownership of codebase output. Catches mistakes reactively not proactively.",
        "archived": false,
        "summary": "Wk 3: 96% baseline. Claude owns the output entirely.",
        "shove": "Read one function in BetOnMe cold. Not to fix it \u2014 just to say out loud what it does. That's domain."
      }
    ],
    "codelogic": [
      {
        "week": 1,
        "date": "2026-03-26",
        "aiPct": 100,
        "youPct": null,
        "verdict": 90,
        "youReason": "I can guess what code points to but I don't know how often I'd be right. Pattern recognition but not line-by-line tracing.",
        "swingPoint": "Pattern recognition is above zero. Guessing is not owning.",
        "archived": false,
        "summary": "Wk 1: 90% verdict (AI was 100%). Pattern recognition real. Guessing not owning.",
        "shove": "Take the next Claude-generated block, close the chat, and explain out loud what each line does. Record where you get stuck."
      },
      {
        "week": 2,
        "date": "2026-04-01",
        "aiPct": 92,
        "youPct": null,
        "verdict": 92,
        "youReason": "",
        "swingPoint": "",
        "archived": false,
        "summary": "Wk 2: 92%. No change.",
        "shove": ""
      },
      {
        "week": 3,
        "date": "2026-04-03",
        "aiPct": 96,
        "youPct": null,
        "verdict": 96,
        "youReason": "Can't explain own code cold. Scary to even look at the fetchedRef guard.",
        "swingPoint": "No change. Code remains unread and unexplained.",
        "archived": false,
        "summary": "Wk 3: 96%. Still can't read own codebase cold.",
        "shove": "Pick any one function in BetOnMe. Close Claude. Explain it line by line out loud. Record where you lose the thread."
      }
    ],
    "debugging": [
      {
        "week": 1,
        "date": "2026-03-26",
        "aiPct": 100,
        "youPct": null,
        "verdict": 93,
        "youReason": "I know error types \u2014 ghost, runtime, compiled, style. But I can't fix them myself at all.",
        "swingPoint": "Error taxonomy from exposure is real. Can't fix alone confirmed.",
        "archived": false,
        "summary": "Wk 1: 93% verdict (AI was 100%). Error taxonomy real. Can't fix alone.",
        "shove": "Next time something breaks, give yourself 10 minutes before pasting. Read the error. Name the type. One hypothesis."
      },
      {
        "week": 2,
        "date": "2026-04-01",
        "aiPct": 95,
        "youPct": null,
        "verdict": 95,
        "youReason": "",
        "swingPoint": "",
        "archived": false,
        "summary": "Wk 2: 95%. No change.",
        "shove": ""
      },
      {
        "week": 3,
        "date": "2026-04-03",
        "aiPct": 94,
        "youPct": null,
        "verdict": 94,
        "youReason": "Tried to reason through Claude's logic independently, failed. Did remove an emoji from a string solo.",
        "swingPoint": "1pt for attempting independent reasoning before Claude. Small but real.",
        "archived": false,
        "summary": "Wk 3: 94%. Attempted solo reasoning. Failed but tried.",
        "shove": "Next error \u2014 name the type out loud before opening Claude. Syntax, runtime, or logic. One word. Build the reflex."
      }
    ],
    "markup": [
      {
        "week": 3,
        "date": "2026-04-03",
        "aiPct": 97,
        "youPct": null,
        "verdict": 97,
        "youReason": "All Claude-generated. No scratch work, no docs consulted.",
        "swingPoint": "New skill week 3. Baseline at 97%.",
        "archived": false,
        "summary": "Wk 3: 97% baseline. All Claude-generated.",
        "shove": "Write a card component in HTML/CSS from memory \u2014 no Claude until you've got the skeleton down."
      }
    ],
    "scripting": [
      {
        "week": 3,
        "date": "2026-04-03",
        "aiPct": 96,
        "youPct": null,
        "verdict": 96,
        "youReason": "Test scripts Claude-written. BetOnMe JS all Claude.",
        "swingPoint": "New skill week 3. Baseline at 96%.",
        "archived": false,
        "summary": "Wk 3: 96% baseline. No independent JS or Python written.",
        "shove": "Write one small JS function from scratch \u2014 even 5 lines. No Claude until it's written."
      }
    ],
    "frameworks": [
      {
        "week": 3,
        "date": "2026-04-03",
        "aiPct": 97,
        "youPct": null,
        "verdict": 97,
        "youReason": "React and Tailwind all Claude-scaffolded. No independent hook or component decisions.",
        "swingPoint": "New skill week 3. Baseline at 97%.",
        "archived": false,
        "summary": "Wk 3: 97% baseline. All Claude-scaffolded.",
        "shove": "Next time you use useState or useEffect, write the hook yourself before asking Claude. Even if it's wrong."
      }
    ],
    "compiled": [
      {
        "week": 3,
        "date": "2026-04-03",
        "aiPct": 100,
        "youPct": null,
        "verdict": 100,
        "youReason": "Not touched this week.",
        "swingPoint": "New skill week 3. Baseline at 100%.",
        "archived": false,
        "summary": "Wk 3: 100% baseline. Not in active use.",
        "shove": ""
      }
    ],
    "assembly": [
      {
        "week": 3,
        "date": "2026-04-03",
        "aiPct": 98,
        "youPct": null,
        "verdict": 98,
        "youReason": "ARM in CompOrg but nothing cold.",
        "swingPoint": "New skill week 3. Baseline at 98%.",
        "archived": false,
        "summary": "Wk 3: 98% baseline. CompOrg ARM not executed cold.",
        "shove": ""
      }
    ],
    "sql": [
      {
        "week": 3,
        "date": "2026-04-03",
        "aiPct": 100,
        "youPct": null,
        "verdict": 100,
        "youReason": "Not touched.",
        "swingPoint": "New skill week 3. Baseline at 100%.",
        "archived": false,
        "summary": "Wk 3: 100% baseline. Not in curriculum yet.",
        "shove": ""
      }
    ],
    "regex": [
      {
        "week": 3,
        "date": "2026-04-03",
        "aiPct": 99,
        "youPct": null,
        "verdict": 99,
        "youReason": "Not touched.",
        "swingPoint": "New skill week 3. Baseline at 99%.",
        "archived": false,
        "summary": "Wk 3: 99% baseline. Not in active use.",
        "shove": ""
      }
    ],
    "dsa": [
      {
        "week": 1,
        "date": "2026-03-26",
        "aiPct": 100,
        "youPct": null,
        "verdict": 95,
        "youReason": "Maybe just theory. Cannot trace or implement cold at all.",
        "swingPoint": "Theory only. Exam room has no Claude.",
        "archived": false,
        "summary": "Wk 1: 95% verdict (AI was 100%). Theory only.",
        "shove": "Trace a BFS on paper using a 5-node graph you draw yourself. No AI, no notes. Just you and the graph."
      },
      {
        "week": 2,
        "date": "2026-04-01",
        "aiPct": 96,
        "youPct": null,
        "verdict": 96,
        "youReason": "",
        "swingPoint": "",
        "archived": false,
        "summary": "Wk 2: 96%. No change.",
        "shove": ""
      },
      {
        "week": 3,
        "date": "2026-04-03",
        "aiPct": 94,
        "youPct": null,
        "verdict": 94,
        "youReason": "Dijkstra GPS workshop \u2014 applied algo work, assisted but real.",
        "swingPoint": "2pts for applied Dijkstra in workshop context. First real algo engagement since baseline.",
        "archived": false,
        "summary": "Wk 3: 94%. Dijkstra workshop. First movement in 3 weeks.",
        "shove": "Trace Dijkstra on the graph you used in workshop \u2014 by hand, no notes. Write the priority queue state at every step."
      }
    ],
    "automata": [
      {
        "week": 1,
        "date": "2026-03-26",
        "aiPct": 100,
        "youPct": null,
        "verdict": 85,
        "youReason": "I know DFA, NFA, GNFA, regular languages, sets. I can draw a DFA. But give me a language and I'm guessing. Concatenation and proofs \u2014 not there.",
        "swingPoint": "Knows the landscape and can draw a DFA. Solving from spec cold is not there.",
        "archived": false,
        "summary": "Wk 1: 85% verdict (AI was 100%). Can draw DFA. Solving from spec cold not there.",
        "shove": "Draw a DFA that accepts strings ending in '01' \u2014 from scratch, no help. Check it after."
      },
      {
        "week": 2,
        "date": "2026-04-01",
        "aiPct": 88,
        "youPct": null,
        "verdict": 88,
        "youReason": "",
        "swingPoint": "",
        "archived": false,
        "summary": "Wk 2: 88%. No change.",
        "shove": ""
      },
      {
        "week": 3,
        "date": "2026-04-03",
        "aiPct": 90,
        "youPct": null,
        "verdict": 90,
        "youReason": "Nothing constructed, nothing attempted.",
        "swingPoint": "Regression. 3340 is active and nothing is being practiced cold.",
        "archived": false,
        "summary": "Wk 3: 90%. Nothing cold. Regressing while in active course.",
        "shove": "Draw the DFA for strings ending in '00' right now. Cold. Check it after. This is exam material."
      }
    ],
    "linalg": [
      {
        "week": 1,
        "date": "2026-03-26",
        "aiPct": 100,
        "youPct": null,
        "verdict": 88,
        "youReason": "I know basic operations but got lost in row reduction running out of moves. No geometric intuition yet.",
        "swingPoint": "Basic operations real. Lost mid row-reduction means no geometric foundation yet.",
        "archived": false,
        "summary": "Wk 1: 88% verdict (AI was 100%). Basic ops real. Lost in row reduction.",
        "shove": "Do one row reduction problem by hand from your textbook. Write out every step. Find where you run out of moves."
      },
      {
        "week": 2,
        "date": "2026-04-01",
        "aiPct": 90,
        "youPct": null,
        "verdict": 90,
        "youReason": "",
        "swingPoint": "",
        "archived": false,
        "summary": "Wk 2: 90%. No change.",
        "shove": ""
      },
      {
        "week": 3,
        "date": "2026-04-03",
        "aiPct": 90,
        "youPct": null,
        "verdict": 90,
        "youReason": "Nothing touched.",
        "swingPoint": "Flat 2 weeks. No cold work happening in active course.",
        "archived": false,
        "summary": "Wk 3: 90%. Flat. Nothing cold.",
        "shove": "One row reduction from the 2318 textbook by hand. Every step. Find where you run out of moves."
      }
    ],
    "calc": [
      {
        "week": 1,
        "date": "2026-03-26",
        "aiPct": 100,
        "youPct": null,
        "verdict": 68,
        "youReason": "Took precalc, calc 1, calc 2. I know derivatives and integrals but need a refresher.",
        "swingPoint": "Three completed courses is the strongest credential today. Refresher need keeps it at 68.",
        "archived": false,
        "summary": "Wk 1: 68% verdict (AI was 100%). Three completed courses. Refresher needed.",
        "shove": "Solve 3 derivatives cold from a practice sheet \u2014 no calculator, no AI. Check after."
      },
      {
        "week": 2,
        "date": "2026-04-01",
        "aiPct": 63,
        "youPct": null,
        "verdict": 63,
        "youReason": "",
        "swingPoint": "Solved problems cold. Only CS Academic skill with any cold execution this week.",
        "archived": false,
        "summary": "Wk 2: 63%. Solved problems cold. Only CS Academic skill with any cold execution this week.",
        "shove": ""
      },
      {
        "week": 3,
        "date": "2026-04-03",
        "aiPct": 65,
        "youPct": null,
        "verdict": 65,
        "youReason": "Not in active use, no loop, slight regression for the gap.",
        "swingPoint": "Not in curriculum but drifting. Three completed courses \u2014 don't let it fully decay.",
        "archived": false,
        "summary": "Wk 3: 65%. Drifting. Not in active loop.",
        "shove": ""
      }
    ],
    "stats": [
      {
        "week": 1,
        "date": "2026-03-26",
        "aiPct": 100,
        "youPct": null,
        "verdict": 95,
        "youReason": "I reverse engineered it. Formula heavy. I don't feel like I learned anything. Barely passed.",
        "swingPoint": "Reverse engineering formulas without understanding why \u2014 exactly what this axis measures against.",
        "archived": false,
        "summary": "Wk 1: 95% verdict (AI was 100%). Reverse engineered. Didn't learn it.",
        "shove": "Pick one stats formula you used in that class and explain in one sentence why it works, not just what it does."
      },
      {
        "week": 2,
        "date": "2026-04-01",
        "aiPct": 95,
        "youPct": null,
        "verdict": 95,
        "youReason": "",
        "swingPoint": "",
        "archived": false,
        "summary": "Wk 2: 95%. No change.",
        "shove": ""
      },
      {
        "week": 3,
        "date": "2026-04-03",
        "aiPct": 95,
        "youPct": null,
        "verdict": 95,
        "youReason": "Nothing touched.",
        "swingPoint": "Flat. Not in active curriculum.",
        "archived": false,
        "summary": "Wk 3: 95%. Flat. Not in active use.",
        "shove": ""
      }
    ]
  }
};
