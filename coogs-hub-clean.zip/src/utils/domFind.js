/**
 * domFind.js — real DOM-based in-page search for Tauri webview
 * Replaces window.find() which is broken/deprecated in WebView2.
 *
 * Fix (Apr 2026): highlightAll now retries until the page content
 * stabilises (text length stops growing), so searches issued while
 * React/MarkdownViewer is still rendering actually find matches.
 * scrollIntoView now walks up to the nearest scrollable ancestor so
 * it works inside nested overflow:auto containers.
 */

const MARK_CLASS  = "ctrl-f-hl";
const MARK_ACTIVE = "ctrl-f-hl-active";

let matches      = [];
let currentIndex = -1;

// ── helpers ──────────────────────────────────────────────────────────────────

/** Walk up the DOM and return the nearest scrollable ancestor (or null). */
function nearestScroller(el) {
  let node = el?.parentElement;
  while (node && node !== document.body) {
    const { overflowY } = getComputedStyle(node);
    if (overflowY === "auto" || overflowY === "scroll") return node;
    node = node.parentElement;
  }
  return null;
}

/** Scroll element into the centre of its nearest scrollable ancestor. */
function scrollMarkIntoView(mark) {
  const scroller = nearestScroller(mark);
  if (scroller) {
    const markRect   = mark.getBoundingClientRect();
    const scrollRect = scroller.getBoundingClientRect();
    scroller.scrollBy({
      top: markRect.top - scrollRect.top - scroller.clientHeight / 2,
      behavior: "smooth",
    });
  } else {
    mark.scrollIntoView({ behavior: "smooth", block: "center" });
  }
}

// ── public API ────────────────────────────────────────────────────────────────

export function clearHighlights() {
  document.querySelectorAll(`mark.${MARK_CLASS}`).forEach(mark => {
    const parent = mark.parentNode;
    if (!parent) return;
    parent.replaceChild(document.createTextNode(mark.textContent), mark);
    parent.normalize();
  });
  matches      = [];
  currentIndex = -1;
}

/**
 * Highlight all occurrences of `query` in document.body.
 *
 * If the page is still rendering (text content keeps growing) we poll
 * up to ~2 s until it stabilises, then re-highlight. The callback
 * `onUpdate(total)` is called every time the count changes so the UI
 * can stay in sync.
 *
 * Returns the initial match count (may be 0 if content not ready yet).
 */
export function highlightAll(query, onUpdate) {
  clearHighlights();
  _cancelRetry();

  if (!query || query.length < 1) return 0;

  const count = _doHighlight(query);
  if (count > 0) {
    onUpdate?.(count);
    return count;
  }

  // Nothing found yet — content may still be loading. Start polling.
  _startRetry(query, onUpdate);
  return 0;
}

export function findNext() {
  if (!matches.length) return { current: 0, total: 0 };
  currentIndex = (currentIndex + 1) % matches.length;
  activateCurrent();
  return { current: currentIndex + 1, total: matches.length };
}

export function findPrev() {
  if (!matches.length) return { current: 0, total: 0 };
  currentIndex = (currentIndex - 1 + matches.length) % matches.length;
  activateCurrent();
  return { current: currentIndex + 1, total: matches.length };
}

export function getStats() {
  return { current: currentIndex + 1, total: matches.length };
}

// ── internals ─────────────────────────────────────────────────────────────────

let _retryTimer  = null;
let _retryCancel = false;

function _cancelRetry() {
  _retryCancel = true;
  if (_retryTimer) { clearTimeout(_retryTimer); _retryTimer = null; }
}

/**
 * Poll until body text stabilises (content has finished rendering),
 * then re-highlight. Gives up after ~2 s.
 */
function _startRetry(query, onUpdate) {
  _retryCancel  = false;
  let lastLen   = document.body.innerText.length;
  let stableFor = 0;
  let elapsed   = 0;
  const POLL_MS     = 80;
  const STABLE_NEED = 3;   // consecutive stable checks
  const MAX_MS      = 2000;

  function tick() {
    if (_retryCancel) return;
    elapsed += POLL_MS;
    const nowLen = document.body.innerText.length;

    if (nowLen !== lastLen) {
      lastLen   = nowLen;
      stableFor = 0;
    } else {
      stableFor++;
    }

    if (stableFor >= STABLE_NEED || elapsed >= MAX_MS) {
      clearHighlights();
      const count = _doHighlight(query);
      onUpdate?.(count);
      return;
    }

    _retryTimer = setTimeout(tick, POLL_MS);
  }

  _retryTimer = setTimeout(tick, POLL_MS);
}

/** Core highlight pass. Returns match count. */
function _doHighlight(query) {
  const q = query.toLowerCase();

  const walker = document.createTreeWalker(document.body, NodeFilter.SHOW_TEXT, {
    acceptNode(node) {
      const tag = node.parentElement?.tagName?.toLowerCase();
      if (["script", "style", "noscript", "textarea"].includes(tag)) return NodeFilter.FILTER_REJECT;
      if (node.parentElement?.closest?.("#ctrl-f-bar"))              return NodeFilter.FILTER_REJECT;
      if (node.parentElement?.classList?.contains(MARK_CLASS))       return NodeFilter.FILTER_REJECT;
      return NodeFilter.FILTER_ACCEPT;
    },
  });

  const textNodes = [];
  let node;
  while ((node = walker.nextNode())) textNodes.push(node);

  for (const textNode of textNodes) {
    const text  = textNode.textContent;
    const lower = text.toLowerCase();
    let pos = 0;
    let idx;
    const frag = document.createDocumentFragment();
    let found  = false;

    while ((idx = lower.indexOf(q, pos)) !== -1) {
      if (idx > pos) frag.appendChild(document.createTextNode(text.slice(pos, idx)));
      const mark       = document.createElement("mark");
      mark.className   = MARK_CLASS;
      mark.textContent = text.slice(idx, idx + q.length);
      frag.appendChild(mark);
      matches.push(mark);
      found = true;
      pos   = idx + q.length;
    }

    if (found) {
      if (pos < text.length) frag.appendChild(document.createTextNode(text.slice(pos)));
      textNode.parentNode.replaceChild(frag, textNode);
    }
  }

  if (matches.length > 0) {
    currentIndex = 0;
    activateCurrent();
  }

  return matches.length;
}

function activateCurrent() {
  matches.forEach(m => m.classList.remove(MARK_ACTIVE));
  const m = matches[currentIndex];
  if (!m) return;
  m.classList.add(MARK_ACTIVE);
  scrollMarkIntoView(m);
}
