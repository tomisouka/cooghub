# Growth Checklist — Week 3
**Generated:** Apr 03, 2026
**Complete what you can. Nothing here is mandatory. Everything here moves the needle.**

---

## 🔴 High Priority (active courses + highest reliance)

- [ ] Pick any one function in BetOnMe. Close Claude. Read it line by line and say out loud what it does. Stop where you lose the thread — that's the gap. (Domain / Codelogic)
- [ ] Draw the DFA for strings over {0,1} ending in '00' — cold, no notes, no AI. Check it after against your notes. (Automata)
- [ ] Write one small JS function from scratch in a blank file. Even 5 lines. No Claude until the function exists in some form. (Scripting)
- [ ] Do one row reduction problem from the 2318 textbook by hand. Every step. Find exactly where you run out of moves. (Linalg)

## 🟠 Medium Priority (building toward independence)

- [ ] Trace Dijkstra on the graph you used in workshop. Write the priority queue state at every step on paper. No AI, no notes. (DSA)
- [ ] Next time something breaks in BetOnMe — name the error type out loud before opening Claude. Syntax, runtime, or logic. One word. (Debugging)

## 🟡 Stretch Goals

- [ ] Write a card component in HTML/CSS from memory. Skeleton only — no Claude until the structure is down. (Markup)
- [ ] Before the next BetOnMe feature, write 3 words describing what you want it to look, feel, and do. That's your Cold Vision. (Cold Vision)

---

## Skill Targets This Week
| Skill | Current | Target | What Would Move It |
|---|---|---|---|
| Domain | 96% | 93% | Read one function cold and explain it without Claude |
| Codelogic | 96% | 93% | Trace one BetOnMe function line by line, record where you lose it |
| Automata | 90% | 86% | Draw one DFA from spec cold, check it after |
| Scripting | 96% | 93% | Write one JS function from scratch before Claude touches it |
| DSA | 94% | 91% | Trace Dijkstra by hand, priority queue state at every step |

---

*Check off what you do. Bring this file next session as evidence.*
