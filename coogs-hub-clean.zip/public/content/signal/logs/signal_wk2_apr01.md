# Signal / Noise — Week 2 Debate Log
**Date:** Apr 01, 2026
**Overall avg verdict:** 84%

## Verdicts Locked
| Skill      | Week 1 | Week 2 | Change | Moved? |
|------------|--------|--------|--------|--------|
| Prompting  | 97%    | 97%    | 0      | No     |
| Framing    | 94%    | 88%    | -6     | Yes    |
| Creative   | 72%    | 68%    | -4     | Yes    |
| Writing    | 78%    | 70%    | -8     | Yes    |
| Research   | 68%    | 58%    | -10    | Yes    |
| Systems    | 75%    | 65%    | -10    | Yes    |
| HTML       | 97%    | 97%    | 0      | No     |
| Codelogic  | 90%    | 92%    | +2     | Yes    |
| Debugging  | 93%    | 95%    | +2     | Yes    |
| Docs       | 97%    | 97%    | 0      | No     |
| Testing    | 95%    | 95%    | 0      | No     |
| DSA        | 95%    | 96%    | +1     | Yes    |
| Automata   | 85%    | 88%    | +3     | Yes    |
| Linalg     | 88%    | 90%    | +2     | Yes    |
| Calc       | 68%    | 63%    | -5     | Yes    |
| Stats      | 95%    | 95%    | 0      | No     |

## What Shifted This Week
Real gains in the meta skills — framing, research, and systems all moved meaningfully — but CS practical and academic floors didn't budge, and codelogic, automata, and linalg are quietly getting worse.

## Key Debate Moments
- No contests. All 16 verdicts accepted as proposed.
- Framing was the biggest single-week improvement: 3/3 diagnostic answers, -6pts.
- Research dropped 10pts on the back of catching Claude being out of date — independent verification actually happened.

## Priority Actions Next Week
1. DSA — trace one algorithm by hand before opening Claude
2. Automata — draw the ending-in-00 DFA cold tonight
3. Linalg — one row reduction from textbook, cold, every step written
4. HTML — 10 lines of nav bar from memory before Claude touches it
5. Docs — open react.dev before the next Claude question about hooks

## Escalation Flags
⚠ CODELOGIC — regressing week 2. Reading Claude-generated code before keeping it needs to start now.
⚠ AUTOMATA — regressing week 2. Standard DFA cold execution is not there.
⚠ LINALG — regressing week 2. Cold problems need to start happening this week.
