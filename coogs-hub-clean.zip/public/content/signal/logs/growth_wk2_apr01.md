# Growth Checklist — Week 2
**Generated:** Apr 01, 2026
**Complete what you can. Nothing here is mandatory. Everything here moves the needle.**

---

## 🔴 High Priority (highest-reliance skills + your top courses)

- [ ] Draw the DFA for strings over {0,1} ending in '00' from scratch. No notes, no AI. Check it after. (Automata)
- [ ] Trace BFS on a 5-node graph you draw yourself. Write the queue state at every step. (DSA)
- [ ] Do one row reduction problem from your 2318 textbook cold. Write every step. Find the exact line where you lose the thread. (Linalg)
- [ ] Open a blank file and write a nav bar in HTML from memory. 10 lines minimum before Claude touches it. (HTML)

## 🟠 Medium Priority (building toward independence)

- [ ] Open react.dev and look up one hook you've used in coogs-hub. Read the signature, params, and one example — without asking Claude. (Docs)
- [ ] Take the last Claude-generated block in coogs-hub, close the chat, and explain out loud what each line does. Note exactly where you get stuck. (Codelogic)
- [ ] Next time something breaks in the project, give yourself 10 minutes before pasting. Name the error type. Write one hypothesis. (Debugging)

## 🟡 Stretch Goals

- [ ] Write a 3-sentence explanation of what a DFA is — no AI, no notes. Raw and imperfect is fine. (Writing + Automata)
- [ ] Pick one stats formula from your old class and write one sentence explaining why it works, not just what it does. (Stats)

---

## Skill Targets This Week
| Skill    | Current | Target | What Would Move It |
|----------|---------|--------|--------------------|
| DSA      | 96%     | 91%    | Trace one algorithm cold on paper |
| Automata | 88%     | 82%    | Draw a standard DFA from spec without help |
| Linalg   | 90%     | 85%    | Complete one row reduction cold, every step |
| HTML     | 97%     | 93%    | Write any markup from memory before Claude |
| Docs     | 97%     | 92%    | Open an official reference before the next Claude question |

---

*Check off what you do. Bring this file next session as evidence.*
